/* eslint-disable */
import { action } from '@storybook/addon-actions'
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import Countries from '../../stories/fixtures/countries'
import { disabled, fullWidth, label, placeholder } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import deprecated from '../../stories/decorators/deprecated'
import Autocomplete from './autocomplete'


const CustomOption = item => {

    return (
        <div style={{ display: 'flex', width: '100%' }}>
            <span style={{ flex: '1 1 auto' }}>{item.label}</span>
            <span>{item.value.first}</span>
        </div>
    )
}

const onChange = e => action('change')(e)

const onInputValueChange = value => {
    console.log(value)
}

const searchTemplate = item => item.label

const inputDisplayTemplate = item => item ? item.label : ''

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Autocomplete'
}

export const Basic = () => (
    <Autocomplete {...{
        disabled: disabled(),
        fullWidth: fullWidth(),
        inputDisplayTemplate,
        items: Countries,
        label: label(),
        onChange,
        onInputValueChange,
        searchTemplate: searchTemplate,
        placeholder: placeholder(),
        value: { label: 'test', value: { first: 'b' } }
    }} />
)

export const WithCustomOption = () => (
    <Autocomplete {...{
        disabled: disabled(),
        displayTemplate: CustomOption,
        fullWidth: fullWidth(),
        inputDisplayTemplate,
        label: label(),
        items: Countries,
        onChange,
        placeholder: placeholder(),
        searchTemplate: searchTemplate,
    }} />
)
