
/* eslint-disable */
export const autocompleteStyles = theme => {
    return {
        root: {
            position: 'relative',
            width: '100%',
            '& .au-paper': {
                maxHeight: theme.spacing(50),
                overflow: 'auto',
                padding: 0,
                position: 'absolute',                
                width: '100%',
                zIndex: 999
            }
        }
    }
}

