import { configure, mount } from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import toJson from 'enzyme-to-json'
import React from 'react'
import Autocomplete from './autocomplete'


configure({ adapter: new Adapter() })

describe('<Autocomplete />', () => {

    const items = [
        { label: 'Alpha' },
        { label: 'Bravo' },
        { label: 'Charlie' },
        { label: 'Delta' },
        { label: 'Echo' },
        { label: 'Foxtrot' }
    ]

    let autocomplete

    beforeEach(() => {

        autocomplete = mount(
            <Autocomplete {...{
                fullWidth: true,
                items,
                label: 'Autocomplete label',
                placeholder: 'Autocomplete placeholder'
            }} />
        )
    })

    it('should render correctly', () => {
        expect(toJson(autocomplete)).toMatchSnapshot()
    })
})
