import PropTypes from 'prop-types'
import React from 'react'
import MenuItem from '../../menu-item'


export default WrappedComponent => {

    return class extends React.Component {

        static displayName = 'AUAutocompleteOption'

        static propTypes = {
            children: PropTypes.node,
            isFocused: PropTypes.bool,
            onFocus: PropTypes.func,
            onSelect: PropTypes.func,
            option: PropTypes.shape({
                value: PropTypes.object.isRequired
            })
        }

        handleClick = event => {
            this.props.onSelect(this.props.option, event)
        }

        render () {

            const { children, isFocused, onFocus } = this.props

            return (
                <MenuItem {...{
                    onClick: this.handleClick,
                    onFocus,
                    selected: isFocused
                }}>
                    <WrappedComponent option={this.props.option.value}>{children}</WrappedComponent>
                </MenuItem>
            )
        }
    }
}
