import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown'
import ArrowDropUpIcon from '@material-ui/icons/ArrowDropUp'
import ClearIcon from '@material-ui/icons/Clear'
import PropTypes from 'prop-types'
import React from 'react'
import Select from 'react-select'
import Typography from '../../typography'
import ValueComponent from './value'
import withMenuItem from './with-menu-item'


const clearRenderer = () => <ClearIcon />

const AUAutocompleteSelect = class extends React.Component {

    static displayName = 'AUAutocompleteSelect'

    static defaultProps = {
        disabled: false,
        noResultsMessage: 'No results found',
        optionComponent: withMenuItem(props => props.children)
    }

    static propTypes = {
        disabled: PropTypes.bool,
        noResultsMessage: PropTypes.string,
        optionComponent: PropTypes.oneOfType([
            PropTypes.element,
            PropTypes.func
        ])
    }

    render() {

        const { disabled, noResultsMessage, ...other } = this.props

        return (
            <Select {...{
                arrowRenderer: arrowProps => {
                    return arrowProps.isOpen ? <ArrowDropUpIcon /> : <ArrowDropDownIcon />
                },
                clearRenderer,
                disabled,
                noResultsText: <Typography>{noResultsMessage}</Typography>,
                optionComponent: this.props.optionComponent,
                valueComponent: ValueComponent
            }}
            {...other} />
        )
    }
}

export default AUAutocompleteSelect
