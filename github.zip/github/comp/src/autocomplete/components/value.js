import CancelIcon from '@material-ui/icons/Cancel'
import PropTypes from 'prop-types'
import React from 'react'
import Chip from '../../chip'


const ValueComponent = class extends React.Component {

    static displayName = 'ValueComponent'

    static propTypes = {
        children: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.array
        ]),
        onRemove: PropTypes.func,
        value: PropTypes.object
    }

    constructor(props) {
        super(props)

        this.onDelete = this.onDelete.bind(this)
    }

    onDelete(event) {

        const { value, onRemove } = this.props

        event.preventDefault()
        event.stopPropagation()
        onRemove(value)
    }

    render() {

        const { children, onRemove } = this.props

        if (onRemove) {
            return (
                <Chip {...{
                    deleteIcon: <CancelIcon {...{ onTouchEnd: this.onDelete }} />,
                    label: children,
                    onDelete: this.onDelete,
                    tabIndex: -1
                }} />
            )
        }

        return (
            <div className='Select-value'>
                {children}
            </div>
        )
    }
}

export default ValueComponent
