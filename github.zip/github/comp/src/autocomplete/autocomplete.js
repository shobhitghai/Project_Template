import isFunction from 'lodash/fp/isFunction'
import isObject from 'lodash/fp/isObject'
import React from 'react'
import PropTypes from 'prop-types'
import Downshift from 'downshift'
import { withStyles } from '../styles/'
import MenuItem from '../menu-item'
import Paper from '../paper'
import TextField from '../text-field'
import { withTelemetry } from '../telemetry'
import { showDeprecationWarning } from '../../utils'
import { autocompleteStyles } from './styles'


const valuesBySearchTerm = (item, value, searchTemplate) => {
    if (!value) {
        return true
    }
    if (!searchTemplate) {
        return true
    }
    const searchThis = searchTemplate(item)
    const regEx = new RegExp(value, 'i')
    return regEx.test(searchThis)
}

const AUAutocomplete = withTelemetry(withStyles(autocompleteStyles)(class extends React.Component {

    static displayName = 'AUAutocomplete'

    static propTypes = {
        ...TextField.propTypes,
        displayTemplate: PropTypes.oneOfType([
            PropTypes.element,
            PropTypes.func
        ]),
        inputDisplayTemplate: PropTypes.func,
        items: PropTypes.arrayOf(PropTypes.object),
        onInputValueChange: PropTypes.func,
        paperProps: PropTypes.shape({ ...Paper.propTypes }),
        searchTemplate: PropTypes.func,
        toggleOnClick: PropTypes.bool,
        value: PropTypes.oneOfType([ PropTypes.string, PropTypes.object ])
    }

    static defaultProps = {
        inputDisplayTemplate: item => item ? item.toString() : undefined,
        items: [],
        paperProps: { elevation: 5 },
        toggleOnClick: false
    }

    componentDidMount () {
        showDeprecationWarning('The Autocomplete component has been deprecated. Please use Autocomplete 2 instead')
    }

    renderMenuItems = options => {
        const { isOpen, inputValue } = options
        const displayValue = inputValue || ''
        const {
            searchTemplate,
            items,
            paperProps
        } = this.props
        return (
            <Paper {...paperProps}>
                {isOpen
                    ? items
                        .filter(item => valuesBySearchTerm(item, displayValue, searchTemplate))
                        .map((item, index) => this.renderMenuItem(item, index, options))
                    : []}
            </Paper>
        )
    }

    renderMenuItem = (item, index, options) => {
        const { highlightedIndex, selectedItem, getItemProps } = options
        const {
            displayTemplate,
            inputDisplayTemplate
        } = this.props

        const itemProps = getItemProps({
            item
        })
        const selected = selectedItem && inputDisplayTemplate(item) === inputDisplayTemplate(selectedItem)

        const isHighlighted = highlightedIndex === index

        return <MenuItem
            {...itemProps}
            key={index}
            selected={isHighlighted}
            style={{
                fontWeight: selected ? 500 : 400
            }}
        >{displayTemplate ? displayTemplate(item, itemProps) : inputDisplayTemplate(item)}</MenuItem>
    }

    inputProps = options => {
        const {
            getInputProps,
            inputValue,
            selectedItem,
            toggleMenu,
            clearSelection
        } = options

        const { inputDisplayTemplate, onInputValueChange, toggleOnClick } = this.props

        let displayValue = inputValue || ''

        if (isObject(selectedItem)) {
            displayValue = inputDisplayTemplate(selectedItem)
        }

        return getInputProps({
            onChange: event => {
                clearSelection()
                if (isFunction(onInputValueChange)) {
                    onInputValueChange(event.target.value)
                }
            },
            onClick: toggleOnClick ? toggleMenu : () => { },
            value: displayValue
        })
    }

    renderAutoComplete = options => {

        const {
            displayTemplate,
            searchTemplate,
            inputDisplayTemplate,
            items,
            onChange,
            onInputValueChange,
            paperProps,
            toggleOnClick,
            value,
            ...other
        } = this.props

        const { isOpen } = options

        return (
            <div>
                <TextField {...this.inputProps(options)} {...other} />
                {isOpen && this.renderMenuItems(options)}
            </div>
        )
    }

    render() {
        const {
            classes,
            inputDisplayTemplate,
            onChange,
            value
        } = this.props

        return (
            <div className={classes.root}>
                <Downshift onChange={onChange} itemToString={inputDisplayTemplate} selectedItem={value}>
                    {this.renderAutoComplete}
                </Downshift>
            </div>
        )
    }
}))

export default AUAutocomplete

