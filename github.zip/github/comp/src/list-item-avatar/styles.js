/* eslint-disable */
export const listItemAvatarStyles = theme => {
    return {
        root: {
            height: theme.spacing(4),
            width: theme.spacing(4)
        }
    }
}
