import { ListItemAvatar } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { listItemAvatarStyles } from './styles'


const AUListItemAvatar = withTelemetry(withStyles(listItemAvatarStyles)(class extends React.Component {

    static displayName = 'AUListItemAvatar'

    // Declaring muiName (using the same name as the original Material UI component) essential for ListItem to detect its presence
    static muiName = 'ListItemAvatar'

    static propTypes = ListItemAvatar.propTypes

    render() {

        const { props } = this

        return (
            <ListItemAvatar {... {
                ...props,
                className: classnames('au-list-item-avatar', props.className)
            }} />
        )
    }
}))

export default AUListItemAvatar
