/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import classnames from 'classnames'
import jss from 'jss'
import preset from 'jss-preset-default'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { anchor, elevation } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Button from '../button'
import Drawer from './drawer'


jss.setup(preset())

const DRAWER_SPACING = 240

const styles = {
    drawerContent: {
        minHeight: DRAWER_SPACING,
        minWidth: DRAWER_SPACING
    },
    mainContent: {
        flexGrow: 1,
        marginLeft: -DRAWER_SPACING,
        padding: 32,
        transition: 'margin-left 225ms cubic-bezier(0.4, 0, 0.6, 1)'
    },
    mainContentShifted: {
        marginLeft: 0,
        transition: 'margin-left 225ms cubic-bezier(0, 0, 0.2, 1)'
    },
    permanentDrawer: {
        height: '100vh',
        width: DRAWER_SPACING
    },
    persisentDrawer: {
        height: '100vh',
        width: DRAWER_SPACING
    },
    persisentDrawerPaper: {
        width: DRAWER_SPACING
    },
    persistentWrapper: {
        display: 'flex'
    },
    wrapper: {
        alignItems: 'center',
        display: 'flex',
        height: 400,
        justifyContent: 'center',
        width: '100%'
    },
    paper:{
        backgroundColor: '#27292a !important'
    }
}

const { classes } = jss.createStyleSheet(styles).attach()

class OverrideStyleTemporaryDrawer extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            open: false
        }

        this.toggleDrawer = this.toggleDrawer.bind(this)
    }

    toggleDrawer() {
        this.setState({ open: !this.state.open })
    }

    render() {
        return (
            <div {...{
                className: classes.wrapper
            }}>
                <Button {...{
                    onClick: this.toggleDrawer
                }}>
                    Open Drawer
                </Button>

                <Drawer {...{
                    anchor: anchor(),
                    elevation: parseInt(elevation()),
                    onClose: this.toggleDrawer,
                    open: this.state.open,
                    classes: { paper: classes.paper }
                }}>
                    <div {...{
                        className: classes.drawerContent
                    }}/>
                </Drawer>
            </div>
        )
    }
}

class TemporaryDrawer extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            open: false
        }

        this.toggleDrawer = this.toggleDrawer.bind(this)

        this.ref = React.createRef()
    }

    toggleDrawer() {
        this.setState({ open: !this.state.open })
    }

    render() {
        return (
            <div {...{
                className: classes.wrapper
            }}>
                <Button {...{
                    onClick: this.toggleDrawer
                }}>
                    Open Drawer
                </Button>

                <Drawer {...{
                    anchor: anchor(),
                    elevation: parseInt(elevation()),
                    onClose: this.toggleDrawer,
                    open: this.state.open,
                    ref: this.ref
                }}>
                    <div {...{
                        className: classes.drawerContent
                    }}/>
                </Drawer>
            </div>
        )
    }
}

class PersistentDrawer extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            open: false
        }

        this.toggleDrawer = this.toggleDrawer.bind(this)
    }

    toggleDrawer() {
        this.setState({ open: !this.state.open })
    }

    render() {

        const { open } = this.state

        return (
            <div {...{
                className: classes.persistentWrapper
            }}>
                <Drawer {...{
                    anchor: 'left',
                    onClose: this.toggleDrawer,
                    open,
                    PaperProps: {
                        className: classes.persisentDrawerPaper
                    },
                    variant: 'persistent'
                }}>
                    <div {...{
                        className: classes.persisentDrawer
                    }}/>
                </Drawer>

                <main {...{
                    className: classnames(classes.mainContent, {
                        [classes.mainContentShifted]: open
                    })
                }}>
                    <Button {...{
                        onClick: this.toggleDrawer
                    }}>
                        {open ? 'Close' : 'Open'} Drawer
                    </Button>
                </main>
            </div>
        )
    }
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Drawer'
}

export const OverrideStyleTemporary = () => <OverrideStyleTemporaryDrawer />

export const Temporary = () => <TemporaryDrawer />

export const Permanent = () => (
    <div>
        <Drawer {...{
            className: classes.permanentDrawer,
            variant: 'permanent'
        }}>
            <div {...{
                className: classnames(classes.drawerContent, classes.permanentDrawer)
            }}/>
        </Drawer>
    </div>
)

export const Persistent = () => <PersistentDrawer />
