/* eslint-disable */
export const drawerStyles = theme => {
    return {
        paperAnchorDockedBottom: {
            borderTop: 'none'
        },
        paperAnchorDockedLeft: {
            borderRight: 'none'
        },
        paperAnchorDockedRight: {
            borderLeft: 'none'
        },
        paperAnchorDockedTop: {
            borderBottom: 'none'
        }
    }
}
