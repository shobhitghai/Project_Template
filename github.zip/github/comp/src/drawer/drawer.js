import { Drawer } from '@material-ui/core'
import { makeStyles } from '@material-ui/core/styles'
import classnames from 'classnames'
import merge from 'lodash/fp/merge'
import React from 'react'
import { withTelemetry } from '../telemetry'
import { drawerStyles } from './styles'


const useStyles = makeStyles(drawerStyles)

const AUDrawer = withTelemetry(React.forwardRef(({ classes, ...other }, ref) => {

    const defaultStyles = useStyles()

    return (
        <Drawer {...{
            ...other,
            classes: merge(defaultStyles, classes),
            className: classnames('au-drawer', other.className),
            ref
        }} />
    )
}))

AUDrawer.displayName = 'AUDrawer'
AUDrawer.propTypes = Drawer.propTypes

export default AUDrawer
