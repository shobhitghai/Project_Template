/* eslint-disable */
import { number, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import rootWrapper from '../../stories/root-wrapper'
import TimePicker from './time-picker'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Time Picker'
}

export const Basic = () => (
    <TimePicker {...{
        inputProps: {
            step: number('Step', 300)
        }
    }} />
)
