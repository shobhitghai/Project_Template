import Schedule from '@material-ui/icons/Schedule'
import classnames from 'classnames'
import propTypes from 'prop-types'
import React from 'react'
import { showDeprecationWarning } from '../../utils'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import InputAdornment from '../input-adornment'
import TextField from '../text-field'
import { timePickerStyles } from './styles'


showDeprecationWarning('The TimePicker component has been deprecated. Please use TimePicker2 instead')

const AUTimePicker = withTelemetry(withStyles(timePickerStyles)(class extends React.Component {

    static displayName = 'AUTimePicker'

    static propTypes = {
        classes: propTypes.object,
        defaultValue: propTypes.string,
        fullWidth: propTypes.bool,
        inputProps: propTypes.shape({
            step: propTypes.number
        })
    }

    static defaultProps = {
        fullWidth: true,
        inputProps: {
            step: 300
        }
    }

    render() {

        const { props } = this
        const { input, ...otherClasses } = props.classes

        return (
            <TextField {...{
                ...props,
                classes: otherClasses,
                className: classnames('au-time-picker', props.className),
                InputProps: {
                    className: input,
                    endAdornment: <InputAdornment><Schedule /></InputAdornment>
                },
                type: 'time'
            }} />
        )
    }
}))

export default AUTimePicker
