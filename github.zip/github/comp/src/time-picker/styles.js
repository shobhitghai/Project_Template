/* eslint-disable */
export const timePickerStyles = theme => {
    return {
        root: {
            '& input::-webkit-inner-spin-button': {
                display: 'none'
            },

            '& input[type="time"]::-webkit-clear-button': {
                display: 'none'
            },

            '& svg': {
                fontSize: theme.typography.h3.fontSize
            }
        },

        input: {
            fontSize: theme.typography.body2.fontSize
        }
    }
}
