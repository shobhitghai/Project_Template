/* eslint-disable */

export const sliderStyles = theme => {
    return {
        root: {
            fontFamily: theme.typography.fontFamily,
            fontSize: theme.typography.body1.fontSize
        }
    }
}
