import { Slider } from '@material-ui/core/'
import { makeStyles } from '@material-ui/core/styles'
import classnames from 'classnames'
import merge from 'lodash/fp/merge'
import React from 'react'
import { withTelemetry } from '../telemetry'
import { sliderStyles } from './styles'


const useStyles = makeStyles(sliderStyles)

const AUSlider = withTelemetry(({ classes, ...other }) => {

    const defaultStyles = useStyles()

    return (
        <Slider {...{
            ...other,
            classes: merge(defaultStyles, classes),
            className: classnames('au-slider', other.className)
        }} />
    )
})
AUSlider.displayName = 'AUSlider'

AUSlider.propTypes = Slider.propTypes

export default AUSlider
