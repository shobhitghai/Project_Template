/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import jss from 'jss'
import preset from 'jss-preset-default'
import React, { useState } from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { max, min, orientation, step, valueLabel } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Slider from './slider'


jss.setup(preset())

const styles = {
    wrapper: {
        alignItems: 'center',
        display: 'flex',
        height: 400,
        justifyContent: 'center',
        width: '100%'
    }
}

const { classes } = jss.createStyleSheet(styles).attach()

const marks = [
    {
        value: 0,
        label: '0',
    },
    {
        value: 15,
        label: '15',
    },
    {
        value: 37,
        label: '37',
    },
    {
        value: 63,
        label: '63',
    },
    {
        value: 100,
        label: '100',
    },
];

const DEFAULT_VALUE = 15

const StepSlider = () => {

    return (
        <div {...{
            className: classes.wrapper
        }}>
            <Slider {...{
                defaultValue: DEFAULT_VALUE,
                marks,
                max: max(),
                min: min(),
                orientation: orientation(),
                step: step(),
                valueLabelDisplay: valueLabel()
            }}/>
        </div>
    );
}

const RestrictedvaluesSlider = () => {

    return (
        <div {...{
            className: classes.wrapper
        }}>
            <Slider {...{
                defaultValue: DEFAULT_VALUE,
                marks,
                max: max(),
                min: min(),
                orientation: orientation(),
                step: null,
                valueLabelDisplay: valueLabel()
            }}/>
        </div>
    );
}

const RangeSlider = () => {

    const  [value, setValue] = useState([20,37])

    const handleChange= (evt, newValue) => setValue(newValue)

    return (
        <div {...{
            className: classes.wrapper
        }}>
            <Slider {...{
                max: max(),
                marks,
                min: min(),
                onChange: handleChange,
                orientation: orientation(),
                step: step(),
                value: value,
                valueLabelDisplay: valueLabel()
            }}/>
        </div>
    );
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Slider'
}

export const Steps = () => <StepSlider />

export const Range = () => <RangeSlider />

export const RestrictedValues = () => <RestrictedvaluesSlider />