export { default } from './slider'
