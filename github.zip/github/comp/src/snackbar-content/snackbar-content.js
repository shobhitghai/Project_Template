import { SnackbarContent } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { snackbarContentStyles } from './styles'


const AUSnackbarContent = withTelemetry(withStyles(snackbarContentStyles)(class extends React.Component {

    static displayName = 'AUSnackbarContent'

    static propTypes = SnackbarContent.proptypes

    render() {

        const { props } = this

        return (
            <SnackbarContent {...{
                ...props,
                className: classnames('au-snackbar-content', props.className)
            }} />
        )
    }
}))

export default AUSnackbarContent
