/* eslint-disable */
export const snackbarContentStyles = theme => {
    return {
        root: {
            alignItems: 'flex-start',
            flexGrow: 'unset',
            padding: theme.spacing(2)
        },
        message: {
            flex: 1,
            padding: 0
        },
        action: {
            '& svg': {
                ...theme.typography.h3
            }
        }
    }
}
