export { default } from './fade'
