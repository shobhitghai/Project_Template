import { Fade } from '@material-ui/core'
import classnames from 'classnames'
import React from 'react'


const AUFade = class extends React.Component {

    static displayName = 'AUFade'

    static propTypes = Fade.propTypes

    render() {

        const { props } = this

        return (
            <Fade {...{
                ...props,
                className: classnames('au-fade', props.className)
            }} />
        )
    }
}

export default AUFade
