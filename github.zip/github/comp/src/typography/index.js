export { default } from './typography'
