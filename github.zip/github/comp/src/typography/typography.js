import { Typography } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import withCustomColors from '../styles/with-custom-colors'
import { withTelemetry } from '../telemetry'
import { typographyStyles } from './styles'


const AUTypography = withTelemetry(withCustomColors(withStyles(typographyStyles)(class extends React.Component {

    static displayName = 'AUTypography'

    static propTypes = Typography.proptypes

    render() {

        const { props } = this

        return (
            <Typography {... {
                ...props,
                className: classnames('au-typography', props.className)
            }}/>
        )
    }
})))

export default AUTypography
