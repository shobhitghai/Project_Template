export const typographyStyles = theme => {
    return {
        gutterBottom: {
            marginBottom: theme.spacing(2)
        }
    }
}
