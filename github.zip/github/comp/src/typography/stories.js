/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { align, color, gutterBottom, loremIpsum } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Typography from './typography'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Typography'
}

export const Basic = () => (
    <div>
        <Typography {...{
            align: align(),
            color: color(),
            gutterBottom: gutterBottom(),
            variant: 'h1'
        }}>
            H1
        </Typography>

        <Typography {...{
            align: align(),
            color: color(),
            gutterBottom: gutterBottom(),
            variant: 'h2'
        }}>
            H2
        </Typography>

        <Typography {...{
            align: align(),
            color: color(),
            gutterBottom: gutterBottom(),
            variant: 'h3'
        }}>
            H3
        </Typography>

        <Typography {...{
            align: align(),
            color: color(),
            gutterBottom: gutterBottom(),
            variant: 'h4'
        }}>
            H4
        </Typography>

        <Typography {...{
            align: align(),
            color: color(),
            gutterBottom: gutterBottom(),
            variant: 'h5'
        }}>
            H5
        </Typography>

        <Typography {...{
            align: align(),
            color: color(),
            gutterBottom: gutterBottom(),
            variant: 'h6'
        }}>
            H6
        </Typography>

        <Typography {...{
            align: align(),
            color: color(),
            gutterBottom: gutterBottom(),
            variant: 'subtitle1'
        }}>
            Subtitle1
        </Typography>

        <Typography {...{
            align: align(),
            color: color(),
            gutterBottom: gutterBottom(),
            variant: 'body1'
        }}>
            Body 1
        </Typography>

        <Typography {...{
            align: align(),
            color: color(),
            gutterBottom: gutterBottom(),
            variant: 'body2'
        }}>
            Body 2
        </Typography>

        <Typography {...{
            align: align(),
            color: color(),
            gutterBottom: gutterBottom(),
            variant: 'caption'
        }}>
            Caption
        </Typography>

        <Typography {...{
            align: align(),
            color: color(),
            gutterBottom: gutterBottom(),
            noWrap: true,
            paragraph: true
        }}>
            <b>Paragraph with noWrap prop:</b> {loremIpsum()}
        </Typography>

        <Typography {...{
            align: align(),
            color: color(),
            gutterBottom: gutterBottom(),
            variant: 'button'
        }}>
            Button
        </Typography>
    </div>
)
