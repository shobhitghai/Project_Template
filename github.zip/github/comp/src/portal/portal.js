import { Portal } from '@material-ui/core'
import React from 'react'


const AUPortal = class extends React.Component {

    static displayName = 'AUPortal'

    static propTypes = Portal.propTypes

    render() {

        const { props } = this

        return (
            <Portal {...props} />
        )
    }
}

export default AUPortal
