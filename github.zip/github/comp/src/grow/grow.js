import { Grow } from '@material-ui/core'
import classnames from 'classnames'
import React from 'react'


const AUGrow = class extends React.Component {

    static displayName = 'AUGrow'

    static propTypes = Grow.propTypes

    render() {

        const { props } = this

        return (
            <Grow {...{
                ...props,
                className: classnames('au-grow', props.className)
            }} />
        )
    }
}

export default AUGrow
