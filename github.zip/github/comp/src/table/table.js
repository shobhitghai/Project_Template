import React from 'react'
import { Table } from '@material-ui/core'
import classnames from 'classnames'
import { withTelemetry } from '../telemetry'


export default withTelemetry(class extends React.Component {

    static displayName = 'AUTable'

    static propTypes = Table.propTypes

    render() {

        const { props } = this

        return (
            <Table {...{
                ...props,
                className: classnames('au-table', props.className)
            }} />
        )
    }
})
