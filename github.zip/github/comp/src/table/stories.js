/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import jss from 'jss'
import preset from 'jss-preset-default'
import fp from 'lodash/fp'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import tableData from '../../stories/fixtures/table-data'
import rootWrapper from '../../stories/root-wrapper'
import Button from '../button'
import Checkbox from '../checkbox'
import TableBody from '../table-body'
import TableCell from '../table-cell'
import TableHead from '../table-head'
import TablePagination from '../table-pagination'
import TableRow from '../table-row'
import TableSortLabel from '../table-sort-label'
import Toolbar from '../toolbar'
import Tooltip from '../tooltip'
import Typography from '../typography'
import Table from './table'


jss.setup(preset())

const map3 = fp.map.convert({ 'cap': false })

const tableHeadings = [
    {
        id: 'heading1',
        label: 'Table Heading 1'
    },
    {
        id: 'heading2',
        label: 'Table Heading 2'
    },
    {
        id: 'heading3',
        label: 'Table Heading 3'
    },
    {
        id: 'heading4',
        label: 'Table Heading 4'
    }
]

function getSorting(order, orderBy) {
    return order === 'desc'
        ? (a, b) => (b[orderBy] < a[orderBy] ? -1 : 1)
        : (a, b) => (a[orderBy] < b[orderBy] ? -1 : 1)
}

const styles = {
    cellWithButton: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between'
    }
}

class EnhancedTableHead extends React.Component {
    createSortHandler = property => event => {
        this.props.onRequestSort(event, property)
    }

    render() {
        const { onSelectAllClick, order, orderBy, numSelected, rowCount } = this.props

        return (
            <TableHead>
                <TableRow>
                    <TableCell {...{
                        padding: 'checkbox'
                    }}>
                        <Checkbox {...{
                            checked: numSelected === rowCount,
                            indeterminate: numSelected > 0 && numSelected < rowCount,
                            onChange: onSelectAllClick
                        }} />
                    </TableCell>

                    {map3(heading => {
                        return (
                            <TableCell {...{
                                key: heading.id,
                                sortDirection: orderBy === heading.id ? order : false
                            }}>
                                <Tooltip {...{
                                    title: 'Sort'
                                }}>
                                    <TableSortLabel {...{
                                        active: orderBy === heading.id,
                                        direction: order,
                                        onClick: this.createSortHandler(heading.id)
                                    }}>
                                        {heading.label}
                                    </TableSortLabel>
                                </Tooltip>
                            </TableCell>
                        )
                    })(tableHeadings)}
                </TableRow>
            </TableHead>
        )
    }
}

let EnhancedTableToolbar = props => {
    const { numSelected } = props

    return (
        <Toolbar>
            <div>
                {numSelected > 0 ? (
                    <Typography {...{
                        variant: 'subtitle1'
                    }}>
                        {numSelected} selected
                    </Typography>
                ) : (
                    <Typography {...{
                        id: 'tableTitle',
                        variant: 'h6'
                    }}>
                        Title
                    </Typography>
                )}
            </div>
        </Toolbar>
    )
}

class EnhancedTable extends React.Component {
    state = {
        data: tableData,
        order: 'asc',
        orderBy: 'heading2',
        page: 0,
        rowsPerPage: 5,
        selected: []
    }

    onSelectAllClick = (event, checked) => {
        if (checked) {
            this.setState(state => ({ selected: map3(n => n.id, state.data) }))
            return
        }
        this.setState({ selected: [] })
    }
    
    onClick = (event, id) => {
        const { selected } = this.state
        const selectedIndex = selected.indexOf(id)
        let newSelected = []
        
        if (selectedIndex === -1) {
            newSelected = newSelected.concat(selected, id)
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(selected.slice(1))
        } else if (selectedIndex === selected.length - 1) {
            newSelected = newSelected.concat(selected.slice(0, -1))
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(
                selected.slice(0, selectedIndex),
                selected.slice(selectedIndex + 1),
            )
        }
        
        this.setState({ selected: newSelected })
    }
    
    onChangePage = (event, page) => {
        this.setState({ page })
    }
    
    onChangeRowsPerPage = event => {
        this.setState({ rowsPerPage: event.target.value })
    }
    
    isSelected = id => this.state.selected.indexOf(id) !== -1
    
    onRequestSort = (event, property) => {
        const orderBy = property
        let order = 'desc'

        if (this.state.orderBy === property && this.state.order === 'desc') {
            order = 'asc'
        }
        this.setState({ order, orderBy })
    }

    render() {
        const { data, order, orderBy, selected, rowsPerPage, page } = this.state
        
        return (
            <div>
                <EnhancedTableToolbar {...{
                    numSelected: selected.length
                }} />

                <div>
                    <Table>
                        <EnhancedTableHead {...{
                            numSelected: selected.length,
                            onRequestSort: this.onRequestSort,
                            onSelectAllClick: this.onSelectAllClick,
                            order,
                            orderBy,
                            rowCount: data.length
                        }} />

                        <TableBody>
                            {map3(
                                n => {
                                    const isSelected = this.isSelected(n.id)
                                    return (
                                        <TableRow {...{
                                            'aria-checked': isSelected,
                                            hover: true,
                                            key: n.id,
                                            onClick: event => this.onClick(event, n.id),
                                            role: 'checkbox',
                                            selected: isSelected,
                                            tabIndex: -1
                                        }}>
                                            <TableCell {...{
                                                padding: 'checkbox'
                                            }}>
                                                <Checkbox {...{
                                                    checked: isSelected
                                                }} />
                                            </TableCell>
                                            <TableCell>{n.heading1}</TableCell>
                                            <TableCell>{n.heading2}</TableCell>
                                            <TableCell>{n.heading3}</TableCell>
                                            <TableCell>{n.heading4}</TableCell>
                                        </TableRow>
                                    )
                                },
                                tableData
                                    .sort(getSorting(order, orderBy))
                                    .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            )}
                        </TableBody>
                    </Table>
                </div>

                <TablePagination {...{
                    component: 'div',
                    count: data.length,
                    onChangePage: this.onChangePage,
                    onChangeRowsPerPage: this.onChangeRowsPerPage,
                    page: page,
                    rowsPerPage: rowsPerPage
                }} />
            </div>
        )
    }
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Table'
}

export const Basic = () => {
    const { classes } = jss.createStyleSheet(styles).attach()

    return (
        <Table>
            <TableHead>
                <TableRow>
                    {map3(heading => {
                        return (
                            <TableCell {...{
                                key: heading.id
                            }}>
                                {heading.label}
                            </TableCell>
                        )
                    })(tableHeadings)}
                </TableRow>
            </TableHead>

            <TableBody>
                {map3((n, i) => {
                    return (
                        <TableRow {...{
                            key: n.id
                        }}>
                            <TableCell {...{
                                component: 'th',
                                scope: 'row'
                            }}>
                                {n.heading1}
                            </TableCell>
                            <TableCell>{n.heading2}</TableCell>
                            <TableCell {...{
                                align: 'right'
                            }}>
                                {n.heading3}
                            </TableCell>
                            <TableCell {...{
                                className: i === 1 && classes.cellWithButton,
                                align: 'right'
                            }}>
                                {n.heading4}
                                {i === 1
                                    && <Button {...{
                                        children: 'Button',
                                        size: 'small'
                                    }} />
                                }
                            </TableCell>
                        </TableRow>
                    )
                })(tableData)}
            </TableBody>
        </Table>
    )
}

export const SortingAndSelecting = () => <EnhancedTable />
