import { Grid } from '@material-ui/core/'
import classnames from 'classnames'
import PropTypes from 'prop-types'
import React from 'react'


const AUGridContainer = class extends React.Component {

    static displayName = 'AUGridContainer'

    static defaultProps = {
        spacing: 0
    }

    static propTypes = {
        ...Grid.propTypes,
        alignItems: PropTypes.oneOf([ 'flex-start', 'center', 'flex-end', 'stretch', 'baseline' ]),
        spacing: PropTypes.oneOf([ 0, 8, 16, 24, 32, 40 ])
    }

    render() {

        const { props } = this

        return (
            <Grid {...{
                ...props,
                className: classnames('au-grid-container', props.className),
                container: true
            }} />
        )
    }
}

export default AUGridContainer
