import classnames from 'classnames'
import Tab from '@material-ui/core/Tab'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { tabStyles } from './styles'


const AUTab = withTelemetry(withStyles(tabStyles)(class extends React.Component {

    static displayName = 'AUTab'

    static propTypes = Tab.propTypes

    render() {

        const { props } = this

        return (
            <Tab {...{
                ...props,
                className: classnames('au-tab', props.className)
            }} />
        )
    }
}))

export default AUTab
