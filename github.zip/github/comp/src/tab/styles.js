/* eslint-disable */
export const tabStyles = theme => {
    return {
        root: {
            height: theme.spacing(4),
            fontSize: theme.typography.body2.fontSize,
            maxWidth: 'none',
            minHeight: theme.spacing(4),
            minWidth: 'auto',
            paddingLeft: theme.spacing(2),
            paddingRight: theme.spacing(2),
            textTransform: 'none'
        },
        wrapper: {
            '& > span:first-of-type': {
                padding: `0 ${theme.spacing(2)}px`
            }
        }
    }
}
