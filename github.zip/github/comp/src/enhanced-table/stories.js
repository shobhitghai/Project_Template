/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import rootWrapper from '../../stories/root-wrapper'
import EnhancedTable from './table'
import icons from './icons'

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Enhanced Table'
}

export const Basic = () => (
    <EnhancedTable
        actions={[
            {
                icon: icons.Edit,
                tooltip: 'Save User',
                onClick: (event, rowData) => {}
            },
            {
                icon: icons.Delete,
                tooltip: 'Delete User',
                onClick: (event, rowData) => {}
            }
        ]}
        columns={[
            { title: 'First', field: 'name' },
            { title: 'Last', field: 'surname' },
            { title: 'Birth', field: 'birthYear', type: 'numeric' },
            { title: 'City', field: 'birthCity', lookup: { 34: 'London', 63: 'Toronto' } }
        ]}
        data={[
            { name: 'Eget', surname: 'Aliquet', birthYear: 1977, birthCity: 63 },
            { name: 'Nibh', surname: 'Praesent', birthYear: 1987, birthCity: 34 },
            { name: 'Tristique', surname: 'Eget', birthYear: 1997, birthCity: 63 },
            { name: 'Mehmet', surname: 'Baran', birthYear: 1982, birthCity: 34 },
            { name: 'Tristique', surname: 'Nibh', birthYear: 1988, birthCity: 63 },
            { name: 'Aliquet', surname: 'Magna', birthYear: 1981, birthCity: 34 }
        ]}
        options={{
            exportButton: true,
            filtering: true,
            search: true
        }}
        title="Employees"
    />
)
