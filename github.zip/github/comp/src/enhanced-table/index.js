export { default } from './table'
