import { createMuiTheme, ThemeProvider } from '@material-ui/core/styles'
import classnames from 'classnames'
import MaterialTable from 'material-table'
import React, { forwardRef } from 'react'
import icons from './icons'
import overrides from './styles/overrides'


const getTableTheme = overridesFunc => theme => {

    const { overrides: currentOverrides, ...rest } = theme

    return createMuiTheme({
        overrides: {
            ...currentOverrides,
            ...overridesFunc(theme)
        },
        ...rest
    })

}

const AUEnhancedTable = forwardRef(({ className, ...other }, ref) => (
    <ThemeProvider theme={getTableTheme(overrides)}>
        <MaterialTable {...{
            className: classnames('au-enhanced-table', className),
            icons,
            ...other,
            tableRef: ref
        }} />
    </ThemeProvider>
))

AUEnhancedTable.displayName = 'AUEnhancedTable'

AUEnhancedTable.propTypes = MaterialTable.propTypes

export default AUEnhancedTable
