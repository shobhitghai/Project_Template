export default ({ palette }) => (
    {
        MuiIconButton: {
            colorSecondary: {
                '&.Mui-checked': {
                    '&:hover': {
                        backgroundColor: `${palette.action.hover} !important`
                    }
                },
                '&:hover': {
                    backgroundColor: palette.action.hover
                }
            },
            root: {
                '&:hover': {
                    backgroundColor: palette.action.hover
                }
            },
        },
    }
)
