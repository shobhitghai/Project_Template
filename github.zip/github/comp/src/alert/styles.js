/* eslint-disable */
export default theme => {

    return {
        root: {
            fontSize: theme.typography.body2.fontSize
        }
    }
}
