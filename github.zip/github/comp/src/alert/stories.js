/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { severity, variantTextField } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Alert from './alert'
import AlertTitle from '../alert-title'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        }
    },
    title: 'Components|Alert'
}

export const Basic = () => (
    <Alert severity={severity()} variant={variantTextField()}>
        {`This is important ${severity()} message`}
    </Alert>
)

export const WithTitle = () => (
    <Alert severity={severity()} variant={variantTextField()}>
        <AlertTitle>{severity()}</AlertTitle>
        {`This is important ${severity()} message`}
    </Alert>
)

export const WithClose = () => (
    <Alert severity={severity()} onClose={() => {}} variant={variantTextField()}>
        {`This is important ${severity()} message`}
    </Alert>
)
