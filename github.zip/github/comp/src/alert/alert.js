import Alert from '@material-ui/lab/Alert'
import { makeStyles } from '@material-ui/core/styles'
import classnames from 'classnames'
import merge from 'lodash/fp/merge'
import React from 'react'
import { withTelemetry } from '../telemetry'
import styles from './styles'


const useStyles = makeStyles(styles)

const AUAlert = withTelemetry(React.forwardRef(({ classes, ...other }, ref) => {

    const defaultStyles = useStyles()

    return (
        <Alert {...{
            ...other,
            classes: merge(defaultStyles, classes),
            className: classnames('au-alert', other.className),
            ref
        }} />
    )
}))

AUAlert.displayName = 'AUAlert'
AUAlert.propTypes = Alert.propTypes

export default AUAlert
