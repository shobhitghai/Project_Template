/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import rootWrapper from '../../stories/root-wrapper'
import Typography from '../typography'
import ExpansionPanelDetails from '../expansion-panel-details'
import ExpansionPanelSummary from '../expansion-panel-summary'
import ExpansionPanel from '../expansion-panel'
import Accordion from './accordion'
import mdx from '../../stories/components/component-doc.mdx'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Accordion'
}

export const Basic = () => (
    <Accordion>
            <ExpansionPanel>
                <ExpansionPanelSummary>
                    <Typography>Expansion Panel 1</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                    <Typography>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex, sit amet blandit leo lobortis eget.</Typography>
                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel disabled>
                <ExpansionPanelSummary>
                    <Typography>Expansion Panel 2</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                    <Typography>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex, sit amet blandit leo lobortis eget.</Typography>
                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel expanded>
                <ExpansionPanelSummary>
                    <Typography>Expansion Panel 3</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                    <Typography>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex, sit amet blandit leo lobortis eget.</Typography>
                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel defaultExpanded>
                <ExpansionPanelSummary>
                    <Typography>Expansion Panel 4</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                    <Typography>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex, sit amet blandit leo lobortis eget.</Typography>
                </ExpansionPanelDetails>
            </ExpansionPanel>
        </Accordion>
)
