import { configure, mount } from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import toJson from 'enzyme-to-json'
import React from 'react'
import ExpansionPanelDetails from '../expansion-panel-details'
import ExpansionPanelSummary from '../expansion-panel-summary'
import ExpansionPanel from '../expansion-panel'
import Typography from '../typography'
import Accordion from './accordion'


configure({ adapter: new Adapter() })

describe('<Accordion />', () => {

    let accordion

    beforeEach(() => {

        accordion = mount(
            <Accordion>
                <ExpansionPanel>
                    <ExpansionPanelSummary>
                        <Typography>Expansion Panel 1</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <Typography>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex, sit amet blandit leo lobortis eget.</Typography>
                    </ExpansionPanelDetails>
                </ExpansionPanel>

                <ExpansionPanel disabled>
                    <ExpansionPanelSummary>
                        <Typography>Expansion Panel 2</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <Typography>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex, sit amet blandit leo lobortis eget.</Typography>
                    </ExpansionPanelDetails>
                </ExpansionPanel>

                <ExpansionPanel expanded>
                    <ExpansionPanelSummary>
                        <Typography>Expansion Panel 3</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <Typography>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex, sit amet blandit leo lobortis eget.</Typography>
                    </ExpansionPanelDetails>
                </ExpansionPanel>

                <ExpansionPanel defaultExpanded>
                    <ExpansionPanelSummary>
                        <Typography>Expansion Panel 4</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <Typography>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex, sit amet blandit leo lobortis eget.</Typography>
                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </Accordion>
        )
    })

    it('should render correctly', () => {
        expect(toJson(accordion)).toMatchSnapshot()
    })

    it('should identify the first expanded panel and update state', () => {
        expect(accordion.state().expanded).toEqual('panel-2')
    })

    it('should open a new panel and update state', () => {
        const accordionButton = accordion.find('.au-expansion-panel-summary').last()

        accordionButton.simulate('click')

        expect(accordion.state().expanded).toEqual('panel-3')
    })

    it('should close an open panel and update state', () => {
        const accordionButton = accordion.find('.au-expansion-panel-summary').first()

        accordionButton.simulate('click')
        accordionButton.simulate('click')

        expect(accordion.state().expanded).toEqual('')
    })
})
