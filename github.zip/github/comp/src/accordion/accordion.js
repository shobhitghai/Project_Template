import fp from 'lodash/fp'
import PropTypes from 'prop-types'
import React from 'react'
import AccordionChild from './accordion-child'


const map3 = fp.map.convert({ 'cap': false })

const AUAccordion = class extends React.Component {

    static displayName = 'AUAccordion'

    static defaultProps = {
        children: []
    }

    static propTypes = {
        children: PropTypes.oneOfType([
            PropTypes.element,
            PropTypes.arrayOf(PropTypes.element)
        ]).isRequired
    }

    constructor(props) {

        super(props)

        this.state = {
            expanded: this.findExpandedPanel(React.Children.toArray(props.children))
        }
    }

    findExpandedPanel(children) {

        for (let i = 0, l = fp.size(children); i < l; i++) {

            const { expanded, defaultExpanded } = children[i].props

            if (expanded || defaultExpanded) {
                return `panel-${i}`
            }
        }

        return ''
    }

    onChange = expanded => {

        this.setState({ expanded })
    }

    render() {

        return (
            <div className='au-accordion'>
                {map3(
                    (child, index) => {

                        const key = `panel-${index}`

                        return <AccordionChild {...{
                            children: child,
                            expanded: key === this.state.expanded,
                            key,
                            onChange: this.onChange,
                            panelid: key
                        }} />
                    },
                    React.Children.toArray(this.props.children)
                )}
            </div>
        )
    }
}

export default AUAccordion
