import PropTypes from 'prop-types'
import React from 'react'


const AccordionChild = class extends React.Component {

    static displayName = 'AccordionChild'

    static propTypes = {
        expanded: PropTypes.bool,
        onChange: PropTypes.func,
        panelid: PropTypes.string
    }

    onChange = () => {

        this.props.onChange(!this.props.expanded ? this.props.panelid : '')
    }

    render() {

        const { props } = this

        return React.cloneElement(
            props.children,
            { ...props, onChange: this.onChange },
            props.children.props.children
        )
    }
}

export default AccordionChild
