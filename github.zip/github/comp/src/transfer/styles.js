/* eslint-disable */
export const listStyles = theme => {
    return {
        root: {
            color: theme.palette.text.primary,
            fontFamily: theme.typography.fontFamily,
            fontSize: theme.typography.body1.fontSize,
            background: theme.palette.background.paper,
            display: 'grid',
            gridTemplateColumns: '40% 20% 40%',
            gridTemplateRows: '100%',
            width: '100%',
            height: '100%'
        },
        card: {
            height: '100%',
            display: 'flex',
            flexDirection: 'column',
            border: `1px solid ${theme.palette.divider}`
        },
        cardHeader: {
            flex: '0 1 auto',
            padding: theme.spacing(1, 2)
        },
        checkbox: {
            '&:hover': {
                background: 'none !important'
            }
        },
        divider: {
            backgroundColor: theme.palette.divider
        },
        filter: {
            flex: '0 1 auto',
            marginLeft: theme.spacing(2),
            marginRight: theme.spacing(2),

            '& label': {
                color: theme.palette.text.secondary
            },

            '& .MuiInput-underline:before': {
                borderBottomColor: theme.palette.divider
            }
        },
        itemIcon: {
            minWidth: 0,
        },
        item: {
            borderBottom: `1px solid ${theme.palette.divider}`,
            padding: 0,
            '&:hover': {
                backgroundColor: theme.palette.action.hover
            }
        },
        list: {
            flex: '1 1 auto',
            backgroundColor: theme.palette.background.paper,
            overflow: 'auto'
        },
        button: {
            color: theme.palette.text.secondary,
            margin: theme.spacing(1),
            width: theme.spacing(5),
            minWidth: theme.spacing(5),
            height: theme.spacing(5),
            '&:hover': {
                backgroundColor: theme.palette.action.hover
            }
        },
        toolbar: {
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center'
        }
    }
}
