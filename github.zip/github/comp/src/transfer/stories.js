/* eslint-disable */
import { action } from '@storybook/addon-actions'
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import jss from 'jss'
import classnames from 'classnames'
import preset from 'jss-preset-default'
import React, { useState } from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import ListItem from '@material-ui/core/ListItem'
import ListItemText from '@material-ui/core/ListItemText'
import rootWrapper from '../../stories/root-wrapper'
import { withStyles } from '../styles'
import Transfer from './transfer'


jss.setup(preset())

const styles = themes => ({
    container: { width: 800, height: 350 },
    selectedItem: {
        '& span': {
            color: themes.palette.common.white
        },
        backgroundColor: themes.palette.primary.light,
    }
})

const items = [
    {
        id: '1',
        label: 'Lorem ipsum'
    },
    {
        id: '2',
        label: 'Dolor sit'
    },
    {
        id: '3',
        label: 'Consectetuer'
    },
    {
        id: '4',
        label: 'Adipiscing elit'
    },
    {
        id: '5',
        label: 'Diam'
    },
    {
        id: '6',
        label: 'Nonummy nibh'
    },
    {
        id: '7',
        label: 'Tincidunt'
    }
]
const onChange = rightItems => action('OnChange')(rightItems)

const AuTransfer = withStyles(styles)(({ classes }) => {

    const [ value, setValue ] = useState([ '1' ])

    const onClick = newValue => () => setValue(newValue)

    return (
        <div className={classes.container}>
            <button onClick={onClick([ '3' ])}>Consectetuer</button>
            <button onClick={onClick([ '6' ])}>Nonummy nibh</button>
            <Transfer
                selectedItems={value}
                items={items}
                elevation={1}
                leftConfig={{
                    caption: 'Left',
                    filter: true
                }}
                onChange={onChange}
                rightConfig={{
                    caption: 'Right',
                    filter: true
                }}
            />
        </div>
    )
})

const AuTransferWithItemRenderer = withStyles(styles)(({ classes }) => {
    const itemRenderer = ({ item }) => {
        const id = item.origin.id
        const labelId = `transfer-list-all-item-${id}-label`

        return <ListItem key={id} className={classnames({ [classes.selectedItem]: item.checked })} >
            <ListItemText id={labelId} primary={item.origin.label} />
        </ListItem >
    }

    return (
        <div className={classes.container}>
            <Transfer
                items={items}
                elevation={1}
                leftConfig={{
                    caption: 'Left',
                    itemRenderer,
                    filter: true
                }}
                onChange={onChange}
                rightConfig={{
                    caption: 'Right',
                    itemRenderer,
                    filter: true
                }}
            />
        </div>
    )
})

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Transfer'
}

export const Basic = () => <AuTransfer />

export const ItemRenderer = () => <AuTransferWithItemRenderer />
