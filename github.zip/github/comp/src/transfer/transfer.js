import Card from '@material-ui/core/Card'
import CardHeader from '@material-ui/core/CardHeader'
import Checkbox from '@material-ui/core/Checkbox'
import Button from '@material-ui/core/Button'
import Divider from '@material-ui/core/Divider'
import ListItem from '@material-ui/core/ListItem'
import ListItemText from '@material-ui/core/ListItemText'
import ListItemIcon from '@material-ui/core/ListItemIcon'
import TextField from '@material-ui/core/TextField'
import MoveLeft from '@material-ui/icons/ChevronLeft'
import MoveRight from '@material-ui/icons/ChevronRight'
import MoveAllLeft from '@material-ui/icons/FirstPage'
import MoveAllRight from '@material-ui/icons/LastPage'
import classnames from 'classnames'
import isEmpty from 'lodash/fp/isEmpty'
import isEqual from 'lodash/fp/isEqual'
import getOr from 'lodash/fp/getOr'
import React from 'react'
import PropTypes from 'prop-types'
import { withStyles } from '../styles'
import { withTelemetry } from '../telemetry'
import VirtualList, { VirtualListCellMeasurer, VirtualListCellMeasurerCache } from '../virtual-list'
import { listStyles } from './styles'


const SIDES = {
    Left: 1,
    Right: 2
}
const matches = (text, substring) => {
    return new RegExp(substring, 'i').test(text)
}

const AUTransfer = withTelemetry(withStyles(listStyles)(class extends React.Component {

    static displayName = 'AUTransfer'

    static propTypes = {
        classes: PropTypes.shape({
            button: PropTypes.string.isRequired
        }),
        elevation: PropTypes.number,
        items: PropTypes.arrayOf(PropTypes.shape({
            id: PropTypes.string.isRequired,
            label: PropTypes.string.isRequired
        })),
        leftConfig: PropTypes.shape({
            caption: PropTypes.string.isRequired,
            filter: PropTypes.bool,
            itemRenderer: PropTypes.func
        }).isRequired,
        onChange: PropTypes.func.isRequired,
        rightConfig: PropTypes.shape({
            caption: PropTypes.string.isRequired,
            filter: PropTypes.bool,
            itemRenderer: PropTypes.func
        }).isRequired,
        selectedItems: PropTypes.arrayOf(PropTypes.string)
    }

    static defaultProps = {
        elevation: 0,
        selectedItems: []
    }

    constructor(props) {
        super(props)
        this.state = {
            filtered: 0,
            items: this.wrapItems(props.items)
        }
        this.virtualCache = {
            [SIDES.Left]: new VirtualListCellMeasurerCache({ fixedWidth: true }),
            [SIDES.Right]: new VirtualListCellMeasurerCache({ fixedWidth: true })
        }
    }

    componentDidUpdate(prevProps) {
        if (!isEqual(prevProps.items.map(item => item.id), this.props.items.map(item => item.id)) || !isEqual(prevProps.selectedItems, this.props.selectedItems)) {
            this.setState({ items: this.wrapItems(this.props.items) })
        }
    }

    wrapItems = items => items.map(current => ({
        checked: false,
        hidden: false,
        origin: current,
        side: this.props.selectedItems.includes(current.id) ? SIDES.Right : SIDES.Left
    }))

    button = (onClick, icon, disabled = false) => (
        <Button className={this.props.classes.button} disabled={disabled} variant="outlined" onClick={onClick}>
            {icon}
        </Button>
    )

    customList = ({ classes, items, side }) => {
        const { elevation } = this.props
        const { caption, filter } = this.getConfigBySide(side)
        return (
            < Card className={classes.card} elevation={elevation} >
                <CardHeader
                    className={classes.cardHeader}
                    avatar={
                        <Checkbox
                            className={classes.checkbox}
                            color="primary"
                            onClick={this.handleToggleAll(items)}
                            checked={this.numberOfChecked(items) === items.length && items.length !== 0}
                            indeterminate={this.numberOfChecked(items) !== items.length && this.numberOfChecked(items) !== 0}
                            disabled={items.length === 0}
                            inputProps={{ 'aria-label': 'all items selected' }}
                        />
                    }
                    title={caption}
                    subheader={`${this.numberOfChecked(items)}/${items.length} selected`}
                />
                <Divider className={classes.divider} />
                {filter && (
                    <div className={classes.filter}>
                        <TextField fullWidth={true} label="Filter" onChange={this.filter(side)} />
                    </div>
                )}
                <div className={classes.list}>{this.virtualListRenderer(items)}</div>
            </Card >
        )
    }

    virtualListRenderer = items => {
        // Virtual list uses shallowCompares for props due that it is not rendering on Items selection,
        // so we need to pass through additional properties to ensure changes are detected.
        const numberofCheckedItems = this.numberOfChecked(items)
        const side = getOr(SIDES.Left, '0.side', items)
        return <VirtualList
            token={items.reduce((acc, { origin: { id } }) => acc + id, '')}
            deferredMeasurementCache={this.virtualCache[side]}
            rowHeight={this.virtualCache[side].rowHeight}
            items={items}
            scrollToIndex={0}
            numberofCheckedItems={numberofCheckedItems}
            rowRenderer={this.virtualListRowRenderer}
        />
    }

    virtualListRowRenderer = ({ row, index, parent }) => {
        const { classes } = this.props
        const id = row.origin.id
        const side = row.side
        const { itemRenderer = this.defaultItemRenderer } = this.getConfigBySide(side)
        return <VirtualListCellMeasurer
            cache={this.virtualCache[side]}
            columnIndex={0}
            rowIndex={index}
            parent={parent}
        >
            <ListItem className={classes.item} role="listitem" button onClick={this.handleToggle(id)}>
                {itemRenderer({ classes, item: row })}
            </ListItem>
        </VirtualListCellMeasurer>
    }

    defaultItemRenderer = ({ classes, item }) => {
        const id = item.origin.id
        const labelId = `transfer-list-all-item-${id}-label`
        return <React.Fragment key={id} >
            <ListItemIcon className={classes.itemIcon}>
                <Checkbox
                    className={classes.checkbox}
                    color="primary"
                    checked={item.checked}
                    tabIndex={-1}
                    inputProps={{ 'aria-labelledby': labelId }}
                />
            </ListItemIcon>
            <ListItemText id={labelId} primary={item.origin.label} />
        </React.Fragment >
    }

    filter = side => event => {
        const items = this.state.items.reduce((acc, current) => [ ...acc, {
            ...current,
            hidden: current.side === side ? !matches(current.origin.label, event.currentTarget.value) : current.hidden
        } ], [])
        this.updateItems(items)
        this.setState({ filtered: !isEmpty(event.currentTarget.value) ? this.state.filtered | side : this.state.filtered ^ side })
    }

    getConfigBySide = side => SIDES.Left === side ? this.props.leftConfig : this.props.rightConfig

    getLeftItems = (all = true) => this.state.items.filter(item => item.side === SIDES.Left && (all || !item.hidden))

    getRightItems = (all = true) => this.state.items.filter(item => item.side === SIDES.Right && (all || !item.hidden))

    handleToggle = id => () => {
        const items = this.state.items.reduce((acc, current) => [ ...acc, { ...current, checked: current.origin.id === id ? !current.checked : current.checked } ], [])
        this.updateItems(items)
    }

    handleToggleAll = targetItems => () => {
        const side = targetItems[0].side
        const checked = this.numberOfChecked(targetItems) !== targetItems.length
        const items = this.state.items.reduce((acc, current) => [ ...acc, {
            ...current,
            checked: current.side === side && (!(this.state.filtered & side) || !current.hidden) ? checked : current.checked
        } ], [])
        this.updateItems(items)
    }

    moveToLeft = all => () => {
        this.moveTo(SIDES.Right, SIDES.Left, all)
    }

    moveToRight = all => () => {
        this.moveTo(SIDES.Left, SIDES.Right, all)
    }

    moveTo = (from, to, all = false) => {
        const items = this.state.items.reduce((acc, current) => [ ...acc, current.side === from && (all || current.checked) && !current.hidden ? {
            ...current,
            checked: false,
            side: to
        } : current ], [])
        this.updateItems(items)
    }

    numberOfChecked = items => items.filter(item => !!item.checked && !item.hidden).length

    updateItems = updatedItems => {
        const currentRightItems = this.getRightItems().map(item => item.origin.id)
        this.setState({ items: updatedItems }, () => {
            const newRightItems = this.getRightItems().map(item => item.origin.id)
            if (!isEqual(currentRightItems, newRightItems)) {
                this.props.onChange(newRightItems)
            }
        })
    }

    render() {

        const { props } = this
        const { className, classes } = props

        const leftItems = this.getLeftItems(false)
        const rightItems = this.getRightItems(false)

        return (
            <div className={classnames('au-transfer', classes.root, className)}>
                <div>
                    {this.customList({ classes, items: leftItems, side: SIDES.Left })}
                </div>
                <div className={classes.toolbar}>
                    {this.button(this.moveToLeft(true), <MoveAllLeft />)}
                    {this.button(this.moveToRight(false), <MoveRight />, this.numberOfChecked(leftItems).length === 0)}
                    {this.button(this.moveToLeft(false), <MoveLeft />, this.numberOfChecked(rightItems).length === 0)}
                    {this.button(this.moveToRight(true), <MoveAllRight />)}
                </div>
                <div>
                    {this.customList({ classes, items: rightItems, side: SIDES.Right })}
                </div>
            </div>
        )
    }
}))

export default AUTransfer
