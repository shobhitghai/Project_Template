export { default } from './input-label'
