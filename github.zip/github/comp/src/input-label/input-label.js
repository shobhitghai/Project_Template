import { InputLabel } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { inputLabelStyles } from './styles'


const AUInputLabel = withStyles(inputLabelStyles)(class extends React.Component {

    static displayName = 'AUInputLabel'

    static propTypes = InputLabel.propTypes

    render() {

        const { props } = this

        return (
            <InputLabel {...{
                ...props,
                className: classnames('au-input-label', props.className)
            }} />
        )
    }
})

export default AUInputLabel
