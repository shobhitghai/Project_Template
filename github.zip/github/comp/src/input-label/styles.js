/* eslint-disable */
export const inputLabelStyles = theme => {
    return {
        root: {
            fontSize: theme.typography.body2.fontSize,
            transform: 'translate(0px, 26px) scale(1)'
        },
        shrink: {
            height: theme.spacing(2.5),
            transform: 'translate(0px, 5px) scale(0.8)',
            zIndex: 1
        },
        filled: {
            fontSize: theme.typography.body2.fontSize,
            transform: `translate(${theme.spacing(2)}px, ${theme.spacing(3)}px) scale(1)`
        },
        outlined: {
            fontSize: theme.typography.body2.fontSize,
            transform: `translate(${theme.spacing(2)}px, ${theme.spacing(3)}px) scale(1)`,

            '&.MuiInputLabel-shrink': {
                transform: `translate(${theme.spacing(2)}px, -${theme.spacing(0.5)}px) scale(0.8)`
            }
        },
    }
}