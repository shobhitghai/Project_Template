import { DialogContentText } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { dialogContentTextStyles } from './styles'


const AUDialogContentText = withTelemetry(withStyles(dialogContentTextStyles)(class extends React.Component {

    static displayName = 'AUDialogContentText'

    static propTypes = DialogContentText.propTypes

    render() {

        const { props } = this

        return (
            <DialogContentText {... {
                ...props,
                className: classnames('au-dialog-content-text', props.className)
            }} />
        )
    }
}))

export default AUDialogContentText
