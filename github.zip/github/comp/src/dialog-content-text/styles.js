
/* eslint-disable */
export const dialogContentTextStyles = theme => {
    return {
        root: theme.typography.body2
    }
}

