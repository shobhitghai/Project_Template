/* eslint-disable */

export const linearStyles = theme => {
    
    return {

        root: {
            flexGrow: 1
        }
    }
}
