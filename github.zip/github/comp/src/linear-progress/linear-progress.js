import LinearProgress from '@material-ui/core/LinearProgress'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { linearStyles } from './styles.js'


const AULinearProgress = withStyles(linearStyles)(class extends React.Component {

    static displayName = 'AULinearProgress'

    static propTypes = LinearProgress.propTypes

    render() {

        const { props } = this

        return (
            <LinearProgress {...{
                ...props,
                className: classnames('au-linear-progress', props.className)
            }} />
        )
    }
})

export default AULinearProgress
