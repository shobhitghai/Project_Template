import React from 'react'
import { select, withKnobs } from '@storybook/addon-knobs'
import mdx from '../../stories/components/component-doc.mdx'
import rootWrapper from '../../stories/root-wrapper'
import LinearProgress from './linear-progress'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        }
    },
    title: 'Components|Linear Progress'
}

export const Basic = () => (
    <LinearProgress {...{
        color: select(
            'Color',
            { primary: 'primary', secondary: 'secondary' },
            'primary',
            'COLOR'
        )
    }} />
)
