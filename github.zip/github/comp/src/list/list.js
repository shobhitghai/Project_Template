import { List } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { listStyles } from './styles'


const AUList = withTelemetry(withStyles(listStyles)(class extends React.Component {

    static displayName = 'AUList'

    static propTypes = List.propTypes

    render() {

        const { props } = this

        return (
            <List {...{
                ...props,
                className: classnames('au-list', props.className)
            }}>
                { props.children }
            </List>
        )
    }
}))

export default AUList
