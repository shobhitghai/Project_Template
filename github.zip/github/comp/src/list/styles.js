/* eslint-disable */
export const listStyles = theme => {
    return {
        root: {
        }
    }
}