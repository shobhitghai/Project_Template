/* eslint-disable */
import InboxIcon from '@material-ui/icons/Inbox'
import { boolean, select, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import fp from 'lodash/fp'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import list from '../../stories/fixtures/list'
import { avatar, buttons, color, dense, disableGutters, disablePadding, divider, icons, inset, secondary } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Avatar from '../avatar'
import Checkbox from '../checkbox'
import IconButton from '../icon-button'
import ListItem from '../list-item'
import ListItemAvatar from '../list-item-avatar'
import ListItemIcon from '../list-item-icon'
import ListItemSecondaryAction from '../list-item-secondary-action'
import ListItemText from '../list-item-text'
import ListSubheader from '../list-subheader'
import Switch from '../switch'
import List from './list'


class ListControls extends React.Component {
    state = {
        checked: [0]
    }

    onToggle = key => () => {
        const { checked } = this.state
        const currentIndex = checked.indexOf(key)
        const newChecked = [...checked]

        if (currentIndex === -1) {
            newChecked.push(key)
        } else {
            newChecked.splice(currentIndex, 1)
        }

        this.setState({
            checked: newChecked
        })
    }

    render() {

        const controls = {
            primaryControls: boolean('Add checkboxes as primary control elements', false),
            secondaryControls: select(
                'Secondary controls',
                {
                    checkboxes: 'Checkboxes',
                    iconButtons: 'Icon Buttons',
                    none: 'None',
                    switches: 'Switches'
                },
                'none',
                'SECONDARYCONTROLS'
            )
        }

        const items = controls.primaryControls
            ? renderListItems(controls, this.state.checked, this.onToggle)
            : renderListItems(controls)

        return (
            <List {...{
                ...this.props,
                dense: dense(),
                disablePadding: disablePadding()
            }}>
                {items}
            </List>
        )
    }
}

const renderSecondaryControls = secondaryControls => {

    if (secondaryControls === 'iconButtons') {
        return (
            <ListItemSecondaryAction>
                <IconButton>
                    <InboxIcon />
                </IconButton>
            </ListItemSecondaryAction>
        )
    }

    if (secondaryControls === 'checkboxes') {
        return (
            <ListItemSecondaryAction>
                <Checkbox />
            </ListItemSecondaryAction>
        )
    }

    if (secondaryControls === 'switches') {
        return (
            <ListItemSecondaryAction>
                <Switch />
            </ListItemSecondaryAction>
        )
    }

    return null
}

const renderListItems = (controls, checked, onToggle = () => null) => {

    let primaryControls
    let secondaryControls

    if (controls) {
        primaryControls = controls.primaryControls
        secondaryControls = controls.secondaryControls
    }

    return (
        fp.map(item => {
            return (
                <ListItem {...{
                    button: buttons(),
                    disableGutters: disableGutters(),
                    divider: divider(),
                    key: item,
                    onClick: onToggle(item),
                    selected: false
                }}>
                    {primaryControls && (
                        <Checkbox {...{
                            checked: checked.indexOf(item) !== -1,
                            disableRipple: true,
                            tabIndex: -1
                        }} />
                    )}

                    {avatar() && (
                        <ListItemAvatar>
                            <Avatar>
                                {item.split(' ')[1]}
                            </Avatar>
                        </ListItemAvatar>
                    )}

                    {icons() && (
                        <ListItemIcon>
                            <InboxIcon />
                        </ListItemIcon>
                    )}

                    <ListItemText {...{
                        inset: inset(),
                        primary: item,
                        secondary: secondary() ? 'This is an example of secondary text' : ''
                    }} />

                    {secondaryControls && renderSecondaryControls(secondaryControls)}
                </ListItem>
            )
        })(list(100))
    )
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|List'
}

export const Basic = () =>(
    <List {...{
        dense: dense(),
        disablePadding: disablePadding()
    }}>
        {renderListItems()}
    </List>
)

export const Controls = () => <ListControls />

export const Subheader = () => (
    <List {...{
        subheader: <li />
    }}>
        {[0, 1, 2, 3, 4].map(sectionId => (
            <li key={`section-${sectionId}`}>
                <List {...{
                    subheader: <ListSubheader {...{
                        children: `List Subheader for Section ${sectionId}`,
                        color: color(),
                        inset: inset()
                    }} />
                }} >
                    {renderListItems()}
                </List>
            </li>
        ))}
    </List>
)
