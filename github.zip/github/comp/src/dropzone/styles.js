/* eslint-disable */

export const dropzoneStyles = theme => {
    return {
        root: {
            ...theme.typography.body2
        }
    }
}
