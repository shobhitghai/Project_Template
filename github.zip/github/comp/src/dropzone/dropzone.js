import Dropzone from 'react-dropzone'
import classnames from 'classnames'
import React from 'react'
import {withStyles} from '../styles/'
import {withTelemetry} from '../telemetry'
import {dropzoneStyles} from './styles'


const AUDropzone = withTelemetry(withStyles(dropzoneStyles)(class extends React.Component {

    static displayName = 'AUDropzone'

    static propTypes = Dropzone.propTypes

    render() {

        const { props } = this

        return (
            <Dropzone {...{
                ...props,
                className: classnames('au-dropzone', props.className)
            }} />
        )
    }
}))

export default AUDropzone
