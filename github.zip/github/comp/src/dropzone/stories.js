/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import rootWrapper from '../../stories/root-wrapper'
import Dropzone from './dropzone'


const onDrop = acceptedFiles => console.log('acceptedFiles: ', acceptedFiles)

const onDragEnter = event => console.log('drag entered: ', event)

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Dropzone'
}

export const Basic = () => (
    <Dropzone onDrop={onDrop} onDragEnter={onDragEnter} >
        {({ getRootProps, getInputProps, isDragAccept, isDragReject }) => {
            return (
                <div {...getRootProps()} >
                    <input {...getInputProps()} />
                    <div>{isDragAccept ? 'Drop' : 'Drag'} files here...</div>
                    {isDragReject && <div>Unsupported file type...</div>}
                </div>
            )
        }}
    </Dropzone>
)
