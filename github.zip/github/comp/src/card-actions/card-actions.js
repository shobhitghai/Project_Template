import { CardActions } from '@material-ui/core'
import classnames from 'classnames'
import React from 'react'


const AUCardActions = class extends React.Component {

    static displayName = 'AUCardActions'

    static propTypes = CardActions.propTypes

    render() {

        const { props } = this

        return (
            <CardActions {...{
                ...props,
                className: classnames('au-card-actions', props.className)
            }} />
        )
    }
}

export default AUCardActions
