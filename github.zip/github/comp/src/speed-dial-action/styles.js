/* eslint-disable */
export default theme => {
    return {
        root: {

        }
    }
}
