/* eslint-disable */
import { makeStyles } from '@material-ui/core/styles'
import SaveIcon from '@material-ui/icons/Save'
import SpeedDial from '@material-ui/lab/SpeedDial'
import SpeedDialIcon from '@material-ui/lab/SpeedDialIcon'
import { action } from '@storybook/addon-actions'
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { label, tooltipPlacement } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import SpeedDialAction from './speed-dial-action'


const onClick = action('click')

const useStyles = makeStyles(theme => ({
    speedDial: {
        left: '50%',
        position: 'absolute',
        top: '50%',

        '@global .MuiSpeedDial-fab': {
            opacity: 0.2
        }
    }
}))

const Wrapper = () => {

    const classes = useStyles()

    return (
        <SpeedDial
            ariaLabel="SpeedDial tooltip example"
            className={classes.speedDial}
            icon={<SpeedDialIcon />}
            open={true}
        >
            <SpeedDialAction
                key="SpeedDialAction"
                icon={<SaveIcon />}
                onClick={onClick}
                tooltipTitle={label()}
                tooltipOpen={true}
                tooltipPlacement={tooltipPlacement()}
                value="SpeedDialAction value"
            />
        </SpeedDial>
    )
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Speed Dial Action'
}

export const Basic = () => <Wrapper />
