/* eslint-disable */
import SpeedDialAction from '@material-ui/lab/SpeedDialAction'
import classnames from 'classnames'
import isFunction from 'lodash/fp/isFunction'
import PropTypes from 'prop-types'
import React from 'react'
import { withTelemetry } from '../telemetry'


const AUSpeedDialAction = withTelemetry(class extends React.Component {

    static displayName = 'AUSpeedDialAction'

    static defaultProps = {
        value: ''
    }

    static propTypes = {
        ...SpeedDialAction.propTypes,
        value: PropTypes.any
    }

    onClick = e => {

        const { props } = this

        isFunction(props.onClick) && props.onClick(e, props.value)
    }

    render() {

        const { props } = this

        return (
            <SpeedDialAction
                className={classnames('au-speed-dial-action', props.className)}
                {...props}
                onClick={this.onClick}
            />
        )
    }
})

export default AUSpeedDialAction
