/* eslint-disable */
export const listItemStyles = theme => {
    return {
        root: {
            ...theme.typography.body2,
            boxSizing: 'border-box',
            minHeight: theme.spacing(4),
            // Padding adjusted to allow for body1 line height and border bottom
            padding: `${theme.spacing(6 / 8)}px 0 ${theme.spacing(6 / 8) - 1}px`
        },
        dense: {
            minHeight: theme.spacing(3),
            padding: `${theme.spacing(2 / 8)}px ${theme.spacing(1)}px ${theme.spacing(2 / 8) - 1}px`
        },
        gutters: {
            paddingLeft: theme.spacing(2),
            paddingRight: theme.spacing(2)
        },

        noDivider: {
            // Transparent border bottom required to maintain 8-point grid when larger items (e.g. avatars) added to list item
            borderBottom: '1px solid transparent',
        }
    }
}
