import { ListItem } from '@material-ui/core/'
import { makeStyles } from '@material-ui/core/styles'
import classnames from 'classnames'
import merge from 'lodash/fp/merge'
import React, { forwardRef } from 'react'
import { withTelemetry } from '../telemetry'
import { listItemStyles } from './styles'


const useStyles = makeStyles(listItemStyles)

const AUListItem = withTelemetry(forwardRef(({ classes, ...other }, ref) => {

    const defaultStyles = useStyles()

    const { noDivider, ...nativeClasses } = defaultStyles

    return (
        <ListItem {... {
            ...other,
            classes: merge(nativeClasses, classes),
            className: classnames('au-list-item', other.className, { noDivider: !other.divider }),
            ref
        }} />
    )
}))

AUListItem.displayName = 'AUListItem'

AUListItem.propTypes = ListItem.propTypes

export default AUListItem
