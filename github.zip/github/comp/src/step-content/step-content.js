import { StepContent } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { stepContentStyles } from './styles'


const AUStepContent = withStyles(stepContentStyles)(class extends React.Component {

    static displayName = 'AUStepContent'

    render() {

        const { props } = this

        return (
            <StepContent {...{
                ...props,
                className: classnames('au-step-content', props.className)
            }} />
        )
    }
})

export default AUStepContent
