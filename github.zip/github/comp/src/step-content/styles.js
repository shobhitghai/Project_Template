/* eslint-disable */
export const stepContentStyles = theme => {
    return {
        root: {
            borderLeft: 'none'
        }
    }
}
