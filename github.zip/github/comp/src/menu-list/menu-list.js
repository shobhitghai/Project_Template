import { MenuList } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { menuListStyles } from './styles'


const AUMenuList = withTelemetry(withStyles(menuListStyles)(class extends React.Component {

    static displayName = 'AUMenuList'

    static propTypes = MenuList.propTypes

    render() {

        const { props } = this

        return (
            <MenuList {... {
                ...props,
                className: classnames('au-menu-list', props.className)
            }} />
        )
    }
}))

export default AUMenuList
