import classnames from 'classnames'
import jss from 'jss'
import preset from 'jss-preset-default'
import { menuListStyles } from './styles'


jss.setup(preset())

const styles = {
    menuList: menuListStyles().root
}

const { classes } = jss.createStyleSheet(styles).attach()

export default {
    MenuListProps: {
        className: classnames('au-menu-list', classes.menuList)
    },
    PopoverClasses: {
        paper: classnames('au-paper')
    }
}
