/* eslint-disable */
export const menuListStyles = theme => {
    return {
        root: {
            padding: 0
        }
    }
}
