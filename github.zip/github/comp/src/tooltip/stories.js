/* eslint-disable */
import { select, withKnobs } from '@storybook/addon-knobs'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { title } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Button from '../button'
import Tooltip from './tooltip'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Tooltip'
}

export const Basic = () => (
    <Tooltip {...{
        placement: select(
            'Placement',
            {
                'bottom': 'bottom',
                'bottom-end': 'bottom-end',
                'bottom-start': 'bottom-start',
                'left': 'left',
                'left-end': 'left-end',
                'left-start': 'left-start',
                'right': 'right',
                'right-end': 'right-end',
                'right-start': 'right-start',
                'top': 'top',
                'top-end': 'top-end',
                'top-start': 'top-start'
            },
            'bottom',
            'PLACEMENT'
        ),
        title: title()
    }}>
        <Button children='Hover Here' size='large' />
    </Tooltip>
)
