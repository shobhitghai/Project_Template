/* eslint-disable */
export const tooltipStyles = theme => {
    return {
        popper: {
            zoom: theme.zoom
        },
        tooltip: {
            fontSize: theme.typography.body2.fontSize
        }
    }
}
