import { Tooltip } from '@material-ui/core/'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { tooltipStyles } from './styles'


const AUTooltip = withTelemetry(withStyles(tooltipStyles)(class extends React.Component {

    static displayName = 'AUTooltip'

    static propTypes = Tooltip.propTypes

    render() {
        const { props } = this

        return (
            <Tooltip {... {
                ...props
                // @TODO className currently throwing an error following update to latest Material UI
                // className: classnames('au-tooltip', props.className)
            }}/>
        )
    }
}))

export default AUTooltip
