import { Avatar } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { avatarStyles } from './styles'


const AUAvatar = withTelemetry(withStyles(avatarStyles)(class extends React.Component {

    static displayName = 'AUAvatar'

    static propTypes = Avatar.propTypes

    render() {

        const { props } = this

        return (
            <Avatar {... {
                ...props,
                className: classnames('au-avatar', props.className)
            }} />
        )
    }
}))

export default AUAvatar
