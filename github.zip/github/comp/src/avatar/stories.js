import FolderIcon from '@material-ui/icons/Folder'
import { text, withKnobs } from '@storybook/addon-knobs'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { alt } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Avatar from './avatar'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        }
    },
    title: 'Components|Avatar'
}

export const AvatarWithIcon = () => (
    <Avatar>
        <FolderIcon />
    </Avatar>
)

export const AvatarWithImage = () => (
    <Avatar {...{
        alt: alt(),
        src: text(
            'src',
            'https://www.rbcroyalbank.com/dvl/v1.0/assets/images/logos/rbc-logo-shield.svg'
        )
    }} />
)

export const AvatarWithInitials = () => (
    <Avatar>
        R
    </Avatar>
)
