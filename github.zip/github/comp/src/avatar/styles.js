/* eslint-disable */
export const avatarStyles = theme => {
    return {
        root: {
            fontSize: theme.typography.body2.fontSize,
            height: theme.spacing(3),
            width: theme.spacing(3),

            '& > svg': {
                fontSize: theme.typography.body2.fontSize
            }
        },
    }
}
