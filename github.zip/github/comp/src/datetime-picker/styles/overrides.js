/* eslint-disable */
import { inputStyles } from '../../input/styles'
import { inputLabelStyles } from '../../input-label/styles'


const transparentBackground = {
    backgroundColor: 'transparent'
}

export default theme => (
    {
        
        MuiInput: {
            ...inputStyles(theme),
            root: {
                fontSize: theme.typography.body2.fontSize
            }
        },
        MuiInputLabel: {
            ...inputLabelStyles(theme)
        },
        MuiPickersArrowSwitcher: {
            iconButton: {
                padding: 0,

                '&:hover': {
                    ...transparentBackground
                }
            }
        },
        MuiPickersBasePicker: {
            pickerView: {
                width: theme.spacing(20) + 55
            },
        },
        MuiPickersCalendarHeader: {
            
            monthText: {
                ...theme.typography.body2
            },
            monthTitleContainer: {
                alignItems: 'center'
            },
            previousMonthButton: {
                marginRight: 0
            },
            switchHeader: {
                alignItems: 'baseline',
                marginBottom: 0,
                paddingLeft: theme.spacing(2),
                paddingRight: theme.spacing(1),
            },
            yearSelectionSwitcher: {
                '&:focus': {
                    ...transparentBackground
                },
                '&:hover': {
                    ...transparentBackground
                }
            }
        },
        MuiPickersCalendarView: {
            viewTransitionContainer: {
                height: theme.spacing(20) + 40,
                paddingLeft: theme.spacing(1),
                paddingRight: theme.spacing(1)
            }
        },
        MuiPickersClock: {
            container: {
                height: 246,
                minHeight: 246
            },
            clock: {
                minWidth: 260,
                transform: 'scale(0.7)',

                '& p': {
                    transform: 'scale(1.3)'
                },
            },
            amButton: {
                '&:hover': {
                    ...transparentBackground
                }
            },
            pmButton: {
                '&:hover': {
                    ...transparentBackground
                }
            },
        },
        MuiPickersClockPointer: {
            thumb: {
                top: -22
            }
        },
        MuiPickersDay: {
            day: {
                height: theme.spacing(3),

                '&:focus': {
                    ...transparentBackground
                },
                '&:hover': {
                    ...transparentBackground
                }
            }
        },
        MuiPickerDTToolbar: {
            penIcon: {
                '&:hover': {
                    ...transparentBackground
                }
            }
        },
        MuiPickersSlideTransition: {
            transitionContainer: {
                height: theme.spacing(20),
                minHeight: [ [ theme.spacing(20) ], '!important' ]
            }
        },
        MuiPickersToolbarButton: {
            toolbarBtn: {
                '&:hover': {
                    ...transparentBackground
                }
            }
        },
        MuiPickersYear: {
            yearButton: {
                fontSize: theme.typography.body2.fontSize,
                height: theme.spacing(3),
                width: theme.spacing(7),

                '&:focus': {
                    ...transparentBackground
                },
                '&:hover': {
                    ...transparentBackground
                }
            }
        },
        MuiTabs: {
            root: {
                minHeight: theme.spacing(4)
            }
        },
        MuiTab: {
            root: {
                minHeight: theme.spacing(4),
                '@media (min-width: 600px)': {
                    minWidth: 'unset'
                }
            }
        },
        MuiTypography: {
            subtitle1: {
                ...theme.typography.body2
            }
        }
    }
)