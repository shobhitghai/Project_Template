import { makeStyles, createMuiTheme, ThemeProvider } from '@material-ui/core/styles'
import { DateTimePicker, DesktopDateTimePicker, MobileDateTimePicker, LocalizationProvider } from '@material-ui/pickers'
import DateFnsAdapter from '@material-ui/pickers/adapter/date-fns'
import classnames from 'classnames'
import isEqual from 'date-fns/isEqual'
import PropTypes from 'prop-types'
import React, { useCallback, useEffect, useState } from 'react'
import merge from 'lodash/fp/merge'
import { withTelemetry } from '../telemetry'
import datetimePickerStyles from './styles/datetime-picker'
import iconStyles from './styles/icon'
import overrides from './styles/overrides'


const devices = {
    DESKTOP: 'desktop',
    MOBILE: 'mobile'
}
const datetimePickers = new Map([
    [ devices.DESKTOP, DesktopDateTimePicker ],
    [ devices.MOBILE, MobileDateTimePicker ]
])

const useDatePickerStyles = makeStyles(datetimePickerStyles)
const useIconStyles = makeStyles(iconStyles)

const getDatetimePickerTheme = theme => {

    const datetimePickerOverrides = overrides(theme)

    const { overrides: currentOverrides, ...rest } = theme

    const updatedOverrides = {
        overrides: {
            ...currentOverrides,
            ...datetimePickerOverrides
        }
    }

    return createMuiTheme({ ...updatedOverrides, ...rest })

}

const AUDateTimePicker = withTelemetry(props => {

    const { className, classes, device, onChange: propsOnChange, value, ...other } = props

    const [ selectedDate, setSelectedDate ] = useState(value)

    const onChange = useCallback(date => {
        setSelectedDate(date)
        propsOnChange && propsOnChange(date)
    })

    const defaultDatetimePickerStyles = useDatePickerStyles()
    const defaultIconStyles = useIconStyles()

    useEffect(_ => {
        !isEqual(value, selectedDate) && setSelectedDate(value)
    }, [ value ])

    const DTP = datetimePickers.get(device) || DesktopDateTimePicker

    return (
        <ThemeProvider theme={getDatetimePickerTheme}>
            <LocalizationProvider dateAdapter={DateFnsAdapter}>
                <DTP {...{
                    autoOk: true,
                    classes: merge(defaultDatetimePickerStyles, classes),
                    className: classnames('au-datetime-picker', className),
                    hideTabs: true,
                    KeyboardButtonProps: {
                        classes: {
                            root: defaultIconStyles.root
                        }
                    },
                    label: 'Date/Time',
                    onChange,
                    value: selectedDate,
                    ...other
                }} />
            </LocalizationProvider>
        </ThemeProvider>
    )
})


AUDateTimePicker.displayName = 'AUDatePicker2'
AUDateTimePicker.propTypes = {
    ...DateTimePicker.propTypes,
    device: PropTypes.oneOf([ devices.DESKTOP, devices.MOBILE ])
}

export default AUDateTimePicker
