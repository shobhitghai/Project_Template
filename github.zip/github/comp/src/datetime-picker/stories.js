/* eslint-disable */
import { action } from '@storybook/addon-actions'
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React, { useState } from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import DateTimePicker from './datetime-picker'
import Typography from '../typography'
import rootWrapper from '../../stories/root-wrapper'


const Component = _ => {

    const [ value, setValue ] = useState(null)
            
    const onChange = date => action('Change')(date)

    const onClick = date => _ => setValue(date)

    return (
        <React.Fragment>
            <Typography variant='subtitle1'>DATETIME PICKER EXAMPLE</Typography>
            <div>
                <button onClick={onClick(new Date('03/03/2020'))}>March</button>
                <button onClick={onClick(new Date('04/04/2020'))}>April</button>
                <button onClick={onClick(new Date('05/05/2020'))}>May</button>
            </div>
            <DateTimePicker {...{
                onChange,
                value,
            }}/>
        </React.Fragment>
    )
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|DateTime Picker'
}

export const Basic = () => <Component />
