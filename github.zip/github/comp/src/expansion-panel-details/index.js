export { default } from './expansion-panel-details'
