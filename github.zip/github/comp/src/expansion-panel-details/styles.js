/* eslint-disable */
export const expansionPanelDetailsStyles = theme => {
    return {
        root: {
            padding: `${theme.spacing(2)}px`
        }
    }
}
