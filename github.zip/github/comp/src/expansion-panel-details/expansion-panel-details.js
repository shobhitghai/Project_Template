import { ExpansionPanelDetails } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { expansionPanelDetailsStyles } from './styles'


const AUExpansionPanelDetails = withTelemetry(withStyles(expansionPanelDetailsStyles)(class extends React.Component {

    static displayName = 'AUExpansionPanelDetails'

    static propTypes = ExpansionPanelDetails.propTypes

    render() {

        const { props } = this

        return (
            <ExpansionPanelDetails {...{
                ...props,
                className: classnames('au-expansion-panel-details', props.className)
            }} />
        )
    }
}))

export default AUExpansionPanelDetails
