import { withKnobs } from '@storybook/addon-knobs'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { checked, disabled } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Switch from './switch'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        }
    },
    title: 'Components|Switch'
}

export const Basic = () => (
    <Switch {...{
        checked: checked(),
        disabled: disabled()
    }} />
)
