export { default } from './switch'
