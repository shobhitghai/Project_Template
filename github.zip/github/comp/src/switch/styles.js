/* eslint-disable */

export const switchStyles = () => {
    return {
        disabled: {
            '& $icon': {
                boxShadow: 'none'
            }
        }
    }
}
