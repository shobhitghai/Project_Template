import { Switch } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { switchStyles } from './styles'


const AUSwitch = withTelemetry(withStyles(switchStyles)(class extends React.Component {

    static displayName = 'AUSwitch'

    static defaultProps = {
        color: 'primary'
    }

    static propTypes = Switch.proptypes

    render() {

        const { props } = this

        return (
            <Switch {...{
                ...props,
                className: classnames('au-switch', props.className),
                disableRipple: true
            }} />
        )
    }
}))

export default AUSwitch
