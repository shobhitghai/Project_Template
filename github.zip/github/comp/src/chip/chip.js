import { Chip } from '@material-ui/core'
import CancelIcon from '@material-ui/icons/Cancel'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { chipStyles } from './styles'


const AUChip = withTelemetry(withStyles(chipStyles)(class extends React.Component {

    static displayName = 'AUChip'

    static muiName = 'Chip'

    static propTypes = Chip.propTypes

    static defaultProps = {
        deleteIcon: <CancelIcon />
    }

    render() {

        const { props } = this

        return (
            <Chip {...{
                ...props,
                className: classnames('au-chip', props.className)
            }} />
        )
    }
}))

export default AUChip
