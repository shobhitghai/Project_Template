/* eslint-disable */
import { action } from '@storybook/addon-actions'
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { clickable, label } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Chip from './chip'


const onClick = e => action('click')(e)
const onDelete = e => action('delete')(e)

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Chip'
}

export const Basic = () => (
    <Chip {...{
        clickable: clickable(),
        label: label()
    }} />
)

export const ChipDeletable = () => (
    <Chip {...{
        label: label(),
        onClick,
        onDelete
    }} />
)
