/* eslint-disable */
export const chipStyles = theme => {

    const DEFAULT_PADDING_HEIGHT = theme.spacing(3)

    return {
        root: {
            borderRadius: theme.spacing(0.25),
            height: DEFAULT_PADDING_HEIGHT,
            padding: `0 ${theme.spacing(1)}px`
        },
        label: {
            ...theme.typography.body1,
            lineHeight: `${DEFAULT_PADDING_HEIGHT}px`,
            padding: 0
        },
        deleteIcon: {
            ...theme.typography.body2,
            lineHeight: `${DEFAULT_PADDING_HEIGHT}px`,
            marginLeft: `${theme.spacing(1)}px`,
            marginRight: 0
        }
    }
}
