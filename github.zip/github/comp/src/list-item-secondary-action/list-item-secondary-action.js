import { ListItemSecondaryAction } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'


const AUListItemSecondaryAction = class extends React.Component {

    static displayName = 'AUListItemSecondaryAction'

    // Declaring muiName (using the same name as the original Material UI component) essential for ListItem to detect its presence
    static muiName = 'ListItemSecondaryAction'

    static propTypes = ListItemSecondaryAction.propTypes

    render() {

        const { props } = this

        return (
            <ListItemSecondaryAction {... {
                ...props,
                className: classnames('au-list-item-secondary-action', props.className)
            }} />
        )
    }
}

export default AUListItemSecondaryAction
