export { default } from './table-head'
