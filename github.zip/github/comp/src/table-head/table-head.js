import { TableHead } from '@material-ui/core'
import classnames from 'classnames'
import React from 'react'
import { withTelemetry } from '../telemetry'


export default withTelemetry(class extends React.Component {

    static displayName = 'AUTableHead'

    static propTypes = TableHead.propTypes

    render() {

        const { props } = this

        return (
            <TableHead {...{
                ...props,
                className: classnames('au-table-head', props.className)
            }} />
        )
    }
})
