export { default } from './alert-title'
