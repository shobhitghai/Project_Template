import AlertTitle from '@material-ui/lab/AlertTitle'
import { makeStyles } from '@material-ui/core/styles'
import classnames from 'classnames'
import merge from 'lodash/fp/merge'
import React from 'react'
import { withTelemetry } from '../telemetry'
import styles from './styles'


const useStyles = makeStyles(styles)

const AUAlertTitle = withTelemetry(React.forwardRef(({ classes, ...other }, ref) => {

    const defaultStyles = useStyles()

    return (
        <AlertTitle {...{
            ...other,
            classes: merge(defaultStyles, classes),
            className: classnames('au-alert-title', other.className),
            ref
        }} />
    )
}))

AUAlertTitle.displayName = 'AUAlertTitle'
AUAlertTitle.propTypes = AlertTitle.propTypes

export default AUAlertTitle
