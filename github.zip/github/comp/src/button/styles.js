/* eslint-disable */

export const buttonStyles = theme => {

    const rectangular = {
        height: theme.spacing(3),
        margin: 0,
        padding: `1px ${theme.spacing(2)}px 0`
    }

    return {
        root: {
            fontSize: theme.typography.button.fontSize,
            lineHeight: `${theme.spacing(2)}px`,
            minHeight: 'auto',
            minWidth: 'auto',

            '& .icon': {
                fontSize: theme.spacing(2)
            },

            '& .iconLeft': {
                marginRight: theme.spacing(1)
            },

            '& .iconRight': {
                marginLeft: theme.spacing(1)
            }
        },

        text: {
            ...rectangular
        },

        outlined: {
            ...rectangular
        },
        contained: {
            ...rectangular,
            boxShadow: 'none',

            '&:hover': {
                boxShadow: 'none'
            }
        },
        sizeSmall: {
            fontSize: theme.typography.button.fontSize - 2,
            lineHeight: `${theme.typography.body2.fontSize * 0.75}px`,
            height: theme.spacing(2),
            paddingLeft: theme.spacing(1),
            paddingRight: theme.spacing(1),
            paddingTop: `${theme.spacing(1) === 4 ? 0 : 1}px`,

            '& .icon': {
                fontSize: theme.typography.button.fontSize - 2
            },
        },
        sizeLarge: {
            height: theme.spacing(4),
            paddingRight: theme.spacing(2),
            paddingLeft: theme.spacing(2),
        }
    }
}
