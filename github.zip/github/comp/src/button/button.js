import Button from '@material-ui/core/Button'
import PropTypes from 'prop-types'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { buttonStyles } from './styles'


const AUButton = props => {
    return (
        <Button {...{
            ...props,
            className: classnames('au-button', props.className, {
                'au-button-primary': props.color === 'primary'
            })
        }} />
    )
}

AUButton.displayName = 'AUButton'

AUButton.defaultProps = {
    color: 'primary',
    disabled: false,
    variant: 'contained'
}

AUButton.propTypes = {
    ...Button.propTypes,
    color: PropTypes.string
}

export default withTelemetry(withStyles(buttonStyles)(AUButton))
