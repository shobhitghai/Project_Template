/* eslint-disable */
import Delete from '@material-ui/icons/Delete'
import { action } from '@storybook/addon-actions'
import { withKnobs } from '@storybook/addon-knobs'
import React from 'react'
import { color, disabled, label, size, variant } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Button from './button'
import mdx from '../../stories/components/component-doc.mdx'

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Button'
}

const onClick = action('click')

/* eslint-disable */
export const Basic = () => (
    <Button {...{
        children: label(),
        color: color(),
        disabled: disabled(),
        onClick,
        size: size(),
        variant: variant()
    }} />
)
export const ButtonWithLeftIcon = () => (
    <Button {...{
        color: color(),
        disabled: disabled(),
        onClick,
        size: size(),
        variant: variant()
    }}>
        <Delete className='icon iconLeft' />
        {label()}
    </Button>
)
export const ButtonWithRightIcon = () => (
    <Button {...{
        color: color(),
        disabled: disabled(),
        onClick,
        size: size(),
        variant: variant()
    }}>
        {label()}
        <Delete className='icon iconRight' />
    </Button>
)
