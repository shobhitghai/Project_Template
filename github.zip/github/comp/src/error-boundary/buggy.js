import React from 'react'


export default class extends React.Component {

    static displayName = 'ErrorBoundary.Buggy'

    constructor(props) {
        super(props)
        this.state = {
            crashed: false
        }
    }

    onClicked = () => {
        this.setState({ crashed: true })
    }

    render() {

        if (this.state.crashed) {
            throw new Error('I crashed!')
        }

        return (
            <div>
                <button onClick={this.onClicked}>Click me to crash</button>
            </div>
        )
    }
}
