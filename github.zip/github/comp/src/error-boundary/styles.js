/* eslint-disable */


export default theme => {

    return {

        root: {
            width: 'inherit',
            height: 'inherit'
        }
    }
}
