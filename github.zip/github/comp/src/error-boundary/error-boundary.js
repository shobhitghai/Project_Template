import isFunction from 'lodash/fp/isFunction'
import PropTypes from 'prop-types'
import React from 'react'
import Dialog from '../dialog'
import DialogContent from '../dialog-content'
import DialogTitle from '../dialog-title'
import { withStyles } from '../styles'
import styles from './styles'


const ErrorBoundary = withStyles(styles)(class extends React.Component {

    static displayName = 'ErrorBoundary'

    static propTypes = {
        onError: PropTypes.func
    }

    state = {
        err: null,
        info: null
    }

    componentDidCatch(err, info) {

        this.setState({ err, info })

        if (isFunction(this.props.onError)) {

            this.props.onError(err)
        }
    }

    render() {

        const { props, state } = this

        if (state.err) {

            return (
                <Dialog open={true}>
                    <DialogTitle>Something went wrong</DialogTitle>
                    <DialogContent>
                        {String(state.err)}
                        <div style={{ whiteSpace: 'pre-wrap' }}>
                            {state.info.componentStack}
                        </div>
                    </DialogContent>
                </Dialog>
            )
        }

        return props.children
    }
})

export const withErrorBoundary = Component => class extends React.Component {

    static displayName = 'withErrorBoundary'

    static propTypes = {
        onError: PropTypes.func
    }

    render() {

        const { onError, ...rest } = this.props

        return (
            <ErrorBoundary onError={onError}>
                <Component {...rest} />
            </ErrorBoundary>
        )
    }
}

export default ErrorBoundary
