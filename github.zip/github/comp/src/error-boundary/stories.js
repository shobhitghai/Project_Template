import { withKnobs } from '@storybook/addon-knobs'
import PropTypes from 'prop-types'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import rootWrapper from '../../stories/root-wrapper'
import ErrorBoundary from './'


class Buggy extends React.Component {

    static defaultProps = {
        throwError: false
    }

    static propTypes = {
        throwError: PropTypes.bool
    }

    render() {

        if (this.props.throwError) {
            throw new Error('I crashed!')
        }

        return (
            <div>Buggy</div>
        )
    }
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        }
    },
    title: 'Components|Error Boundary'
}

export const Basic = () => (
    <ErrorBoundary>
        <Buggy throwError={false} />
    </ErrorBoundary>
)
