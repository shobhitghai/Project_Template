/* eslint-disable */
export default {
    "displayName": "MenuItem",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Menu item contents."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "dense": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, compact vertical padding designed for keyboard and mouse input will be used."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "disableGutters": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the left and right padding is removed."
        },
        "role": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "selected": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "tabIndex": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "@ignore"
        }
    }
}