/* eslint-disable */
export default {
    "displayName": "Button",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "The content of the button."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'default'",
                        "computed": false
                    },
                    {
                        "value": "'inherit'",
                        "computed": false
                    },
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the button will be disabled."
        },
        "disableElevation": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, no elevation is used."
        },
        "disableFocusRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the  keyboard focus ripple will be disabled.\r\n`disableRipple` must also be true."
        },
        "disableRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the ripple effect will be disabled.\r\n\n⚠️ Without a ripple there is no styling for :focus-visible by default. Be sure\r\nto highlight the element by applying separate styles with the `focusVisibleClassName`."
        },
        "endIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Element placed after the children."
        },
        "focusVisibleClassName": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "fullWidth": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the button will take up the full width of its container."
        },
        "href": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The URL to link to when the button is clicked.\r\nIf defined, an `a` element will be used as the root node."
        },
        "size": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'small'",
                        "computed": false
                    },
                    {
                        "value": "'medium'",
                        "computed": false
                    },
                    {
                        "value": "'large'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The size of the button.\r\n`small` is equivalent to the dense button styling."
        },
        "startIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Element placed before the children."
        },
        "type": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'text'",
                        "computed": false
                    },
                    {
                        "value": "'outlined'",
                        "computed": false
                    },
                    {
                        "value": "'contained'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}