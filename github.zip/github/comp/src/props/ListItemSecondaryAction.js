/* eslint-disable */
export default {
    "displayName": "ListItemSecondaryAction",
    "description": "Must be used as the last child of ListItem to function properly.",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component, normally an `IconButton` or selection control."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        }
    }
}