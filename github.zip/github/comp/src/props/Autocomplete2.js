/* eslint-disable */
export default {
    "fileName": "autocomplete2",
    "description": "",
    "methods": [
        {
            "name": "clearSearch",
            "docblock": null,
            "modifiers": [],
            "params": [],
            "returns": null
        },
        {
            "name": "onChange",
            "docblock": null,
            "modifiers": [],
            "params": [
                {
                    "name": "selectedItem",
                    "type": null
                }
            ],
            "returns": null
        },
        {
            "name": "onCloseMenu",
            "docblock": null,
            "modifiers": [],
            "params": [],
            "returns": null
        },
        {
            "name": "onStateChange",
            "docblock": null,
            "modifiers": [],
            "params": [
                {
                    "name": "{ selectedItem }",
                    "type": null
                }
            ],
            "returns": null
        }
    ],
    "props": {
        "inputFormatter": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when a item is selected. Should return a string which will be input's value.\n@param {object} selected item\n@return {string} string which will be input's value",
            "defaultValue": {
                "value": "getOr('', 'value')",
                "computed": true
            }
        },
        "itemFormatter": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when an item is selected or when the list of items changes.\nThis can be usefull if you want to provide a custom list of items (by default is assuming that items are `[{value: 'some value', ...}]`)\n\n@param {object}\n@return {string} string to be printed",
            "defaultValue": {
                "value": "getOr('', 'value')",
                "computed": true
            }
        },
        "itemHeight": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Height in pixels to each row/item"
        },
        "items": {
            "type": {
                "name": "array"
            },
            "required": false,
            "description": "List of items to be printed. By default is assuming [{value: 'some value', ...}, ...].\nIf you want to provide a different structure you might need to use `itemFormatter` and `itemsFilter`.",
            "defaultValue": {
                "value": "[]",
                "computed": false
            }
        },
        "itemsFilter": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when component needs to filter items to be shown.\n@param {array} list of items\n@param {string} search text\n@return {array} list of items to be printed",
            "defaultValue": {
                "value": "(items, search = '') => {\n    const regEx = escapeRegExp(search)\n    return items.filter(item => regEx.test(item.value))\n}",
                "computed": false
            }
        },
        "maxItemsToShow": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Maximum number of items to show"
        },
        "multi": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Enable multi selection of items",
            "defaultValue": {
                "value": "false",
                "computed": false
            }
        },
        "onSelect": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when an item is selected\n\n@param {object} items/item selected from items list provided through props",
            "defaultValue": {
                "value": "noop",
                "computed": true
            }
        },
        "selectedItems": {
            "type": {
                "name": "arrayOf",
                "value": [{
                    "name": "shape",
                    "value": {
                        "value": {
                            "name": "string",
                            "required": false
                        }
                    }
                }]
            },
            "required": false,
            "description": "Selected items/item",
            "defaultValue": {
                "value": "[]",
                "computed": false
            }
        },
        "showDropdownIcon": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "show/hide dropdown icon",
            "defaultValue": {
                "value": "true",
                "computed": false
            }
        },
        "usePopper": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Whether the drop down should be wrapped in a Popper.\nUsing a Popper inside a cell in the AuraGrid can lead to problems with event handling.",
            "defaultValue": {
                "value": "true",
                "computed": false
            }
        },
        "TextFieldProps": {
            "type": {
                "name": "object"
            },
            "defaultValue": {
                "value": "{ InputLabelProps: {}, InputProps: {} }",
                "computed": false
            },
            "required": false
        }
    },
    "composes": [
        "../text-field"
    ]
}