/* eslint-disable */
export default {
    "displayName": "TableRow",
    "description": "Will automatically set dynamic row height\r\nbased on the material table element parent (head, body, etc).",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Should be valid <tr> children such as `TableCell`."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "hover": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the table row will shade on hover."
        },
        "selected": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the table row will have the selected shading."
        }
    }
}