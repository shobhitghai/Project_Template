/* eslint-disable */
export default {
    "fileName": "autocomplete",
    "description": "",
    "methods": [
        {
            "name": "renderMenuItems",
            "docblock": null,
            "modifiers": [],
            "params": [
                {
                    "name": "options",
                    "type": null
                }
            ],
            "returns": null
        },
        {
            "name": "renderMenuItem",
            "docblock": null,
            "modifiers": [],
            "params": [
                {
                    "name": "item",
                    "type": null
                },
                {
                    "name": "index",
                    "type": null
                },
                {
                    "name": "options",
                    "type": null
                }
            ],
            "returns": null
        },
        {
            "name": "inputProps",
            "docblock": null,
            "modifiers": [],
            "params": [
                {
                    "name": "options",
                    "type": null
                }
            ],
            "returns": null
        },
        {
            "name": "renderAutoComplete",
            "docblock": null,
            "modifiers": [],
            "params": [
                {
                    "name": "options",
                    "type": null
                }
            ],
            "returns": null
        }
    ],
    "props": {
        "displayTemplate": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "element"
                    },
                    {
                        "name": "func"
                    }
                ]
            },
            "required": false,
            "description": ""
        },
        "inputDisplayTemplate": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "",
            "defaultValue": {
                "value": "item => item ? item.toString() : undefined",
                "computed": false
            }
        },
        "items": {
            "type": {
                "name": "arrayOf",
                "value": [{
                    "name": "object"
                }]
            },
            "required": false,
            "description": "",
            "defaultValue": {
                "value": "[]",
                "computed": false
            }
        },
        "onInputValueChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": ""
        },
        "paperProps": {
            "type": {
                "name": "shape"
            },
            "required": false,
            "description": "",
            "defaultValue": {
                "value": "{ elevation: 5 }",
                "computed": false
            }
        },
        "searchTemplate": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": ""
        },
        "toggleOnClick": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "",
            "defaultValue": {
                "value": "false",
                "computed": false
            }
        },
        "value": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "string"
                    },
                    {
                        "name": "object"
                    }
                ]
            },
            "required": false,
            "description": ""
        }
    },
    "composes": [
        "../text-field"
    ]
}