/* eslint-disable */
export default {
    "displayName": "RootRef",
    "description": "⚠️⚠️⚠️\r\nIf you want the DOM element of a Material-UI component check out\r\n[FAQ: How can I access the DOM element?](/getting-started/faq/#how-can-i-access-the-dom-element)\r\nfirst.\r\n\nThis component uses `findDOMNode` which is deprecated in React.StrictMode.\r\n\nHelper component to allow attaching a ref to a\r\nwrapped element to access the underlying DOM element.\r\n\nIt's highly inspired by https://github.com/facebook/react/issues/11401#issuecomment-340543801.\r\nFor example:\r\n```jsx\r\nimport React from 'react';\r\nimport RootRef from '@material-ui/core/RootRef';\r\n\nfunction MyComponent() {\r\n  const domRef = React.useRef();\r\n\n  React.useEffect(() => {\r\n    console.log(domRef.current); // DOM node\r\n  }, []);\r\n\n  return (\r\n    <RootRef rootRef={domRef}>\r\n      <SomeChildComponent />\r\n    </RootRef>\r\n  );\r\n}\r\n```",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "element"
            },
            "required": true,
            "description": "The wrapped element."
        },
        "rootRef": {
            "type": {
                "name": "custom",
                "raw": "refType.isRequired"
            },
            "required": false,
            "description": "A ref that points to the first DOM node of the wrapped element."
        }
    }
}