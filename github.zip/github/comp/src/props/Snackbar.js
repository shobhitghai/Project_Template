/* eslint-disable */
export default {
    "displayName": "Snackbar",
    "description": "",
    "methods": [],
    "props": {
        "action": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The action to display. It renders after the message, at the end of the snackbar."
        },
        "anchorOrigin": {
            "type": {
                "name": "shape",
                "value": {
                    "horizontal": {
                        "name": "enum",
                        "value": [
                            {
                                "value": "'left'",
                                "computed": false
                            },
                            {
                                "value": "'center'",
                                "computed": false
                            },
                            {
                                "value": "'right'",
                                "computed": false
                            }
                        ],
                        "required": true
                    },
                    "vertical": {
                        "name": "enum",
                        "value": [
                            {
                                "value": "'top'",
                                "computed": false
                            },
                            {
                                "value": "'bottom'",
                                "computed": false
                            }
                        ],
                        "required": true
                    }
                }
            },
            "required": false,
            "description": "The anchor of the `Snackbar`."
        },
        "autoHideDuration": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The number of milliseconds to wait before automatically calling the\r\n`onClose` function. `onClose` should then set the state of the `open`\r\nprop to hide the Snackbar. This behavior is disabled by default with\r\nthe `null` value."
        },
        "children": {
            "type": {
                "name": "element"
            },
            "required": false,
            "description": "Replace the `SnackbarContent` component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "ClickAwayListenerProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the `ClickAwayListener` element."
        },
        "ContentProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`SnackbarContent`](/api/snackbar-content/) element."
        },
        "disableWindowBlurListener": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the `autoHideDuration` timer will expire even if the window is not focused."
        },
        "key": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "When displaying multiple consecutive Snackbars from a parent rendering a single\r\n<Snackbar/>, add the key prop to ensure independent treatment of each message.\r\ne.g. <Snackbar key={message} />, otherwise, the message may update-in-place and\r\nfeatures such as autoHideDuration may be canceled."
        },
        "message": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The message to display."
        },
        "onClose": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component requests to be closed.\r\nTypically `onClose` is used to set state in the parent component,\r\nwhich is used to control the `Snackbar` `open` prop.\r\nThe `reason` parameter can optionally be used to control the response to `onClose`,\r\nfor example ignoring `clickaway`.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"timeout\"` (`autoHideDuration` expired), `\"clickaway\"`."
        },
        "onEnter": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired before the transition is entering."
        },
        "onEntered": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the transition has entered."
        },
        "onEntering": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the transition is entering."
        },
        "onExit": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired before the transition is exiting."
        },
        "onExited": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the transition has exited."
        },
        "onExiting": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the transition is exiting."
        },
        "onMouseEnter": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onMouseLeave": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, `Snackbar` is open."
        },
        "resumeHideDuration": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The number of milliseconds to wait before dismissing after user interaction.\r\nIf `autoHideDuration` prop isn't specified, it does nothing.\r\nIf `autoHideDuration` prop is specified but `resumeHideDuration` isn't,\r\nwe default to `autoHideDuration / 2` ms."
        },
        "TransitionComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
        },
        "transitionDuration": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "shape",
                        "value": {
                            "enter": {
                                "name": "number",
                                "required": false
                            },
                            "exit": {
                                "name": "number",
                                "required": false
                            }
                        }
                    }
                ]
            },
            "required": false,
            "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
        },
        "TransitionProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
        }
    }
}