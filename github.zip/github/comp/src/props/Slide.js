/* eslint-disable */
export default {
    "displayName": "Slide",
    "description": "The Slide transition is used by the [Drawer](/components/drawers/) component.\r\nIt uses [react-transition-group](https://github.com/reactjs/react-transition-group) internally.",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "custom",
                "raw": "elementAcceptingRef"
            },
            "required": false,
            "description": "A single child content element."
        },
        "direction": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'left'",
                        "computed": false
                    },
                    {
                        "value": "'right'",
                        "computed": false
                    },
                    {
                        "value": "'up'",
                        "computed": false
                    },
                    {
                        "value": "'down'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Direction the child node will enter from."
        },
        "in": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, show the component; triggers the enter or exit animation."
        },
        "onEnter": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onEntering": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onExit": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onExited": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "style": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "@ignore"
        },
        "timeout": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "shape",
                        "value": {
                            "enter": {
                                "name": "number",
                                "required": false
                            },
                            "exit": {
                                "name": "number",
                                "required": false
                            }
                        }
                    }
                ]
            },
            "required": false,
            "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
        }
    }
}