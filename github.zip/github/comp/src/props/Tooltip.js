/* eslint-disable */
export default {
    "displayName": "Tooltip",
    "description": "",
    "methods": [],
    "props": {
        "arrow": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, adds an arrow to the tooltip."
        },
        "children": {
            "type": {
                "name": "custom",
                "raw": "elementAcceptingRef.isRequired"
            },
            "required": false,
            "description": "Tooltip reference element."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "disableFocusListener": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Do not respond to focus events."
        },
        "disableHoverListener": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Do not respond to hover events."
        },
        "disableTouchListener": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Do not respond to long press touch events."
        },
        "enterDelay": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The number of milliseconds to wait before showing the tooltip.\r\nThis prop won't impact the enter touch delay (`enterTouchDelay`)."
        },
        "enterTouchDelay": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The number of milliseconds a user must touch the element before showing the tooltip."
        },
        "id": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "This prop is used to help implement the accessibility logic.\r\nIf you don't provide this prop. It falls back to a randomly generated id."
        },
        "interactive": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Makes a tooltip interactive, i.e. will not close when the user\r\nhovers over the tooltip before the `leaveDelay` is expired."
        },
        "leaveDelay": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The number of milliseconds to wait before hiding the tooltip.\r\nThis prop won't impact the leave touch delay (`leaveTouchDelay`)."
        },
        "leaveTouchDelay": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The number of milliseconds after the user stops touching an element before hiding the tooltip."
        },
        "onClose": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback."
        },
        "onOpen": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component requests to be open.\r\n\n@param {object} event The event source of the callback."
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the tooltip is shown."
        },
        "placement": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'bottom-end'",
                        "computed": false
                    },
                    {
                        "value": "'bottom-start'",
                        "computed": false
                    },
                    {
                        "value": "'bottom'",
                        "computed": false
                    },
                    {
                        "value": "'left-end'",
                        "computed": false
                    },
                    {
                        "value": "'left-start'",
                        "computed": false
                    },
                    {
                        "value": "'left'",
                        "computed": false
                    },
                    {
                        "value": "'right-end'",
                        "computed": false
                    },
                    {
                        "value": "'right-start'",
                        "computed": false
                    },
                    {
                        "value": "'right'",
                        "computed": false
                    },
                    {
                        "value": "'top-end'",
                        "computed": false
                    },
                    {
                        "value": "'top-start'",
                        "computed": false
                    },
                    {
                        "value": "'top'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Tooltip placement."
        },
        "PopperProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Popper`](/api/popper/) element."
        },
        "title": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "Tooltip title. Zero-length titles string are never displayed."
        },
        "TransitionComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
        },
        "TransitionProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
        }
    }
}