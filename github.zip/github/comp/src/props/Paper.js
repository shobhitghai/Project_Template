/* eslint-disable */
export default {
    "displayName": "Paper",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "elevation": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Shadow depth, corresponds to `dp` in the spec.\r\nIt accepts values between 0 and 24 inclusive."
        },
        "square": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, rounded corners are disabled."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'elevation'",
                        "computed": false
                    },
                    {
                        "value": "'outlined'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}