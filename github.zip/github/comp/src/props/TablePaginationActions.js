
/* eslint-disable */

export default {
    "description": "@ignore - internal component.",
    "displayName": "TablePaginationActions",
    "methods": [
        {
            "name": "handleBackButtonClick",
            "docblock": null,
            "modifiers": [],
            "params": [
                {
                    "name": "event",
                    "type": null
                }
            ],
            "returns": null
        },
        {
            "name": "handleNextButtonClick",
            "docblock": null,
            "modifiers": [],
            "params": [
                {
                    "name": "event",
                    "type": null
                }
            ],
            "returns": null
        }
    ],
    "props": {
        "backIconButtonProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Properties applied to the back arrow [`IconButton`](/api/icon-button) element."
        },
        "count": {
            "type": {
                "name": "number"
            },
            "required": true,
            "description": "The total number of rows."
        },
        "nextIconButtonProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Properties applied to the next arrow [`IconButton`](/api/icon-button) element."
        },
        "onChangePage": {
            "type": {
                "name": "func"
            },
            "required": true,
            "description": "Callback fired when the page is changed.\r\n\n@param {object} event The event source of the callback\r\n@param {number} page The page selected"
        },
        "page": {
            "type": {
                "name": "number"
            },
            "required": true,
            "description": "The zero-based index of the current page."
        },
        "rowsPerPage": {
            "type": {
                "name": "number"
            },
            "required": true,
            "description": "The number of rows per page."
        },
        "theme": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "@ignore"
        }
    }
}
