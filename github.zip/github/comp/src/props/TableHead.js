/* eslint-disable */
export default {
    "displayName": "TableHead",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component, normally `TableRow`."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        }
    }
}