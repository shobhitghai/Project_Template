/* eslint-disable */
export default {
    "displayName": "ExpansionPanel",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "custom",
                "raw": "chainPropTypes(PropTypes.node.isRequired, props => {\r\n  const summary = React.Children.toArray(props.children)[0];\r\n  if (isFragment(summary)) {\r\n    return new Error(\r\n      \"Material-UI: the ExpansionPanel doesn't accept a Fragment as a child. \" +\r\n        'Consider providing an array instead.',\r\n    );\r\n  }\r\n\r\n  if (!React.isValidElement(summary)) {\r\n    return new Error(\r\n      'Material-UI: expected the first child of ExpansionPanel to be a valid element.',\r\n    );\r\n  }\r\n\r\n  return null;\r\n})"
            },
            "required": false,
            "description": "The content of the expansion panel."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "defaultExpanded": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, expands the panel by default."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the panel will be displayed in a disabled state."
        },
        "expanded": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, expands the panel, otherwise collapse it.\r\nSetting this prop enables control over the panel."
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the expand/collapse state is changed.\r\n\n@param {object} event The event source of the callback.\r\n@param {boolean} expanded The `expanded` state of the panel."
        },
        "square": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "TransitionComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the collapse effect.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
        },
        "TransitionProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
        }
    }
}