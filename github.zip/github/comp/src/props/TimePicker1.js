/* eslint-disable */
export default {
    "fileName": "time-picker",
    "description": "",
    "methods": [],
    "props": {
        "defaultValue": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": ""
        },
        "fullWidth": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "",
            "defaultValue": {
                "value": "true",
                "computed": false
            }
        },
        "inputProps": {
            "type": {
                "name": "shape",
                "value": {
                    "step": {
                        "name": "number",
                        "required": false
                    }
                }
            },
            "required": false,
            "description": "",
            "defaultValue": {
                "value": "{\n    step: 300\n}",
                "computed": false
            }
        }
    }
}