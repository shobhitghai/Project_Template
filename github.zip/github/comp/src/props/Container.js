/* eslint-disable */
export default {
    "displayName": "Container",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": ""
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "disableGutters": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the left and right padding is removed."
        },
        "fixed": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Set the max-width to match the min-width of the current breakpoint.\r\nThis is useful if you'd prefer to design for a fixed set of sizes\r\ninstead of trying to accommodate a fully fluid viewport.\r\nIt's fluid by default."
        },
        "maxWidth": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'xs'",
                        "computed": false
                    },
                    {
                        "value": "'sm'",
                        "computed": false
                    },
                    {
                        "value": "'md'",
                        "computed": false
                    },
                    {
                        "value": "'lg'",
                        "computed": false
                    },
                    {
                        "value": "'xl'",
                        "computed": false
                    },
                    {
                        "value": "false",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Determine the max-width of the container.\r\nThe container width grows with the size of the screen.\r\nSet to `false` to disable `maxWidth`."
        }
    }
}