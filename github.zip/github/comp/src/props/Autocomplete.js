/* eslint-disable */
export default {
    "displayName": "Autocomplete",
    "description": "",
    "methods": [],
    "props": {
        "autoComplete": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the portion of the selected suggestion that has not been typed by the user,\r\nknown as the completion string, appears inline after the input cursor in the textbox.\r\nThe inline completion string is visually highlighted and has a selected state."
        },
        "autoHighlight": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the first option is automatically highlighted."
        },
        "autoSelect": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the selected option becomes the value of the input\r\nwhen the Autocomplete loses focus unless the user chooses\r\na different option or changes the character string in the input."
        },
        "blurOnSelect": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "enum",
                        "value": [
                            {
                                "value": "'mouse'",
                                "computed": false
                            },
                            {
                                "value": "'touch'",
                                "computed": false
                            }
                        ]
                    },
                    {
                        "name": "bool"
                    }
                ]
            },
            "required": false,
            "description": "Control if the input should be blurred when an option is selected:\r\n\n- `false` the input is not blurred.\r\n- `true` the input is always blurred.\r\n- `touch` the input is blurred after a touch event.\r\n- `mouse` the input is blurred after a mouse event."
        },
        "ChipProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Chip`](/api/chip/) element."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "clearOnEscape": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, clear all values when the user presses escape and the popup is closed."
        },
        "clearText": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Override the default text for the *clear* icon button.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
        },
        "closeIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon to display in place of the default close icon."
        },
        "closeText": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Override the default text for the *close popup* icon button.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
        },
        "debug": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the popup will ignore the blur event if the input if filled.\r\nYou can inspect the popup markup with your browser tools.\r\nConsider this option when you need to customize the component."
        },
        "defaultValue": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "any"
                    },
                    {
                        "name": "array"
                    }
                ]
            },
            "required": false,
            "description": "The default input value. Use when the component is not controlled."
        },
        "disableClearable": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the input can't be cleared."
        },
        "disableCloseOnSelect": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the popup won't close when a value is selected."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the input will be disabled."
        },
        "disableListWrap": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the list box in the popup will not wrap focus."
        },
        "disableOpenOnFocus": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the popup won't open on input focus."
        },
        "disablePortal": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Disable the portal behavior.\r\nThe children stay within it's parent DOM hierarchy."
        },
        "filterOptions": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "A filter function that determines the options that are eligible.\r\n\n@param {T[]} options The options to render.\r\n@param {object} state The state of the component.\r\n@returns {T[]}"
        },
        "filterSelectedOptions": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, hide the selected options from the list box."
        },
        "forcePopupIcon": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "enum",
                        "value": [
                            {
                                "value": "'auto'",
                                "computed": false
                            }
                        ]
                    },
                    {
                        "name": "bool"
                    }
                ]
            },
            "required": false,
            "description": "Force the visibility display of the popup icon."
        },
        "freeSolo": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the Autocomplete is free solo, meaning that the user input is not bound to provided options."
        },
        "getOptionDisabled": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Used to determine the disabled state for a given option."
        },
        "getOptionLabel": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Used to determine the string value for a given option.\r\nIt's used to fill the input (and the list box options if `renderOption` is not provided)."
        },
        "getOptionSelected": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Used to determine if an option is selected.\r\nUses strict equality by default."
        },
        "groupBy": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "If provided, the options will be grouped under the returned string.\r\nThe groupBy value is also used as the text for group headings when `renderGroup` is not provided.\r\n\n@param {T} options The option to group.\r\n@returns {string}"
        },
        "id": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "This prop is used to help implement the accessibility logic.\r\nIf you don't provide this prop. It falls back to a randomly generated id."
        },
        "includeInputInList": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the highlight can move to the input."
        },
        "inputValue": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The input value."
        },
        "ListboxComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used to render the listbox."
        },
        "ListboxProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the Listbox element."
        },
        "loading": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the component is in a loading state."
        },
        "loadingText": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Text to display when in a loading state.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
        },
        "multiple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, `value` must be an array and the menu will support multiple selections."
        },
        "noOptionsText": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Text to display when there are no options.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the value changes.\r\n\n@param {object} event The event source of the callback.\r\n@param {T} value"
        },
        "onClose": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the popup requests to be closed.\r\nUse in controlled mode (see open).\r\n\n@param {object} event The event source of the callback."
        },
        "onInputChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the input value changes.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} value The new value of the text input.\r\n@param {string} reason Can be: \"input\" (user input), \"reset\" (programmatic change), `\"clear\"`."
        },
        "onOpen": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the popup requests to be opened.\r\nUse in controlled mode (see open).\r\n\n@param {object} event The event source of the callback."
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Control the popup` open state."
        },
        "openText": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Override the default text for the *open popup* icon button.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
        },
        "options": {
            "type": {
                "name": "array"
            },
            "required": false,
            "description": "Array of options."
        },
        "PaperComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used to render the body of the popup."
        },
        "PopperComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used to position the popup."
        },
        "popupIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon to display in place of the default popup icon."
        },
        "renderGroup": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Render the group.\r\n\n@param {any} option The group to render.\r\n@returns {ReactNode}"
        },
        "renderInput": {
            "type": {
                "name": "func"
            },
            "required": true,
            "description": "Render the input.\r\n\n@param {object} params\r\n@returns {ReactNode}"
        },
        "renderOption": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Render the option, use `getOptionLabel` by default.\r\n\n@param {T} option The option to render.\r\n@param {object} state The state of the component.\r\n@returns {ReactNode}"
        },
        "renderTags": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Render the selected value.\r\n\n@param {T[]} value The `value` provided to the component.\r\n@param {function} getTagProps A tag props getter.\r\n@returns {ReactNode}"
        },
        "selectOnFocus": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the input's text will be selected on focus."
        },
        "size": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'medium'",
                        "computed": false
                    },
                    {
                        "value": "'small'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The size of the autocomplete."
        },
        "value": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "any"
                    },
                    {
                        "name": "array"
                    }
                ]
            },
            "required": false,
            "description": "The value of the autocomplete.\r\n\nThe value must have reference equality with the option in order to be selected.\r\nYou can customize the equality behavior with the `getOptionSelected` prop."
        }
    }
}