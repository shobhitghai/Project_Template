/* eslint-disable */
export default {
    "displayName": "CircularProgress",
    "description": "## ARIA\r\n\nIf the progress bar is describing the loading progress of a particular region of a page,\r\nyou should use `aria-describedby` to point to the progress bar, and set the `aria-busy`\r\nattribute to `true` on that region until it has finished loading.",
    "methods": [],
    "props": {
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    },
                    {
                        "value": "'inherit'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "disableShrink": {
            "type": {
                "name": "custom",
                "raw": "chainPropTypes(PropTypes.bool, props => {\r\n  if (props.disableShrink && props.variant && props.variant !== 'indeterminate') {\r\n    return new Error(\r\n      'Material-UI: you have provided the `disableShrink` prop ' +\r\n        'with a variant other than `indeterminate`. This will have no effect.',\r\n    );\r\n  }\r\n\r\n  return null;\r\n})"
            },
            "required": false,
            "description": "If `true`, the shrink animation is disabled.\r\nThis only works if variant is `indeterminate`."
        },
        "size": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "string"
                    }
                ]
            },
            "required": false,
            "description": "The size of the circle.\r\nIf using a number, the pixel unit is assumed.\r\nIf using a string, you need to provide the CSS unit, e.g '3rem'."
        },
        "style": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "@ignore"
        },
        "thickness": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The thickness of the circle."
        },
        "value": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The value of the progress indicator for the determinate and static variants.\r\nValue between 0 and 100."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'determinate'",
                        "computed": false
                    },
                    {
                        "value": "'indeterminate'",
                        "computed": false
                    },
                    {
                        "value": "'static'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use.\r\nUse indeterminate when there is no progress value."
        }
    }
}