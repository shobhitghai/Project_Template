/* eslint-disable */
export default {
    "displayName": "StepLabel",
    "description": "",
    "methods": [],
    "props": {
        "active": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "alternativeLabel": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "In most cases will simply be a string containing a title for the label."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "completed": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Mark the step as disabled, will also disable the button if\r\n`StepLabelButton` is a child of `StepLabel`. Is passed to child components."
        },
        "error": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Mark the step as failed."
        },
        "expanded": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "icon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Override the default label of the step icon."
        },
        "last": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "optional": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The optional node to display."
        },
        "orientation": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'horizontal'",
                        "computed": false
                    },
                    {
                        "value": "'vertical'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "@ignore"
        },
        "StepIconComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component to render in place of the [`StepIcon`](/api/step-icon/)."
        },
        "StepIconProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`StepIcon`](/api/step-icon/) element."
        }
    }
}