/* eslint-disable */
export default {
    "fileName": "status-snackbar",
    "description": "",
    "methods": [],
    "props": {
        "message": {
            "type": {
                "name": "string"
            },
            "required": true,
            "description": ""
        },
        "variant": {
            "type": {
                "name": "enum",
                "computed": true,
                "value": "values(Variants)"
            },
            "required": false,
            "description": "",
            "defaultValue": {
                "value": "'error'",
                "computed": false
            }
        }
    },
    "composes": [
        "../snackbar"
    ]
}