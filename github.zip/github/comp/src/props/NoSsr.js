/* eslint-disable */
export default {
    "displayName": "NoSsr",
    "description": "NoSsr purposely removes components from the subject of Server Side Rendering (SSR).\r\n\nThis component can be useful in a variety of situations:\r\n- Escape hatch for broken dependencies not supporting SSR.\r\n- Improve the time-to-first paint on the client by only rendering above the fold.\r\n- Reduce the rendering time on the server.\r\n- Under too heavy server load, you can turn on service degradation.",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "You can wrap a node."
        },
        "defer": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the component will not only prevent server-side rendering.\r\nIt will also defer the rendering of the children into a different screen frame."
        },
        "fallback": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The fallback content to display."
        }
    }
}