/* eslint-disable */
export default {
    "displayName": "Menu",
    "description": "",
    "methods": [],
    "props": {
        "anchorEl": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "object"
                    },
                    {
                        "name": "func"
                    }
                ]
            },
            "required": false,
            "description": "The DOM element used to set the position of the menu."
        },
        "autoFocus": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true` (Default) will focus the `[role=\"menu\"]` if no focusable child is found. Disabled\r\nchildren are not focusable. If you set this prop to `false` focus will be placed\r\non the parent modal container. This has severe accessibility implications\r\nand should only be considered if you manage focus otherwise."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Menu contents, normally `MenuItem`s."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "disableAutoFocusItem": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "When opening the menu will not focus the active item but the `[role=\"menu\"]`\r\nunless `autoFocus` is also set to `false`. Not using the default means not\r\nfollowing WAI-ARIA authoring practices. Please be considerate about possible\r\naccessibility implications."
        },
        "MenuListProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`MenuList`](/api/menu-list/) element."
        },
        "onClose": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"escapeKeyDown\"`, `\"backdropClick\"`, `\"tabKeyDown\"`."
        },
        "onEnter": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired before the Menu enters."
        },
        "onEntered": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the Menu has entered."
        },
        "onEntering": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the Menu is entering."
        },
        "onExit": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired before the Menu exits."
        },
        "onExited": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the Menu has exited."
        },
        "onExiting": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the Menu is exiting."
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": true,
            "description": "If `true`, the menu is visible."
        },
        "PaperProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "@ignore"
        },
        "PopoverClasses": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "`classes` prop applied to the [`Popover`](/api/popover/) element."
        },
        "transitionDuration": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "shape",
                        "value": {
                            "enter": {
                                "name": "number",
                                "required": false
                            },
                            "exit": {
                                "name": "number",
                                "required": false
                            }
                        }
                    },
                    {
                        "name": "enum",
                        "value": [
                            {
                                "value": "'auto'",
                                "computed": false
                            }
                        ]
                    }
                ]
            },
            "required": false,
            "description": "The length of the transition in `ms`, or 'auto'"
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'menu'",
                        "computed": false
                    },
                    {
                        "value": "'selectedMenu'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use. Use `menu` to prevent selected items from impacting the initial focus\r\nand the vertical alignment relative to the anchor element."
        }
    }
}