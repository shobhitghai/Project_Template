/* eslint-disable */
export default {
    "displayName": "InputAdornment",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "The content of the component, normally an `IconButton` or string."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "disablePointerEvents": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Disable pointer events on the root.\r\nThis allows for the content of the adornment to focus the input on click."
        },
        "disableTypography": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If children is a string then disable wrapping in a Typography component."
        },
        "muiFormControl": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "@ignore"
        },
        "position": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'start'",
                        "computed": false
                    },
                    {
                        "value": "'end'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The position this adornment should appear relative to the `Input`."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'standard'",
                        "computed": false
                    },
                    {
                        "value": "'outlined'",
                        "computed": false
                    },
                    {
                        "value": "'filled'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use.\r\nNote: If you are using the `TextField` component or the `FormControl` component\r\nyou do not have to set this manually."
        }
    }
}