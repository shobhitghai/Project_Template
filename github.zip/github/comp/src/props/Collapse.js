/* eslint-disable */
export default {
    "displayName": "Collapse",
    "description": "The Collapse transition is used by the\r\n[Vertical Stepper](/components/steppers/#vertical-stepper) StepContent component.\r\nIt uses [react-transition-group](https://github.com/reactjs/react-transition-group) internally.",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content node to be collapsed."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "collapsedHeight": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "string"
                    },
                    {
                        "name": "number"
                    }
                ]
            },
            "required": false,
            "description": "The height of the container when collapsed."
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "in": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the component will transition in."
        },
        "onEnter": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onEntered": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onEntering": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onExit": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onExiting": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "style": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "@ignore"
        },
        "timeout": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "shape",
                        "value": {
                            "enter": {
                                "name": "number",
                                "required": false
                            },
                            "exit": {
                                "name": "number",
                                "required": false
                            }
                        }
                    },
                    {
                        "name": "enum",
                        "value": [
                            {
                                "value": "'auto'",
                                "computed": false
                            }
                        ]
                    }
                ]
            },
            "required": false,
            "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object.\r\n\nSet to 'auto' to automatically calculate transition time based on height."
        }
    }
}