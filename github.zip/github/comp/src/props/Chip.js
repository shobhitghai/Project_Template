/* eslint-disable */
export default {
    "displayName": "Chip",
    "description": "Chips represent complex entities in small blocks, such as a contact.",
    "methods": [],
    "props": {
        "avatar": {
            "type": {
                "name": "element"
            },
            "required": false,
            "description": "Avatar element."
        },
        "children": {
            "type": {
                "name": "custom",
                "raw": "unsupportedProp"
            },
            "required": false,
            "description": "This prop isn't supported.\r\nUse the `component` prop if you need to change the children structure."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "clickable": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the chip will appear clickable, and will raise when pressed,\r\neven if the onClick prop is not defined.\r\nIf false, the chip will not be clickable, even if onClick prop is defined.\r\nThis can be used, for example,\r\nalong with the component prop to indicate an anchor Chip is clickable."
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'default'",
                        "computed": false
                    },
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "deleteIcon": {
            "type": {
                "name": "element"
            },
            "required": false,
            "description": "Override the default delete icon element. Shown only if `onDelete` is set."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the chip should be displayed in a disabled state."
        },
        "icon": {
            "type": {
                "name": "element"
            },
            "required": false,
            "description": "Icon element."
        },
        "label": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the label."
        },
        "onClick": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onDelete": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback function fired when the delete icon is clicked.\r\nIf set, the delete icon will be shown."
        },
        "onKeyDown": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onKeyUp": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "size": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'small'",
                        "computed": false
                    },
                    {
                        "value": "'medium'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The size of the chip."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'default'",
                        "computed": false
                    },
                    {
                        "value": "'outlined'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}