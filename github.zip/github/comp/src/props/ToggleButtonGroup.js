/* eslint-disable */
export default {
    "displayName": "ToggleButtonGroup",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the button."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "exclusive": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, only allow one of the child ToggleButton values to be selected."
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the value changes.\r\n\n@param {object} event The event source of the callback.\r\n@param {any} value of the selected buttons. When `exclusive` is true\r\nthis is a single value; when false an array of selected values. If no value\r\nis selected and `exclusive` is true the value is null; when false an empty array."
        },
        "size": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'large'",
                        "computed": false
                    },
                    {
                        "value": "'medium'",
                        "computed": false
                    },
                    {
                        "value": "'small'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The size of the buttons."
        },
        "value": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "The currently selected value within the group or an array of selected\r\nvalues when `exclusive` is false."
        }
    }
}