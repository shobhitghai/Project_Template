/* eslint-disable */
export default {
    "displayName": "ToggleButton",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "The content of the button."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the button will be disabled."
        },
        "disableFocusRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the  keyboard focus ripple will be disabled.\r\n`disableRipple` must also be true."
        },
        "disableRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the ripple effect will be disabled."
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onClick": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "selected": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the button will be rendered in an active state."
        },
        "size": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'small'",
                        "computed": false
                    },
                    {
                        "value": "'medium'",
                        "computed": false
                    },
                    {
                        "value": "'large'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "@ignore"
        },
        "value": {
            "type": {
                "name": "any"
            },
            "required": true,
            "description": "The value to associate with the button when selected in a\r\nToggleButtonGroup."
        }
    }
}