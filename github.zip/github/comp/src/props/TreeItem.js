/* eslint-disable */
export default {
    "displayName": "TreeItem",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "collapseIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon used to collapse the node."
        },
        "endIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon displayed next to a end node."
        },
        "expandIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon used to expand the node."
        },
        "icon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon to display next to the tree node's label."
        },
        "label": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The tree node label."
        },
        "nodeId": {
            "type": {
                "name": "string"
            },
            "required": true,
            "description": "The id of the node."
        },
        "onClick": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onFocus": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onKeyDown": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "TransitionComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
        },
        "TransitionProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
        }
    }
}