/* eslint-disable */
export default {
    "displayName": "Table",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "The content of the table, normally `TableHead` and `TableBody`."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "padding": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'default'",
                        "computed": false
                    },
                    {
                        "value": "'checkbox'",
                        "computed": false
                    },
                    {
                        "value": "'none'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Allows TableCells to inherit padding of the Table."
        },
        "size": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'small'",
                        "computed": false
                    },
                    {
                        "value": "'medium'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Allows TableCells to inherit size of the Table."
        },
        "stickyHeader": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Set the header sticky.\r\n\n⚠️ It doesn't work with IE 11."
        }
    }
}