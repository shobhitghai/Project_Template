/* eslint-disable */
export default {
    "displayName": "NativeSelect",
    "description": "An alternative to `<Select native />` with a much smaller bundle size footprint.",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The option elements to populate the select with.\r\nCan be some `<option>` elements."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "IconComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The icon that displays the arrow."
        },
        "input": {
            "type": {
                "name": "element"
            },
            "required": false,
            "description": "An `Input` element; does not have to be a material-ui specific `Input`."
        },
        "inputProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Attributes applied to the `select` element."
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback function fired when a menu item is selected.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new value by accessing `event.target.value` (string)."
        },
        "value": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "The input value. The DOM API casts this to a string."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'standard'",
                        "computed": false
                    },
                    {
                        "value": "'outlined'",
                        "computed": false
                    },
                    {
                        "value": "'filled'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}