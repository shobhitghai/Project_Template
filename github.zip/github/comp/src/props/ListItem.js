/* eslint-disable */
export default {
    "displayName": "ListItem",
    "description": "Uses an additional container component if `ListItemSecondaryAction` is the last child.",
    "methods": [],
    "props": {
        "alignItems": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'flex-start'",
                        "computed": false
                    },
                    {
                        "value": "'center'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Defines the `align-items` style property."
        },
        "autoFocus": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the list item will be focused during the first mount.\r\nFocus will also be triggered if the value changes from false to true."
        },
        "button": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the list item will be a button (using `ButtonBase`). Props intended\r\nfor `ButtonBase` can then be applied to `ListItem`."
        },
        "children": {
            "type": {
                "name": "custom",
                "raw": "chainPropTypes(PropTypes.node, props => {\r\n  const children = React.Children.toArray(props.children);\r\n\r\n  // React.Children.toArray(props.children).findLastIndex(isListItemSecondaryAction)\r\n  let secondaryActionIndex = -1;\r\n  for (let i = children.length - 1; i >= 0; i -= 1) {\r\n    const child = children[i];\r\n    if (isMuiElement(child, ['ListItemSecondaryAction'])) {\r\n      secondaryActionIndex = i;\r\n      break;\r\n    }\r\n  }\r\n\r\n  //  is ListItemSecondaryAction the last child of ListItem\r\n  if (secondaryActionIndex !== -1 && secondaryActionIndex !== children.length - 1) {\r\n    return new Error(\r\n      'Material-UI: you used an element after ListItemSecondaryAction. ' +\r\n        'For ListItem to detect that it has a secondary action ' +\r\n        'you must pass it as the last child to ListItem.',\r\n    );\r\n  }\r\n\r\n  return null;\r\n})"
            },
            "required": false,
            "description": "The content of the component. If a `ListItemSecondaryAction` is used it must\r\nbe the last child."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component.\r\nBy default, it's a `li` when `button` is `false` and a `div` when `button` is `true`."
        },
        "ContainerComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The container component used when a `ListItemSecondaryAction` is the last child."
        },
        "ContainerProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the container component if used."
        },
        "dense": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, compact vertical padding designed for keyboard and mouse input will be used."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the list item will be disabled."
        },
        "disableGutters": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the left and right padding is removed."
        },
        "divider": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, a 1px light border is added to the bottom of the list item."
        },
        "focusVisibleClassName": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "selected": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Use to apply selected styling."
        }
    }
}