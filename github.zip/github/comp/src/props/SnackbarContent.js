/* eslint-disable */
export default {
    "displayName": "SnackbarContent",
    "description": "",
    "methods": [],
    "props": {
        "action": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The action to display. It renders after the message, at the end of the snackbar."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "message": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The message to display."
        },
        "role": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The ARIA role attribute of the element."
        }
    }
}