/* eslint-disable */
export default {
    "displayName": "TableSortLabel",
    "description": "A button based label for placing inside `TableCell` for column sorting.",
    "methods": [],
    "props": {
        "active": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the label will have the active styling (should be true for the sorted column)."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Label contents, the arrow will be appended automatically."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "direction": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'asc'",
                        "computed": false
                    },
                    {
                        "value": "'desc'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The current sort direction."
        },
        "hideSortIcon": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Hide sort icon when active is false."
        },
        "IconComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "Sort icon to use."
        }
    }
}