/* eslint-disable */
export default {
    "displayName": "Divider",
    "description": "",
    "methods": [],
    "props": {
        "absolute": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Absolutely position the element."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "light": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the divider will have a lighter color."
        },
        "orientation": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'horizontal'",
                        "computed": false
                    },
                    {
                        "value": "'vertical'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The divider orientation."
        },
        "role": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'fullWidth'",
                        "computed": false
                    },
                    {
                        "value": "'inset'",
                        "computed": false
                    },
                    {
                        "value": "'middle'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}