/* eslint-disable */
export default {
    "displayName": "Avatar",
    "description": "",
    "methods": [],
    "props": {
        "alt": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Used in combination with `src` or `srcSet` to\r\nprovide an alt attribute for the rendered `img` element."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Used to render icon or text elements inside the Avatar if `src` is not set.\r\nThis can be an element, or just a string."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "imgProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Attributes applied to the `img` element if the component is used to display an image.\r\nIt can be used to listen for the loading error event."
        },
        "sizes": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The `sizes` attribute for the `img` element."
        },
        "src": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The `src` attribute for the `img` element."
        },
        "srcSet": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The `srcSet` attribute for the `img` element.\r\nUse this attribute for responsive image display."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'circle'",
                        "computed": false
                    },
                    {
                        "value": "'rounded'",
                        "computed": false
                    },
                    {
                        "value": "'square'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The shape of the avatar."
        }
    }
}