/* eslint-disable */
export default {
    "displayName": "Typography",
    "description": "",
    "methods": [],
    "props": {
        "align": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'inherit'",
                        "computed": false
                    },
                    {
                        "value": "'left'",
                        "computed": false
                    },
                    {
                        "value": "'center'",
                        "computed": false
                    },
                    {
                        "value": "'right'",
                        "computed": false
                    },
                    {
                        "value": "'justify'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Set the text-align on the component."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'initial'",
                        "computed": false
                    },
                    {
                        "value": "'inherit'",
                        "computed": false
                    },
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    },
                    {
                        "value": "'textPrimary'",
                        "computed": false
                    },
                    {
                        "value": "'textSecondary'",
                        "computed": false
                    },
                    {
                        "value": "'error'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component.\r\nOverrides the behavior of the `variantMapping` prop."
        },
        "display": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'initial'",
                        "computed": false
                    },
                    {
                        "value": "'block'",
                        "computed": false
                    },
                    {
                        "value": "'inline'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Controls the display type"
        },
        "gutterBottom": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the text will have a bottom margin."
        },
        "noWrap": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the text will not wrap, but instead will truncate with a text overflow ellipsis.\r\n\nNote that text overflow can only happen with block or inline-block level elements\r\n(the element needs to have a width in order to overflow)."
        },
        "paragraph": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the text will have a bottom margin."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'h1'",
                        "computed": false
                    },
                    {
                        "value": "'h2'",
                        "computed": false
                    },
                    {
                        "value": "'h3'",
                        "computed": false
                    },
                    {
                        "value": "'h4'",
                        "computed": false
                    },
                    {
                        "value": "'h5'",
                        "computed": false
                    },
                    {
                        "value": "'h6'",
                        "computed": false
                    },
                    {
                        "value": "'subtitle1'",
                        "computed": false
                    },
                    {
                        "value": "'subtitle2'",
                        "computed": false
                    },
                    {
                        "value": "'body1'",
                        "computed": false
                    },
                    {
                        "value": "'body2'",
                        "computed": false
                    },
                    {
                        "value": "'caption'",
                        "computed": false
                    },
                    {
                        "value": "'button'",
                        "computed": false
                    },
                    {
                        "value": "'overline'",
                        "computed": false
                    },
                    {
                        "value": "'srOnly'",
                        "computed": false
                    },
                    {
                        "value": "'inherit'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Applies the theme typography styles."
        },
        "variantMapping": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "The component maps the variant prop to a range of different DOM element types.\r\nFor instance, subtitle1 to `<h6>`.\r\nIf you wish to change that mapping, you can provide your own.\r\nAlternatively, you can use the `component` prop."
        }
    }
}