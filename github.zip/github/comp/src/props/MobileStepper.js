/* eslint-disable */
export default {
    "displayName": "MobileStepper",
    "description": "",
    "methods": [],
    "props": {
        "activeStep": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Set the active step (zero based index).\r\nDefines which dot is highlighted when the variant is 'dots'."
        },
        "backButton": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "A back button element. For instance, it can be a `Button` or an `IconButton`."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "LinearProgressProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the `LinearProgress` element."
        },
        "nextButton": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "A next button element. For instance, it can be a `Button` or an `IconButton`."
        },
        "position": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'bottom'",
                        "computed": false
                    },
                    {
                        "value": "'top'",
                        "computed": false
                    },
                    {
                        "value": "'static'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Set the positioning type."
        },
        "steps": {
            "type": {
                "name": "number"
            },
            "required": true,
            "description": "The total steps."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'text'",
                        "computed": false
                    },
                    {
                        "value": "'dots'",
                        "computed": false
                    },
                    {
                        "value": "'progress'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}