/* eslint-disable */
export default {
    "displayName": "TextareaAutosize",
    "description": "",
    "methods": [],
    "props": {
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "placeholder": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "rows": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "string"
                    },
                    {
                        "name": "number"
                    }
                ]
            },
            "required": false,
            "description": "Use `rowsMin` instead. The prop will be removed in v5.\r\n\n@deprecated"
        },
        "rowsMax": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "string"
                    },
                    {
                        "name": "number"
                    }
                ]
            },
            "required": false,
            "description": "Maximum number of rows to display."
        },
        "rowsMin": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "string"
                    },
                    {
                        "name": "number"
                    }
                ]
            },
            "required": false,
            "description": "Minimum number of rows to display."
        },
        "style": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "@ignore"
        },
        "value": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "@ignore"
        }
    }
}