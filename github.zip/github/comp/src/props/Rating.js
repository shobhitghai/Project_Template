/* eslint-disable */
export default {
    "displayName": "Rating",
    "description": "",
    "methods": [],
    "props": {
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "defaultValue": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The default value. Use when the component is not controlled."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the rating will be disabled."
        },
        "emptyIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon to display when empty."
        },
        "emptyLabelText": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The label read when the rating input is empty."
        },
        "getLabelText": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Accepts a function which returns a string value that provides a user-friendly name for the current value of the rating.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/).\r\n\n@param {number} value The rating label's value to format.\r\n@returns {string}"
        },
        "icon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon to display."
        },
        "IconContainerComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component containing the icon."
        },
        "max": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Maximum rating."
        },
        "name": {
            "type": {
                "name": "custom",
                "raw": "chainPropTypes(PropTypes.string, props => {\r\n  if (!props.readOnly && !props.name) {\r\n    return new Error(\r\n      [\r\n        'Material-UI: the prop `name` is required (when `readOnly` is false).',\r\n        'Additionally, the input name should be unique within the parent form.',\r\n      ].join('\\n'),\r\n    );\r\n  }\r\n  return null;\r\n})"
            },
            "required": false,
            "description": "The name attribute of the radio `input` elements.\r\nIf `readOnly` is false, the prop is required,\r\nthis input name`should be unique within the parent form."
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the value changes.\r\n\n@param {object} event The event source of the callback.\r\n@param {number} value The new value."
        },
        "onChangeActive": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback function that is fired when the hover state changes.\r\n\n@param {object} event The event source of the callback.\r\n@param {number} value The new value."
        },
        "onMouseLeave": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onMouseMove": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "precision": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The minimum increment value change allowed."
        },
        "readOnly": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Removes all hover effects and pointer events."
        },
        "size": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'small'",
                        "computed": false
                    },
                    {
                        "value": "'medium'",
                        "computed": false
                    },
                    {
                        "value": "'large'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The size of the rating."
        },
        "value": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The rating value."
        }
    }
}