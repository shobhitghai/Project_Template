/* eslint-disable */
export default {
    "displayName": "SpeedDialAction",
    "description": "",
    "methods": [],
    "props": {
        "classes": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "delay": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Adds a transition delay, to allow a series of SpeedDialActions to be animated."
        },
        "FabProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Fab`](/api/fab/) component."
        },
        "icon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The Icon to display in the SpeedDial Fab."
        },
        "id": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "TooltipClasses": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Classes applied to the [`Tooltip`](/api/tooltip/) element."
        },
        "tooltipOpen": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Make the tooltip always visible when the SpeedDial is open."
        },
        "tooltipPlacement": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'bottom-end'",
                        "computed": false
                    },
                    {
                        "value": "'bottom-start'",
                        "computed": false
                    },
                    {
                        "value": "'bottom'",
                        "computed": false
                    },
                    {
                        "value": "'left-end'",
                        "computed": false
                    },
                    {
                        "value": "'left-start'",
                        "computed": false
                    },
                    {
                        "value": "'left'",
                        "computed": false
                    },
                    {
                        "value": "'right-end'",
                        "computed": false
                    },
                    {
                        "value": "'right-start'",
                        "computed": false
                    },
                    {
                        "value": "'right'",
                        "computed": false
                    },
                    {
                        "value": "'top-end'",
                        "computed": false
                    },
                    {
                        "value": "'top-start'",
                        "computed": false
                    },
                    {
                        "value": "'top'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Placement of the tooltip."
        },
        "tooltipTitle": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Label to display in the tooltip."
        }
    }
}