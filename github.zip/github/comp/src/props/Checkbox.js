/* eslint-disable */
export default {
    "displayName": "Checkbox",
    "description": "",
    "methods": [],
    "props": {
        "checked": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the component is checked."
        },
        "checkedIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon to display when the component is checked."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    },
                    {
                        "value": "'default'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the switch will be disabled."
        },
        "disableRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the ripple effect will be disabled."
        },
        "icon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon to display when the component is unchecked."
        },
        "id": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The id of the `input` element."
        },
        "indeterminate": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the component appears indeterminate.\r\nThis does not set the native input element to indeterminate due\r\nto inconsistent behavior across browsers.\r\nHowever, we set a `data-indeterminate` attribute on the input."
        },
        "indeterminateIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon to display when the component is indeterminate."
        },
        "inputProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "[Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Attributes) applied to the `input` element."
        },
        "inputRef": {
            "type": {
                "name": "custom",
                "raw": "refType"
            },
            "required": false,
            "description": "Pass a ref to the `input` element."
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the state is changed.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new checked state by accessing `event.target.checked` (boolean)."
        },
        "required": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the `input` element will be required."
        },
        "size": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'small'",
                        "computed": false
                    },
                    {
                        "value": "'medium'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The size of the checkbox.\r\n`small` is equivalent to the dense checkbox styling."
        },
        "type": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The input component prop `type`."
        },
        "value": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "The value of the component. The DOM API casts this to a string."
        }
    }
}