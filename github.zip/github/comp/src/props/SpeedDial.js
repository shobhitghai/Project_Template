/* eslint-disable */
export default {
    "displayName": "SpeedDial",
    "description": "",
    "methods": [],
    "props": {
        "ariaLabel": {
            "type": {
                "name": "string"
            },
            "required": true,
            "description": "The aria-label of the button element.\r\nAlso used to provide the `id` for the `SpeedDial` element and its children."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "SpeedDialActions to display when the SpeedDial is `open`."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "direction": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'down'",
                        "computed": false
                    },
                    {
                        "value": "'left'",
                        "computed": false
                    },
                    {
                        "value": "'right'",
                        "computed": false
                    },
                    {
                        "value": "'up'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The direction the actions open relative to the floating action button."
        },
        "FabProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Fab`](/api/fab/) element."
        },
        "hidden": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the SpeedDial will be hidden."
        },
        "icon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon to display in the SpeedDial Fab. The `SpeedDialIcon` component\r\nprovides a default Icon with animation."
        },
        "onBlur": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onClose": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"toggle\"`, `\"blur\"`, `\"mouseLeave\"`, `\"escapeKeyDown\"`."
        },
        "onFocus": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onKeyDown": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onMouseEnter": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onMouseLeave": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onOpen": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component requests to be open.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"toggle\"`, `\"focus\"`, `\"mouseEnter\"`."
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": true,
            "description": "If `true`, the SpeedDial is open."
        },
        "openIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon to display in the SpeedDial Fab when the SpeedDial is open."
        },
        "TransitionComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
        },
        "transitionDuration": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "shape",
                        "value": {
                            "appear": {
                                "name": "number",
                                "required": false
                            },
                            "enter": {
                                "name": "number",
                                "required": false
                            },
                            "exit": {
                                "name": "number",
                                "required": false
                            }
                        }
                    }
                ]
            },
            "required": false,
            "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
        },
        "TransitionProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
        }
    }
}