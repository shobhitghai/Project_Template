/* eslint-disable */
export default {
    "displayName": "ButtonBase",
    "description": "`ButtonBase` contains as few styles as possible.\r\nIt aims to be a simple building block for creating a button.\r\nIt contains a load of style reset and some focus/ripple logic.",
    "methods": [],
    "props": {
        "action": {
            "type": {
                "name": "custom",
                "raw": "refType"
            },
            "required": false,
            "description": "A ref for imperative actions.\r\nIt currently only supports `focusVisible()` action."
        },
        "buttonRef": {
            "type": {
                "name": "custom",
                "raw": "refType"
            },
            "required": false,
            "description": "@ignore\r\n\nUse that prop to pass a ref to the native button component.\r\n@deprecated Use `ref` instead."
        },
        "centerRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the ripples will be centered.\r\nThey won't start at the cursor interaction position."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "custom",
                "raw": "elementTypeAcceptingRef"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the base button will be disabled."
        },
        "disableRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the ripple effect will be disabled.\r\n\n⚠️ Without a ripple there is no styling for :focus-visible by default. Be sure\r\nto highlight the element by applying separate styles with the `focusVisibleClassName`."
        },
        "disableTouchRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the touch ripple effect will be disabled."
        },
        "focusRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the base button will have a keyboard focus ripple.\r\n`disableRipple` must also be `false`."
        },
        "focusVisibleClassName": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "This prop can help a person know which element has the keyboard focus.\r\nThe class name will be applied when the element gain the focus through a keyboard interaction.\r\nIt's a polyfill for the [CSS :focus-visible selector](https://drafts.csswg.org/selectors-4/#the-focus-visible-pseudo).\r\nThe rationale for using this feature [is explained here](https://github.com/WICG/focus-visible/blob/master/explainer.md).\r\nA [polyfill can be used](https://github.com/WICG/focus-visible) to apply a `focus-visible` class to other components\r\nif needed."
        },
        "onBlur": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onClick": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onDragLeave": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onFocus": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onFocusVisible": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component is focused with a keyboard.\r\nWe trigger a `onFocus` callback too."
        },
        "onKeyDown": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onKeyUp": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onMouseDown": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onMouseLeave": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onMouseUp": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onTouchEnd": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onTouchMove": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onTouchStart": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "role": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "tabIndex": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "string"
                    }
                ]
            },
            "required": false,
            "description": "@ignore"
        },
        "TouchRippleProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the `TouchRipple` element."
        },
        "type": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'submit'",
                        "computed": false
                    },
                    {
                        "value": "'reset'",
                        "computed": false
                    },
                    {
                        "value": "'button'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Used to control the button's purpose.\r\nThis prop passes the value to the `type` attribute of the native button component."
        }
    }
}