/* eslint-disable */
export default {
    "displayName": "RadioGroup",
    "description": "",
    "methods": [],
    "props": {
        "actions": {
            "type": {
                "name": "shape",
                "value": {
                    "current": {
                        "name": "object",
                        "required": false
                    }
                }
            },
            "required": false,
            "description": "@ignore"
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "defaultValue": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "The default `input` element value. Use when the component is not controlled."
        },
        "name": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The name used to reference the value of the control."
        },
        "onBlur": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when a radio button is selected.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new value by accessing `event.target.value` (string)."
        },
        "onKeyDown": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "value": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "Value of the selected radio button. The DOM API casts this to a string."
        }
    }
}