/* eslint-disable */
export default {
    "fileName": "dropzone",
    "description": "",
    "methods": [],
    "composes": [
        "react-dropzone"
    ],
    "props": {
        "children": {
            "type": {
                "name": "Func"
            },
            "required": true,
            "description": `Render function that exposes the dropzone state and prop getter fns
            @param {Function} getRootProps- Returns the props you should apply to the root drop container you render
            @param {Function} getInputProps- Returns the props you should apply to hidden file input you render
            @param {Function} open- Open the native file selection dialog
            @param {boolean} isFocused- Dropzone area is in focus
            @param {boolean} isFileDialogActive- File dialog is opened 
            @param {boolean} isDragActive- Active drag is in progress
            @param {boolean} isDragAccept- Dragged files are accepted
            @param {boolean} isDragReject- Some dragged files are rejected 
            @param {File[]} draggedFiles- Files in active drag
            @param {File[]} acceptedFiles- Accepted files
            @param {File[]} rejectedFiles- Rejected files`
        },
        "accept": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "string"
                    },
                    {
                        "name": "arrayOf",
                        "value": {
                            "name": "string"
                        }
                    }
                ]
            },
            "required": false,
            "description": `Set accepted file types.
            See https://github.com/okonet/attr-accept for more information.
            Keep in mind that mime type determination is not reliable across platforms. CSV files,
            for example, are reported as text/plain under macOS but as application/vnd.ms-excel under Windows.`
        },
        "multiple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Allow drag 'n' drop (or selection from the file dialog) of multiple files",
            "defaultValue": {
                "value": "true",
                "computed": false
            }
        },
        "preventDropOnDocument": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If false, allow dropped items to take over the current browser window",
            "defaultValue": {
                "value": "true",
                "computed": false
            }
        },
        "noClick": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If true, disables click to open the native file selection dialog",
            "defaultValue": {
                "value": "false",
                "computed": false
            }
        },
        "noKeyboard": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": `If true, disables SPACE/ENTER to open the native file selection dialog.
            Note that it also stops tracking the focus state.`,
            "defaultValue": {
                "value": "false",
                "computed": false
            }
        },
        "noDrag": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": `If true, disables drag 'n' drop`,
            "defaultValue": {
                "value": "false",
                "computed": false
            }
        },
        "noDragEventsBubbling": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": `If true, stops drag event propagation to parents`,
            "defaultValue": {
                "value": "false",
                "computed": false
            }
        },
        "minSize": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": `Minimum file size (in bytes)`,
            "defaultValue": {
                "value": "0",
                "computed": false
            }
        },
        "maxSize": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": `Maximum file size (in bytes)`,
            "defaultValue": {
                "value": "infinity",
                "computed": false
            }
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": `Enable/disable the dropzone`,
            "defaultValue": {
                "value": "false",
                "computed": false
            }
        },
        "getFilesFromEvent": {
            "type": {
                "name": "Func"
            },
            "required": false,
            "description": `Use this to provide a custom file aggregator
            @param {(DragEvent|Event)} event A drag event or input change event (if files were selected via the file dialog)`
        },
        "onFileDialogCancel": {
            "type": {
                "name": "Func"
            },
            "required": false,
            "description": `Callback for when closing the file dialog with no selection`
        },
        "onDragEnter": {
            "type": {
                "name": "Func"
            },
            "required": false,
            "description": `Callback for when the dragenter event occurs.`
        },
        "onDragLeave": {
            "type": {
                "name": "Func"
            },
            "required": false,
            "description": `Callback for when the onDragLeave event occurs.`
        },
        "onDragOver": {
            "type": {
                "name": "Func"
            },
            "required": false,
            "description": `Callback for when the onDragOver event occurs.`
        },
        "onDrop": {
            "type": {
                "name": "Func"
            },
            "required": false,
            "description": `Callback for when the drop event occurs.
            - Note that this callback is invoked after the "getFilesFromEvent" callback is done.
            - Files are accepted or rejected based on the "accept", "multiple", "minSize" and "maxSize" props.
            - If "multiple" is set to false and additional files are droppped, all files besides the first will be rejected.
            - Any file which does not have a size in the ["minSize", "maxSize"] range, will be rejected as well.
            - Note that the "onDrop" callback will always be invoked regardless if the dropped files were accepted or rejected.
            - If you'd like to react to a specific scenario, use the "onDropAccepted"/"onDropRejected" props.
            - "onDrop" will provide you with an array of [File](https://developer.mozilla.org/en-US/docs/Web/API/File) objects which you can then process and send to a server.
            @param {File[]} acceptedFiles
            @param {File[]} rejectedFiles
            @param {(DragEvent|Event)} event A drag event or input change event (if files were selected via the file dialog)`
        },
        "onDropAccepted": {
            "type": {
                "name": "Func"
            },
            "required": false,
            "description": `Callback for when the "drop" event occurs.
            Note that if no files are accepted, this callback is not invoked.
            @param {File[]} files
            @param {(DragEvent|Event)} event`
        },
        "onDropRejected": {
            "type": {
                "name": "Func"
            },
            "required": false,
            "description": `Callback for when the "drop" event occurs.
            Note that if no files are rejected, this callback is not invoked.
            @param {object[]} files
            @param {(DragEvent|Event)} event`
        },
    }
}