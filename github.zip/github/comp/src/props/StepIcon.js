/* eslint-disable */
export default {
    "displayName": "StepIcon",
    "description": "",
    "methods": [],
    "props": {
        "active": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Whether this step is active."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "completed": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Mark the step as completed. Is passed to child components."
        },
        "error": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Mark the step as failed."
        },
        "icon": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "The label displayed in the step icon."
        }
    }
}