/* eslint-disable */
export default {
    "displayName": "StepConnector",
    "description": "",
    "methods": [],
    "props": {
        "active": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "alternativeLabel": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore\r\nSet internally by Step when it's supplied with the alternativeLabel property."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "completed": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "index": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "@ignore"
        },
        "orientation": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'horizontal'",
                        "computed": false
                    },
                    {
                        "value": "'vertical'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "@ignore"
        }
    }
}