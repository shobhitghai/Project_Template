/* eslint-disable */
export default {
    "displayName": "FormControlLabel",
    "description": "Drop in replacement of the `Radio`, `Switch` and `Checkbox` component.\r\nUse this component if you want to display an extra label.",
    "methods": [],
    "props": {
        "checked": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the component appears selected."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "control": {
            "type": {
                "name": "element"
            },
            "required": false,
            "description": "A control element. For instance, it can be be a `Radio`, a `Switch` or a `Checkbox`."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the control will be disabled."
        },
        "inputRef": {
            "type": {
                "name": "custom",
                "raw": "refType"
            },
            "required": false,
            "description": "Pass a ref to the `input` element."
        },
        "label": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The text to be used in an enclosing label element."
        },
        "labelPlacement": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'end'",
                        "computed": false
                    },
                    {
                        "value": "'start'",
                        "computed": false
                    },
                    {
                        "value": "'top'",
                        "computed": false
                    },
                    {
                        "value": "'bottom'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The position of the label."
        },
        "name": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": ""
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the state is changed.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new checked state by accessing `event.target.checked` (boolean)."
        },
        "value": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "The value of the component."
        }
    }
}