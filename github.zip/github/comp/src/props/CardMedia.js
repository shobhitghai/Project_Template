/* eslint-disable */
export default {
    "displayName": "CardMedia",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "custom",
                "raw": "chainPropTypes(PropTypes.node, props => {\r\n  if (!props.children && !props.image && !props.src) {\r\n    return new Error('Material-UI: either `children`, `image` or `src` prop must be specified.');\r\n  }\r\n  return null;\r\n})"
            },
            "required": false,
            "description": "The content of the component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "Component for rendering image.\r\nEither a string to use a DOM element or a component."
        },
        "image": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Image to be displayed as a background image.\r\nEither `image` or `src` prop must be specified.\r\nNote that caller must specify height otherwise the image will not be visible."
        },
        "src": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "An alias for `image` property.\r\nAvailable only with media components.\r\nMedia components: `video`, `audio`, `picture`, `iframe`, `img`."
        },
        "style": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "@ignore"
        }
    }
}