/* eslint-disable */
export default {
    "displayName": "CardHeader",
    "description": "",
    "methods": [],
    "props": {
        "action": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The action to display in the card header."
        },
        "avatar": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The Avatar for the Card Header."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "disableTypography": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, `subheader` and `title` won't be wrapped by a Typography component.\r\nThis can be useful to render an alternative Typography variant by wrapping\r\nthe `title` text, and optional `subheader` text\r\nwith the Typography component."
        },
        "subheader": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "subheaderTypographyProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "These props will be forwarded to the subheader\r\n(as long as disableTypography is not `true`)."
        },
        "title": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the Card Title."
        },
        "titleTypographyProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "These props will be forwarded to the title\r\n(as long as disableTypography is not `true`)."
        }
    }
}