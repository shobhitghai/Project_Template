/* eslint-disable */
export default {
    "displayName": "Portal",
    "description": "Portals provide a first-class way to render children into a DOM node\r\nthat exists outside the DOM hierarchy of the parent component.",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The children to render into the `container`."
        },
        "container": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "func"
                    },
                    {
                        "name": "instanceOf",
                        "value": "React.Component"
                    },
                    {
                        "name": "instanceOf",
                        "value": "typeof Element === 'undefined' ? Object : Element"
                    }
                ]
            },
            "required": false,
            "description": "A node, component instance, or function that returns either.\r\nThe `container` will have the portal children appended to it.\r\nBy default, it uses the body of the top-level document object,\r\nso it's simply `document.body` most of the time."
        },
        "disablePortal": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Disable the portal behavior.\r\nThe children stay within it's parent DOM hierarchy."
        },
        "onRendered": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired once the children has been mounted into the `container`.\r\n\nThis prop will be deprecated and removed in v5, the ref can be used instead."
        }
    }
}