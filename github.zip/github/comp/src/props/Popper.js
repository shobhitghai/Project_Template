/* eslint-disable */
export default {
    "displayName": "Popper",
    "description": "Poppers rely on the 3rd party library [Popper.js](https://github.com/FezVrasta/popper.js) for positioning.",
    "methods": [],
    "props": {
        "anchorEl": {
            "type": {
                "name": "custom",
                "raw": "chainPropTypes(PropTypes.oneOfType([PropTypes.object, PropTypes.func]), props => {\r\n  if (props.open) {\r\n    const resolvedAnchorEl = getAnchorEl(props.anchorEl);\r\n    const containerWindow = ownerWindow(resolvedAnchorEl);\r\n\r\n    if (resolvedAnchorEl instanceof containerWindow.Element) {\r\n      const box = resolvedAnchorEl.getBoundingClientRect();\r\n\r\n      if (\r\n        process.env.NODE_ENV !== 'test' &&\r\n        box.top === 0 &&\r\n        box.left === 0 &&\r\n        box.right === 0 &&\r\n        box.bottom === 0\r\n      ) {\r\n        return new Error(\r\n          [\r\n            'Material-UI: the `anchorEl` prop provided to the component is invalid.',\r\n            'The anchor element should be part of the document layout.',\r\n            \"Make sure the element is present in the document or that it's not display none.\",\r\n          ].join('\\n'),\r\n        );\r\n      }\r\n    } else if (\r\n      !resolvedAnchorEl ||\r\n      typeof resolvedAnchorEl.clientWidth !== 'number' ||\r\n      typeof resolvedAnchorEl.clientHeight !== 'number' ||\r\n      typeof resolvedAnchorEl.getBoundingClientRect !== 'function'\r\n    ) {\r\n      return new Error(\r\n        [\r\n          'Material-UI: the `anchorEl` prop provided to the component is invalid.',\r\n          'It should be an HTML Element instance or a referenceObject:',\r\n          'https://popper.js.org/popper-documentation.html#referenceObject.',\r\n        ].join('\\n'),\r\n      );\r\n    }\r\n  }\r\n\r\n  return null;\r\n})"
            },
            "required": false,
            "description": "This is the reference element, or a function that returns the reference element,\r\nthat may be used to set the position of the popover.\r\nThe return value will passed as the reference object of the Popper\r\ninstance.\r\n\nThe reference element should be an HTML Element instance or a referenceObject:\r\nhttps://popper.js.org/popper-documentation.html#referenceObject."
        },
        "children": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "node"
                    },
                    {
                        "name": "func"
                    }
                ]
            },
            "required": true,
            "description": "Popper render function or node."
        },
        "container": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "object"
                    },
                    {
                        "name": "func"
                    }
                ]
            },
            "required": false,
            "description": "A node, component instance, or function that returns either.\r\nThe `container` will passed to the Modal component.\r\nBy default, it uses the body of the anchorEl's top-level document object,\r\nso it's simply `document.body` most of the time."
        },
        "disablePortal": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Disable the portal behavior.\r\nThe children stay within it's parent DOM hierarchy."
        },
        "keepMounted": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Always keep the children in the DOM.\r\nThis prop can be useful in SEO situation or\r\nwhen you want to maximize the responsiveness of the Popper."
        },
        "modifiers": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Popper.js is based on a \"plugin-like\" architecture,\r\nmost of its features are fully encapsulated \"modifiers\".\r\n\nA modifier is a function that is called each time Popper.js needs to\r\ncompute the position of the popper.\r\nFor this reason, modifiers should be very performant to avoid bottlenecks.\r\nTo learn how to create a modifier, [read the modifiers documentation](https://github.com/FezVrasta/popper.js/blob/master/docs/_includes/popper-documentation.md#modifiers--object)."
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": true,
            "description": "If `true`, the popper is visible."
        },
        "placement": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'bottom-end'",
                        "computed": false
                    },
                    {
                        "value": "'bottom-start'",
                        "computed": false
                    },
                    {
                        "value": "'bottom'",
                        "computed": false
                    },
                    {
                        "value": "'left-end'",
                        "computed": false
                    },
                    {
                        "value": "'left-start'",
                        "computed": false
                    },
                    {
                        "value": "'left'",
                        "computed": false
                    },
                    {
                        "value": "'right-end'",
                        "computed": false
                    },
                    {
                        "value": "'right-start'",
                        "computed": false
                    },
                    {
                        "value": "'right'",
                        "computed": false
                    },
                    {
                        "value": "'top-end'",
                        "computed": false
                    },
                    {
                        "value": "'top-start'",
                        "computed": false
                    },
                    {
                        "value": "'top'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Popper placement."
        },
        "popperOptions": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Options provided to the [`popper.js`](https://github.com/FezVrasta/popper.js) instance."
        },
        "popperRef": {
            "type": {
                "name": "custom",
                "raw": "refType"
            },
            "required": false,
            "description": "A ref that points to the used popper instance."
        },
        "transition": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Help supporting a react-transition-group/Transition component."
        }
    }
}