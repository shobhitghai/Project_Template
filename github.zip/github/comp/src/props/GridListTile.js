/* eslint-disable */
export default {
    "displayName": "GridListTile",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Theoretically you can pass any node as children, but the main use case is to pass an img,\r\nin which case GridListTile takes care of making the image \"cover\" available space\r\n(similar to `background-size: cover` or to `object-fit: cover`)."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "cols": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Width of the tile in number of grid cells."
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "rows": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Height of the tile in number of grid cells."
        }
    }
}