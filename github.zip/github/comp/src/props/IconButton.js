/* eslint-disable */
export default {
    "displayName": "IconButton",
    "description": "Refer to the [Icons](/components/icons/) section of the documentation\r\nregarding the available icon options.",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "custom",
                "raw": "chainPropTypes(PropTypes.node, props => {\r\n  const found = React.Children.toArray(props.children).some(\r\n    child => React.isValidElement(child) && child.props.onClick,\r\n  );\r\n\r\n  if (found) {\r\n    return new Error(\r\n      [\r\n        'Material-UI: you are providing an onClick event listener ' +\r\n          'to a child of a button element.',\r\n        'Firefox will never trigger the event.',\r\n        'You should move the onClick listener to the parent button element.',\r\n        'https://github.com/mui-org/material-ui/issues/13957',\r\n      ].join('\\n'),\r\n    );\r\n  }\r\n\r\n  return null;\r\n})"
            },
            "required": false,
            "description": "The icon element."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'default'",
                        "computed": false
                    },
                    {
                        "value": "'inherit'",
                        "computed": false
                    },
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the button will be disabled."
        },
        "disableFocusRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the  keyboard focus ripple will be disabled.\r\n`disableRipple` must also be true."
        },
        "disableRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the ripple effect will be disabled."
        },
        "edge": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'start'",
                        "computed": false
                    },
                    {
                        "value": "'end'",
                        "computed": false
                    },
                    {
                        "value": "false",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "If given, uses a negative margin to counteract the padding on one\r\nside (this is often helpful for aligning the left or right\r\nside of the icon with content above or below, without ruining the border\r\nsize and shape)."
        },
        "size": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'small'",
                        "computed": false
                    },
                    {
                        "value": "'medium'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The size of the button.\r\n`small` is equivalent to the dense button styling."
        }
    }
}