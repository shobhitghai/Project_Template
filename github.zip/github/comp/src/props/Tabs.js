/* eslint-disable */
export default {
    "displayName": "Tabs",
    "description": "",
    "methods": [],
    "props": {
        "action": {
            "type": {
                "name": "custom",
                "raw": "refType"
            },
            "required": false,
            "description": "Callback fired when the component mounts.\r\nThis is useful when you want to trigger an action programmatically.\r\nIt supports two actions: `updateIndicator()` and `updateScrollButtons()`\r\n\n@param {object} actions This object contains all possible actions\r\nthat can be triggered programmatically."
        },
        "centered": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the tabs will be centered.\r\nThis property is intended for large views."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "indicatorColor": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'secondary'",
                        "computed": false
                    },
                    {
                        "value": "'primary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Determines the color of the indicator."
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the value changes.\r\n\n@param {object} event The event source of the callback\r\n@param {any} value We default to the index of the child (number)"
        },
        "orientation": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'horizontal'",
                        "computed": false
                    },
                    {
                        "value": "'vertical'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The tabs orientation (layout flow direction)."
        },
        "ScrollButtonComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used to render the scroll buttons."
        },
        "scrollButtons": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'auto'",
                        "computed": false
                    },
                    {
                        "value": "'desktop'",
                        "computed": false
                    },
                    {
                        "value": "'on'",
                        "computed": false
                    },
                    {
                        "value": "'off'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Determine behavior of scroll buttons when tabs are set to scroll:\r\n\n- `auto` will only present them when not all the items are visible.\r\n- `desktop` will only present them on medium and larger viewports.\r\n- `on` will always present them.\r\n- `off` will never present them."
        },
        "TabIndicatorProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the tab indicator element."
        },
        "textColor": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'secondary'",
                        "computed": false
                    },
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'inherit'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Determines the color of the `Tab`."
        },
        "value": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "The value of the currently selected `Tab`.\r\nIf you don't want any selected `Tab`, you can set this property to `false`."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'standard'",
                        "computed": false
                    },
                    {
                        "value": "'scrollable'",
                        "computed": false
                    },
                    {
                        "value": "'fullWidth'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Determines additional display behavior of the tabs:\r\n\n - `scrollable` will invoke scrolling properties and allow for horizontally\r\n scrolling (or swiping) of the tab bar.\r\n -`fullWidth` will make the tabs grow to use all the available space,\r\n which should be used for small views, like on mobile.\r\n - `standard` will render the default state."
        }
    }
}