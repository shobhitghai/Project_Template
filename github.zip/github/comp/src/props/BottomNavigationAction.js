/* eslint-disable */
export default {
    "displayName": "BottomNavigationAction",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "custom",
                "raw": "unsupportedProp"
            },
            "required": false,
            "description": "This prop isn't supported.\r\nUse the `component` prop if you need to change the children structure."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "icon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon element."
        },
        "label": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The label element."
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onClick": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "selected": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "showLabel": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the `BottomNavigationAction` will show its label.\r\nBy default, only the selected `BottomNavigationAction`\r\ninside `BottomNavigation` will show its label."
        },
        "value": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "You can provide your own value. Otherwise, we fallback to the child position index."
        }
    }
}