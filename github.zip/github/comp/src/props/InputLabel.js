/* eslint-disable */
export default {
    "displayName": "InputLabel",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The contents of the `InputLabel`."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "disableAnimation": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the transition animation is disabled."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, apply disabled class."
        },
        "error": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the label will be displayed in an error state."
        },
        "focused": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the input of this label is focused."
        },
        "margin": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'dense'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "If `dense`, will adjust vertical spacing. This is normally obtained via context from\r\nFormControl."
        },
        "required": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "if `true`, the label will indicate that the input is required."
        },
        "shrink": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the label is shrunk."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'standard'",
                        "computed": false
                    },
                    {
                        "value": "'outlined'",
                        "computed": false
                    },
                    {
                        "value": "'filled'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}