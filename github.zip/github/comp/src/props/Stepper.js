/* eslint-disable */
export default {
    "displayName": "Stepper",
    "description": "",
    "methods": [],
    "props": {
        "activeStep": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Set the active step (zero based index).\r\nSet to -1 to disable all the steps."
        },
        "alternativeLabel": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If set to 'true' and orientation is horizontal,\r\nthen the step label will be positioned under the icon."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "Two or more `<Step />` components."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "connector": {
            "type": {
                "name": "element"
            },
            "required": false,
            "description": "An element to be placed between each step."
        },
        "nonLinear": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If set the `Stepper` will not assist in controlling steps for linear flow."
        },
        "orientation": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'horizontal'",
                        "computed": false
                    },
                    {
                        "value": "'vertical'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The stepper orientation (layout flow direction)."
        }
    }
}