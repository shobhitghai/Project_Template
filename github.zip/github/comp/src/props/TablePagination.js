/* eslint-disable */
export default {
    "displayName": "TablePagination",
    "description": "A `TableCell` based component for placing inside `TableFooter` for pagination.",
    "methods": [],
    "props": {
        "ActionsComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for displaying the actions.\r\nEither a string to use a DOM element or a component."
        },
        "backIconButtonProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the back arrow [`IconButton`](/api/icon-button/) component."
        },
        "backIconButtonText": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Text label for the back arrow icon button.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "colSpan": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "count": {
            "type": {
                "name": "number"
            },
            "required": true,
            "description": "The total number of rows."
        },
        "labelDisplayedRows": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Customize the displayed rows label.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
        },
        "labelRowsPerPage": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Customize the rows per page label. Invoked with a `{ from, to, count, page }`\r\nobject.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
        },
        "nextIconButtonProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the next arrow [`IconButton`](/api/icon-button/) element."
        },
        "nextIconButtonText": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Text label for the next arrow icon button.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
        },
        "onChangePage": {
            "type": {
                "name": "func"
            },
            "required": true,
            "description": "Callback fired when the page is changed.\r\n\n@param {object} event The event source of the callback.\r\n@param {number} page The page selected."
        },
        "onChangeRowsPerPage": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the number of rows per page is changed.\r\n\n@param {object} event The event source of the callback."
        },
        "page": {
            "type": {
                "name": "custom",
                "raw": "chainPropTypes(PropTypes.number.isRequired, props => {\r\n  const { count, page, rowsPerPage } = props;\r\n  const newLastPage = Math.max(0, Math.ceil(count / rowsPerPage) - 1);\r\n  if (page < 0 || page > newLastPage) {\r\n    return new Error(\r\n      'Material-UI: the page prop of a TablePagination is out of range ' +\r\n        `(0 to ${newLastPage}, but page is ${page}).`,\r\n    );\r\n  }\r\n  return null;\r\n})"
            },
            "required": false,
            "description": "The zero-based index of the current page."
        },
        "rowsPerPage": {
            "type": {
                "name": "number"
            },
            "required": true,
            "description": "The number of rows per page."
        },
        "rowsPerPageOptions": {
            "type": {
                "name": "array"
            },
            "required": false,
            "description": "Customizes the options of the rows per page select field. If less than two options are\r\navailable, no select field will be displayed."
        },
        "SelectProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the rows per page [`Select`](/api/select/) element."
        }
    }
}