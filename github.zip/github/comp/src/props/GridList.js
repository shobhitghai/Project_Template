/* eslint-disable */
export default {
    "displayName": "GridList",
    "description": "",
    "methods": [],
    "props": {
        "cellHeight": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "enum",
                        "value": [
                            {
                                "value": "'auto'",
                                "computed": false
                            }
                        ]
                    }
                ]
            },
            "required": false,
            "description": "Number of px for one cell height.\r\nYou can set `'auto'` if you want to let the children determine the height."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "Grid Tiles that will be in Grid List."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "cols": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Number of columns."
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "spacing": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Number of px for the spacing between tiles."
        },
        "style": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "@ignore"
        }
    }
}