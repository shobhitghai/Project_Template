/* eslint-disable */
export default {
    "displayName": "Alert",
    "description": "",
    "methods": [],
    "props": {
        "action": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The action to display. It renders after the message, at the end of the alert."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "closeText": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Override the default label for the *close popup* icon button.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'error'",
                        "computed": false
                    },
                    {
                        "value": "'info'",
                        "computed": false
                    },
                    {
                        "value": "'success'",
                        "computed": false
                    },
                    {
                        "value": "'warning'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The main color for the alert. Unless provided, the value is taken from the `severity` prop."
        },
        "icon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Override the icon displayed before the children.\r\nUnless provided, the icon is mapped to the value of the `severity` prop."
        },
        "iconMapping": {
            "type": {
                "name": "shape",
                "value": {
                    "error": {
                        "name": "node",
                        "required": false
                    },
                    "info": {
                        "name": "node",
                        "required": false
                    },
                    "success": {
                        "name": "node",
                        "required": false
                    },
                    "warning": {
                        "name": "node",
                        "required": false
                    }
                }
            },
            "required": false,
            "description": "The component maps the `severity` prop to a range of different icons,\r\nfor instance success to `<SuccessOutlined>`.\r\nIf you wish to change this mapping, you can provide your own.\r\nAlternatively, you can use the `icon` prop to override the icon displayed."
        },
        "onClose": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component requests to be closed.\r\nWhen provided and no `action` prop is set, a close icon button is displayed that triggers the callback when clicked.\r\n\n@param {object} event The event source of the callback."
        },
        "role": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The ARIA role attribute of the element."
        },
        "severity": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'error'",
                        "computed": false
                    },
                    {
                        "value": "'info'",
                        "computed": false
                    },
                    {
                        "value": "'success'",
                        "computed": false
                    },
                    {
                        "value": "'warning'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The severity of the alert. This defines the color and icon used."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'filled'",
                        "computed": false
                    },
                    {
                        "value": "'outlined'",
                        "computed": false
                    },
                    {
                        "value": "'standard'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}