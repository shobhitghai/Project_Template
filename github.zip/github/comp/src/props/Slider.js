/* eslint-disable */
export default {
    "displayName": "Slider",
    "description": "",
    "methods": [],
    "props": {
        "aria-label": {
            "type": {
                "name": "custom",
                "raw": "chainPropTypes(PropTypes.string, props => {\r\n  const range = Array.isArray(props.value || props.defaultValue);\r\n\r\n  if (range && props['aria-label'] != null) {\r\n    return new Error(\r\n      'Material-UI: you need to use the `getAriaLabel` prop instead of `aria-label` when using a range slider.',\r\n    );\r\n  }\r\n\r\n  return null;\r\n})"
            },
            "required": false,
            "description": "The label of the slider."
        },
        "aria-labelledby": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The id of the element containing a label for the slider."
        },
        "aria-valuetext": {
            "type": {
                "name": "custom",
                "raw": "chainPropTypes(PropTypes.string, props => {\r\n  const range = Array.isArray(props.value || props.defaultValue);\r\n\r\n  if (range && props['aria-valuetext'] != null) {\r\n    return new Error(\r\n      'Material-UI: you need to use the `getAriaValueText` prop instead of `aria-valuetext` when using a range slider.',\r\n    );\r\n  }\r\n\r\n  return null;\r\n})"
            },
            "required": false,
            "description": "A string value that provides a user-friendly name for the current value of the slider."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "defaultValue": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "arrayOf",
                        "value": {
                            "name": "number"
                        }
                    }
                ]
            },
            "required": false,
            "description": "The default element value. Use when the component is not controlled."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the slider will be disabled."
        },
        "getAriaLabel": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Accepts a function which returns a string value that provides a user-friendly name for the thumb labels of the slider.\r\n\n@param {number} index The thumb label's index to format.\r\n@returns {string}"
        },
        "getAriaValueText": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Accepts a function which returns a string value that provides a user-friendly name for the current value of the slider.\r\n\n@param {number} value The thumb label's value to format.\r\n@param {number} index The thumb label's index to format.\r\n@returns {string}"
        },
        "marks": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "bool"
                    },
                    {
                        "name": "array"
                    }
                ]
            },
            "required": false,
            "description": "Marks indicate predetermined values to which the user can move the slider.\r\nIf `true` the marks will be spaced according the value of the `step` prop.\r\nIf an array, it should contain objects with `value` and an optional `label` keys."
        },
        "max": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The maximum allowed value of the slider.\r\nShould not be equal to min."
        },
        "min": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The minimum allowed value of the slider.\r\nShould not be equal to max."
        },
        "name": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Name attribute of the hidden `input` element."
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback function that is fired when the slider's value changed.\r\n\n@param {object} event The event source of the callback.\r\n@param {any} value The new value."
        },
        "onChangeCommitted": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback function that is fired when the `mouseup` is triggered.\r\n\n@param {object} event The event source of the callback.\r\n@param {any} value The new value."
        },
        "onMouseDown": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "orientation": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'horizontal'",
                        "computed": false
                    },
                    {
                        "value": "'vertical'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The slider orientation."
        },
        "scale": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "A transformation function, to change the scale of the slider."
        },
        "step": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The granularity with which the slider can step through values. (A \"discrete\" slider.)\r\nThe `min` prop serves as the origin for the valid values.\r\nWe recommend (max - min) to be evenly divisible by the step.\r\n\nWhen step is `null`, the thumb can only be slid onto marks provided with the `marks` prop."
        },
        "ThumbComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used to display the value label."
        },
        "track": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'normal'",
                        "computed": false
                    },
                    {
                        "value": "false",
                        "computed": false
                    },
                    {
                        "value": "'inverted'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The track presentation:\r\n\n- `normal` the track will render a bar representing the slider value.\r\n- `inverted` the track will render a bar representing the remaining slider value.\r\n- `false` the track will render without a bar."
        },
        "value": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "arrayOf",
                        "value": {
                            "name": "number"
                        }
                    }
                ]
            },
            "required": false,
            "description": "The value of the slider.\r\nFor ranged sliders, provide an array with two values."
        },
        "ValueLabelComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The value label component."
        },
        "valueLabelDisplay": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'on'",
                        "computed": false
                    },
                    {
                        "value": "'auto'",
                        "computed": false
                    },
                    {
                        "value": "'off'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Controls when the value label is displayed:\r\n\n- `auto` the value label will display when the thumb is hovered or focused.\r\n- `on` will display persistently.\r\n- `off` will never display."
        },
        "valueLabelFormat": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "string"
                    },
                    {
                        "name": "func"
                    }
                ]
            },
            "required": false,
            "description": "The format function the value label's value.\r\n\nWhen a function is provided, it should have the following signature:\r\n\n- {number} value The value label's value to format\r\n- {number} index The value label's index to format"
        }
    }
}