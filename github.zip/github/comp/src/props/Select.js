/* eslint-disable */
export default {
    "displayName": "Select",
    "description": "",
    "methods": [],
    "props": {
        "autoWidth": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the width of the popover will automatically be set according to the items inside the\r\nmenu, otherwise it will be at least the width of the select input."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The option elements to populate the select with.\r\nCan be some `MenuItem` when `native` is false and `option` when `native` is true.\r\n\n⚠️The `MenuItem` elements **must** be direct descendants when `native` is false."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "defaultValue": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "The default element value. Use when the component is not controlled."
        },
        "displayEmpty": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, a value is displayed even if no items are selected.\r\n\nIn order to display a meaningful value, a function should be passed to the `renderValue` prop which returns the value to be displayed when no items are selected.\r\nYou can only use it when the `native` prop is `false` (default)."
        },
        "IconComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The icon that displays the arrow."
        },
        "id": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "input": {
            "type": {
                "name": "element"
            },
            "required": false,
            "description": "An `Input` element; does not have to be a material-ui specific `Input`."
        },
        "inputProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "[Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Attributes) applied to the `input` element.\r\nWhen `native` is `true`, the attributes are applied on the `select` element."
        },
        "label": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "See [OutlinedLabel#label](/api/outlined-input/#props)"
        },
        "labelId": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The idea of an element that acts as an additional label. The Select will\r\nbe labelled by the additional label and the selected value."
        },
        "labelWidth": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "See OutlinedLabel#label"
        },
        "MenuProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Menu`](/api/menu/) element."
        },
        "multiple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, `value` must be an array and the menu will support multiple selections."
        },
        "native": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the component will be using a native `select` element."
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback function fired when a menu item is selected.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new value by accessing `event.target.value` (any).\r\n@param {object} [child] The react element that was selected when `native` is `false` (default)."
        },
        "onClose": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component requests to be closed.\r\nUse in controlled mode (see open).\r\n\n@param {object} event The event source of the callback."
        },
        "onOpen": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component requests to be opened.\r\nUse in controlled mode (see open).\r\n\n@param {object} event The event source of the callback."
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Control `select` open state.\r\nYou can only use it when the `native` prop is `false` (default)."
        },
        "renderValue": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Render the selected value.\r\nYou can only use it when the `native` prop is `false` (default).\r\n\n@param {any} value The `value` provided to the component.\r\n@returns {ReactNode}"
        },
        "SelectDisplayProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the clickable div element."
        },
        "value": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "The input value. Providing an empty string will select no options.\r\nThis prop is required when the `native` prop is `false` (default).\r\nSet to an empty string `''` if you don't want any of the available options to be selected.\r\n\nIf the value is an object it must have reference equality with the option in order to be selected.\r\nIf the value is not an object, the string representation must match with the string representation of the option in order to be selected."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'standard'",
                        "computed": false
                    },
                    {
                        "value": "'outlined'",
                        "computed": false
                    },
                    {
                        "value": "'filled'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}