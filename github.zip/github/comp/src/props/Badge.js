/* eslint-disable */
export default {
    "displayName": "Badge",
    "description": "",
    "methods": [],
    "props": {
        "anchorOrigin": {
            "type": {
                "name": "shape",
                "value": {
                    "horizontal": {
                        "name": "enum",
                        "value": [
                            {
                                "value": "'left'",
                                "computed": false
                            },
                            {
                                "value": "'right'",
                                "computed": false
                            }
                        ],
                        "required": true
                    },
                    "vertical": {
                        "name": "enum",
                        "value": [
                            {
                                "value": "'bottom'",
                                "computed": false
                            },
                            {
                                "value": "'top'",
                                "computed": false
                            }
                        ],
                        "required": true
                    }
                }
            },
            "required": false,
            "description": "The anchor of the badge."
        },
        "badgeContent": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content rendered within the badge."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The badge will be added relative to this node."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'default'",
                        "computed": false
                    },
                    {
                        "value": "'error'",
                        "computed": false
                    },
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "invisible": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the badge will be invisible."
        },
        "max": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Max count to show."
        },
        "overlap": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'circle'",
                        "computed": false
                    },
                    {
                        "value": "'rectangle'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Wrapped shape the badge should overlap."
        },
        "showZero": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Controls whether the badge is hidden when `badgeContent` is zero."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'dot'",
                        "computed": false
                    },
                    {
                        "value": "'standard'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}