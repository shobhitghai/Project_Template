/* eslint-disable */
export default {
    "displayName": "CssBaseline",
    "description": "Kickstart an elegant, consistent, and simple baseline to build upon.",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "You can wrap a node."
        }
    }
}