/* eslint-disable */
export default {
    "displayName": "ListItemAvatar",
    "description": "A simple wrapper to apply `List` styles to an `Avatar`.",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "element"
            },
            "required": true,
            "description": "The content of the component – normally `Avatar`."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        }
    }
}