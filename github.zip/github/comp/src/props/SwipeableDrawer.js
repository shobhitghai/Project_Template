/* eslint-disable */
export default {
    "displayName": "SwipeableDrawer",
    "description": "",
    "methods": [],
    "props": {
        "anchor": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'left'",
                        "computed": false
                    },
                    {
                        "value": "'top'",
                        "computed": false
                    },
                    {
                        "value": "'right'",
                        "computed": false
                    },
                    {
                        "value": "'bottom'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "@ignore"
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "disableBackdropTransition": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Disable the backdrop transition.\r\nThis can improve the FPS on low-end devices."
        },
        "disableDiscovery": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, touching the screen near the edge of the drawer will not slide in the drawer a bit\r\nto promote accidental discovery of the swipe gesture."
        },
        "disableSwipeToOpen": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, swipe to open is disabled. This is useful in browsers where swiping triggers\r\nnavigation actions. Swipe to open is disabled on iOS browsers by default."
        },
        "hideBackdrop": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "hysteresis": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Affects how far the drawer must be opened/closed to change his state.\r\nSpecified as percent (0-1) of the width of the drawer"
        },
        "minFlingVelocity": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Defines, from which (average) velocity on, the swipe is\r\ndefined as complete although hysteresis isn't reached.\r\nGood threshold is between 250 - 1000 px/s"
        },
        "ModalProps": {
            "type": {
                "name": "shape",
                "value": {
                    "BackdropProps": {
                        "name": "shape",
                        "value": {
                            "component": {
                                "name": "custom",
                                "raw": "elementTypeAcceptingRef",
                                "required": false
                            }
                        },
                        "required": false
                    }
                }
            },
            "required": false,
            "description": "@ignore"
        },
        "onClose": {
            "type": {
                "name": "func"
            },
            "required": true,
            "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback."
        },
        "onOpen": {
            "type": {
                "name": "func"
            },
            "required": true,
            "description": "Callback fired when the component requests to be opened.\r\n\n@param {object} event The event source of the callback."
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": true,
            "description": "If `true`, the drawer is open."
        },
        "PaperProps": {
            "type": {
                "name": "shape",
                "value": {
                    "component": {
                        "name": "custom",
                        "raw": "elementTypeAcceptingRef",
                        "required": false
                    },
                    "style": {
                        "name": "object",
                        "required": false
                    }
                }
            },
            "required": false,
            "description": "@ignore"
        },
        "SwipeAreaProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the swipe area element."
        },
        "swipeAreaWidth": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The width of the left most (or right most) area in pixels where the\r\ndrawer can be swiped open from."
        },
        "transitionDuration": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "shape",
                        "value": {
                            "enter": {
                                "name": "number",
                                "required": false
                            },
                            "exit": {
                                "name": "number",
                                "required": false
                            }
                        }
                    }
                ]
            },
            "required": false,
            "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'permanent'",
                        "computed": false
                    },
                    {
                        "value": "'persistent'",
                        "computed": false
                    },
                    {
                        "value": "'temporary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "@ignore"
        }
    }
}