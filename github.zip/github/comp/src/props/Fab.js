/* eslint-disable */
export default {
    "displayName": "Fab",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "The content of the button."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'default'",
                        "computed": false
                    },
                    {
                        "value": "'inherit'",
                        "computed": false
                    },
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the button will be disabled."
        },
        "disableFocusRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the  keyboard focus ripple will be disabled.\r\n`disableRipple` must also be true."
        },
        "disableRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the ripple effect will be disabled."
        },
        "focusVisibleClassName": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "href": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The URL to link to when the button is clicked.\r\nIf defined, an `a` element will be used as the root node."
        },
        "size": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'small'",
                        "computed": false
                    },
                    {
                        "value": "'medium'",
                        "computed": false
                    },
                    {
                        "value": "'large'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The size of the button.\r\n`small` is equivalent to the dense button styling."
        },
        "type": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'round'",
                        "computed": false
                    },
                    {
                        "value": "'extended'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}