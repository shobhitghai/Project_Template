/* eslint-disable */
export default {
    "displayName": "Link",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "The content of the link."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'default'",
                        "computed": false
                    },
                    {
                        "value": "'error'",
                        "computed": false
                    },
                    {
                        "value": "'inherit'",
                        "computed": false
                    },
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    },
                    {
                        "value": "'textPrimary'",
                        "computed": false
                    },
                    {
                        "value": "'textSecondary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the link."
        },
        "component": {
            "type": {
                "name": "custom",
                "raw": "elementTypeAcceptingRef"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "onBlur": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onFocus": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "TypographyClasses": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "`classes` prop applied to the [`Typography`](/api/typography/) element."
        },
        "underline": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'none'",
                        "computed": false
                    },
                    {
                        "value": "'hover'",
                        "computed": false
                    },
                    {
                        "value": "'always'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Controls when the link should have an underline."
        },
        "variant": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Applies the theme typography styles."
        }
    }
}