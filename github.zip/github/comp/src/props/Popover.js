/* eslint-disable */
export default {
    "displayName": "Popover",
    "description": "",
    "methods": [],
    "props": {
        "action": {
            "type": {
                "name": "custom",
                "raw": "refType"
            },
            "required": false,
            "description": "A ref for imperative actions.\r\nIt currently only supports updatePosition() action."
        },
        "anchorEl": {
            "type": {
                "name": "custom",
                "raw": "chainPropTypes(PropTypes.oneOfType([PropTypes.object, PropTypes.func]), props => {\r\n  if (props.open && (!props.anchorReference || props.anchorReference === 'anchorEl')) {\r\n    const resolvedAnchorEl = getAnchorEl(props.anchorEl);\r\n    const containerWindow = ownerWindow(resolvedAnchorEl);\r\n\r\n    if (resolvedAnchorEl instanceof containerWindow.Element) {\r\n      const box = resolvedAnchorEl.getBoundingClientRect();\r\n\r\n      if (\r\n        process.env.NODE_ENV !== 'test' &&\r\n        box.top === 0 &&\r\n        box.left === 0 &&\r\n        box.right === 0 &&\r\n        box.bottom === 0\r\n      ) {\r\n        return new Error(\r\n          [\r\n            'Material-UI: the `anchorEl` prop provided to the component is invalid.',\r\n            'The anchor element should be part of the document layout.',\r\n            \"Make sure the element is present in the document or that it's not display none.\",\r\n          ].join('\\n'),\r\n        );\r\n      }\r\n    } else {\r\n      return new Error(\r\n        [\r\n          'Material-UI: the `anchorEl` prop provided to the component is invalid.',\r\n          `It should be an Element instance but it's \\`${resolvedAnchorEl}\\` instead.`,\r\n        ].join('\\n'),\r\n      );\r\n    }\r\n  }\r\n\r\n  return null;\r\n})"
            },
            "required": false,
            "description": "This is the DOM element, or a function that returns the DOM element,\r\nthat may be used to set the position of the popover."
        },
        "anchorOrigin": {
            "type": {
                "name": "shape",
                "value": {
                    "horizontal": {
                        "name": "union",
                        "value": [
                            {
                                "name": "number"
                            },
                            {
                                "name": "enum",
                                "value": [
                                    {
                                        "value": "'left'",
                                        "computed": false
                                    },
                                    {
                                        "value": "'center'",
                                        "computed": false
                                    },
                                    {
                                        "value": "'right'",
                                        "computed": false
                                    }
                                ]
                            }
                        ],
                        "required": true
                    },
                    "vertical": {
                        "name": "union",
                        "value": [
                            {
                                "name": "number"
                            },
                            {
                                "name": "enum",
                                "value": [
                                    {
                                        "value": "'top'",
                                        "computed": false
                                    },
                                    {
                                        "value": "'center'",
                                        "computed": false
                                    },
                                    {
                                        "value": "'bottom'",
                                        "computed": false
                                    }
                                ]
                            }
                        ],
                        "required": true
                    }
                }
            },
            "required": false,
            "description": "This is the point on the anchor where the popover's\r\n`anchorEl` will attach to. This is not used when the\r\nanchorReference is 'anchorPosition'.\r\n\nOptions:\r\nvertical: [top, center, bottom];\r\nhorizontal: [left, center, right]."
        },
        "anchorPosition": {
            "type": {
                "name": "shape",
                "value": {
                    "left": {
                        "name": "number",
                        "required": true
                    },
                    "top": {
                        "name": "number",
                        "required": true
                    }
                }
            },
            "required": false,
            "description": "This is the position that may be used\r\nto set the position of the popover.\r\nThe coordinates are relative to\r\nthe application's client area."
        },
        "anchorReference": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'anchorEl'",
                        "computed": false
                    },
                    {
                        "value": "'anchorPosition'",
                        "computed": false
                    },
                    {
                        "value": "'none'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": ""
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "container": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "object"
                    },
                    {
                        "name": "func"
                    }
                ]
            },
            "required": false,
            "description": "A node, component instance, or function that returns either.\r\nThe `container` will passed to the Modal component.\r\nBy default, it uses the body of the anchorEl's top-level document object,\r\nso it's simply `document.body` most of the time."
        },
        "elevation": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The elevation of the popover."
        },
        "getContentAnchorEl": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "This function is called in order to retrieve the content anchor element.\r\nIt's the opposite of the `anchorEl` prop.\r\nThe content anchor element should be an element inside the popover.\r\nIt's used to correctly scroll and set the position of the popover.\r\nThe positioning strategy tries to make the content anchor element just above the\r\nanchor element."
        },
        "marginThreshold": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Specifies how close to the edge of the window the popover can appear."
        },
        "onClose": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"escapeKeyDown\"`, `\"backdropClick\"`."
        },
        "onEnter": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired before the component is entering."
        },
        "onEntered": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component has entered."
        },
        "onEntering": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component is entering."
        },
        "onExit": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired before the component is exiting."
        },
        "onExited": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component has exited."
        },
        "onExiting": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component is exiting."
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": true,
            "description": "If `true`, the popover is visible."
        },
        "PaperProps": {
            "type": {
                "name": "shape",
                "value": {
                    "component": {
                        "name": "custom",
                        "raw": "elementTypeAcceptingRef",
                        "required": false
                    }
                }
            },
            "required": false,
            "description": "Props applied to the [`Paper`](/api/paper/) element."
        },
        "transformOrigin": {
            "type": {
                "name": "shape",
                "value": {
                    "horizontal": {
                        "name": "union",
                        "value": [
                            {
                                "name": "number"
                            },
                            {
                                "name": "enum",
                                "value": [
                                    {
                                        "value": "'left'",
                                        "computed": false
                                    },
                                    {
                                        "value": "'center'",
                                        "computed": false
                                    },
                                    {
                                        "value": "'right'",
                                        "computed": false
                                    }
                                ]
                            }
                        ],
                        "required": true
                    },
                    "vertical": {
                        "name": "union",
                        "value": [
                            {
                                "name": "number"
                            },
                            {
                                "name": "enum",
                                "value": [
                                    {
                                        "value": "'top'",
                                        "computed": false
                                    },
                                    {
                                        "value": "'center'",
                                        "computed": false
                                    },
                                    {
                                        "value": "'bottom'",
                                        "computed": false
                                    }
                                ]
                            }
                        ],
                        "required": true
                    }
                }
            },
            "required": false,
            "description": "This is the point on the popover which\r\nwill attach to the anchor's origin.\r\n\nOptions:\r\nvertical: [top, center, bottom, x(px)];\r\nhorizontal: [left, center, right, x(px)]."
        },
        "TransitionComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
        },
        "transitionDuration": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "shape",
                        "value": {
                            "enter": {
                                "name": "number",
                                "required": false
                            },
                            "exit": {
                                "name": "number",
                                "required": false
                            }
                        }
                    },
                    {
                        "name": "enum",
                        "value": [
                            {
                                "value": "'auto'",
                                "computed": false
                            }
                        ]
                    }
                ]
            },
            "required": false,
            "description": "Set to 'auto' to automatically calculate transition time based on height."
        },
        "TransitionProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
        }
    }
}