/* eslint-disable */
export default {
    "displayName": "ExpansionPanelSummary",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the expansion panel summary."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "expandIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon to display as the expand indicator."
        },
        "IconButtonProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the `IconButton` element wrapping the expand icon."
        },
        "onBlur": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onClick": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onFocusVisible": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        }
    }
}