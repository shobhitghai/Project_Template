/* eslint-disable */
export default {
    "displayName": "Drawer",
    "description": "The props of the [Modal](/api/modal/) component are available\r\nwhen `variant=\"temporary\"` is set.",
    "methods": [],
    "props": {
        "anchor": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'left'",
                        "computed": false
                    },
                    {
                        "value": "'top'",
                        "computed": false
                    },
                    {
                        "value": "'right'",
                        "computed": false
                    },
                    {
                        "value": "'bottom'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Side from which the drawer will appear."
        },
        "BackdropProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "@ignore"
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The contents of the drawer."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "elevation": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The elevation of the drawer."
        },
        "ModalProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Modal`](/api/modal/) element."
        },
        "onClose": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback."
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the drawer is open."
        },
        "PaperProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Paper`](/api/paper/) element."
        },
        "SlideProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Slide`](/api/slide/) element."
        },
        "transitionDuration": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "shape",
                        "value": {
                            "enter": {
                                "name": "number",
                                "required": false
                            },
                            "exit": {
                                "name": "number",
                                "required": false
                            }
                        }
                    }
                ]
            },
            "required": false,
            "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'permanent'",
                        "computed": false
                    },
                    {
                        "value": "'persistent'",
                        "computed": false
                    },
                    {
                        "value": "'temporary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}