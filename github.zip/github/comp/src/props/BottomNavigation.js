/* eslint-disable */
export default {
    "displayName": "BottomNavigation",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the value changes.\r\n\n@param {object} event The event source of the callback.\r\n@param {any} value We default to the index of the child."
        },
        "showLabels": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, all `BottomNavigationAction`s will show their labels.\r\nBy default, only the selected `BottomNavigationAction` will show its label."
        },
        "value": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "The value of the currently selected `BottomNavigationAction`."
        }
    }
}