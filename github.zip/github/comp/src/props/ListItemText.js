/* eslint-disable */
export default {
    "displayName": "ListItemText",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Alias for the `primary` property."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "disableTypography": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the children won't be wrapped by a Typography component.\r\nThis can be useful to render an alternative Typography variant by wrapping\r\nthe `children` (or `primary`) text, and optional `secondary` text\r\nwith the Typography component."
        },
        "inset": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the children will be indented.\r\nThis should be used if there is no left avatar or left icon."
        },
        "primary": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The main content element."
        },
        "primaryTypographyProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "These props will be forwarded to the primary typography component\r\n(as long as disableTypography is not `true`)."
        },
        "secondary": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The secondary content element."
        },
        "secondaryTypographyProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "These props will be forwarded to the secondary typography component\r\n(as long as disableTypography is not `true`)."
        }
    }
}