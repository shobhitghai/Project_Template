/* eslint-disable */
export default {
    "displayName": "Icon",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The name of the icon font ligature."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'inherit'",
                        "computed": false
                    },
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    },
                    {
                        "value": "'action'",
                        "computed": false
                    },
                    {
                        "value": "'error'",
                        "computed": false
                    },
                    {
                        "value": "'disabled'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "fontSize": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'inherit'",
                        "computed": false
                    },
                    {
                        "value": "'default'",
                        "computed": false
                    },
                    {
                        "value": "'small'",
                        "computed": false
                    },
                    {
                        "value": "'large'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The fontSize applied to the icon. Defaults to 24px, but can be configure to inherit font size."
        }
    }
}