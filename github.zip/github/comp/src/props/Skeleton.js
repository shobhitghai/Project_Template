/* eslint-disable */
export default {
    "displayName": "Skeleton",
    "description": "",
    "methods": [],
    "props": {
        "animation": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'pulse'",
                        "computed": false
                    },
                    {
                        "value": "'wave'",
                        "computed": false
                    },
                    {
                        "value": "false",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The animation.\r\nIf `false` the animation effect is disabled."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "height": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "string"
                    }
                ]
            },
            "required": false,
            "description": "Height of the skeleton.\r\nUseful when you don't want to adapt the skeleton to a text element but for instance a card."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'text'",
                        "computed": false
                    },
                    {
                        "value": "'rect'",
                        "computed": false
                    },
                    {
                        "value": "'circle'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The type of content that will be rendered."
        },
        "width": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "string"
                    }
                ]
            },
            "required": false,
            "description": "Width of the skeleton.\r\nUseful when the skeleton is inside an inline element with no width of its own."
        }
    }
}