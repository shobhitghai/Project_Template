/* eslint-disable */
export default {
    "displayName": "Breadcrumbs",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "The breadcrumb children."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component.\r\nBy default, it maps the variant to a good default headline component."
        },
        "itemsAfterCollapse": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "If max items is exceeded, the number of items to show after the ellipsis."
        },
        "itemsBeforeCollapse": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "If max items is exceeded, the number of items to show before the ellipsis."
        },
        "maxItems": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "Specifies the maximum number of breadcrumbs to display. When there are more\r\nthan the maximum number, only the first `itemsBeforeCollapse` and last `itemsAfterCollapse`\r\nwill be shown, with an ellipsis in between."
        },
        "separator": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Custom separator node."
        }
    }
}