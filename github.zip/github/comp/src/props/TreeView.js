/* eslint-disable */
export default {
    "displayName": "TreeView",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "defaultCollapseIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The default icon used to collapse the node."
        },
        "defaultEndIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The default icon displayed next to a end node. This is applied to all\r\ntree nodes and can be overridden by the TreeItem `icon` prop."
        },
        "defaultExpanded": {
            "type": {
                "name": "arrayOf",
                "value": {
                    "name": "string"
                }
            },
            "required": false,
            "description": "Expanded node ids. (Uncontrolled)"
        },
        "defaultExpandIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The default icon used to expand the node."
        },
        "defaultParentIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The default icon displayed next to a parent node. This is applied to all\r\nparent nodes and can be overridden by the TreeItem `icon` prop."
        },
        "expanded": {
            "type": {
                "name": "arrayOf",
                "value": {
                    "name": "string"
                }
            },
            "required": false,
            "description": "Expanded node ids. (Controlled)"
        },
        "onNodeToggle": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when tree items are expanded/collapsed.\r\n\n@param {object} event The event source of the callback.\r\n@param {array} nodeIds The ids of the expanded nodes."
        }
    }
}