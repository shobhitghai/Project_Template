/* eslint-disable */
export default {
    "displayName": "LinearProgress",
    "description": "## ARIA\r\n\nIf the progress bar is describing the loading progress of a particular region of a page,\r\nyou should use `aria-describedby` to point to the progress bar, and set the `aria-busy`\r\nattribute to `true` on that region until it has finished loading.",
    "methods": [],
    "props": {
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "value": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The value of the progress indicator for the determinate and buffer variants.\r\nValue between 0 and 100."
        },
        "valueBuffer": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "The value for the buffer variant.\r\nValue between 0 and 100."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'determinate'",
                        "computed": false
                    },
                    {
                        "value": "'indeterminate'",
                        "computed": false
                    },
                    {
                        "value": "'buffer'",
                        "computed": false
                    },
                    {
                        "value": "'query'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use.\r\nUse indeterminate or query when there is no progress value."
        }
    }
}