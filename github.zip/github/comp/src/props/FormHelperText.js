/* eslint-disable */
export default {
    "displayName": "FormHelperText",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component.\r\n\nIf `' '` is provided, the component reserves one line height for displaying a future message."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the helper text should be displayed in a disabled state."
        },
        "error": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, helper text should be displayed in an error state."
        },
        "filled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the helper text should use filled classes key."
        },
        "focused": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the helper text should use focused classes key."
        },
        "margin": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'dense'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "If `dense`, will adjust vertical spacing. This is normally obtained via context from\r\nFormControl."
        },
        "required": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the helper text should use required classes key."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'standard'",
                        "computed": false
                    },
                    {
                        "value": "'outlined'",
                        "computed": false
                    },
                    {
                        "value": "'filled'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}