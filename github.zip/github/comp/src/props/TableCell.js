/* eslint-disable */
export default {
    "displayName": "TableCell",
    "description": "The component renders a `<th>` element when the parent context is a header\r\nor otherwise a `<td>` element.",
    "methods": [],
    "props": {
        "align": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'inherit'",
                        "computed": false
                    },
                    {
                        "value": "'left'",
                        "computed": false
                    },
                    {
                        "value": "'center'",
                        "computed": false
                    },
                    {
                        "value": "'right'",
                        "computed": false
                    },
                    {
                        "value": "'justify'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Set the text-align on the table cell content.\r\n\nMonetary or generally number fields **should be right aligned** as that allows\r\nyou to add them up quickly in your head without having to worry about decimals."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The table cell contents."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "padding": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'default'",
                        "computed": false
                    },
                    {
                        "value": "'checkbox'",
                        "computed": false
                    },
                    {
                        "value": "'none'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Sets the padding applied to the cell.\r\nBy default, the Table parent component set the value (`default`)."
        },
        "scope": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Set scope attribute."
        },
        "size": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'small'",
                        "computed": false
                    },
                    {
                        "value": "'medium'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Specify the size of the cell.\r\nBy default, the Table parent component set the value (`medium`)."
        },
        "sortDirection": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'asc'",
                        "computed": false
                    },
                    {
                        "value": "'desc'",
                        "computed": false
                    },
                    {
                        "value": "false",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Set aria-sort direction."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'head'",
                        "computed": false
                    },
                    {
                        "value": "'body'",
                        "computed": false
                    },
                    {
                        "value": "'footer'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Specify the cell type.\r\nBy default, the TableHead, TableBody or TableFooter parent component set the value."
        }
    }
}