/* eslint-disable */
export default {
    "displayName": "Modal",
    "description": "Modal is a lower-level construct that is leveraged by the following components:\r\n\n- [Dialog](/api/dialog/)\r\n- [Drawer](/api/drawer/)\r\n- [Menu](/api/menu/)\r\n- [Popover](/api/popover/)\r\n\nIf you are creating a modal dialog, you probably want to use the [Dialog](/api/dialog/) component\r\nrather than directly using Modal.\r\n\nThis component shares many concepts with [react-overlays](https://react-bootstrap.github.io/react-overlays/#modals).",
    "methods": [],
    "props": {
        "BackdropComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "A backdrop component. This prop enables custom backdrop rendering."
        },
        "BackdropProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Backdrop`](/api/backdrop/) element."
        },
        "children": {
            "type": {
                "name": "custom",
                "raw": "elementAcceptingRef.isRequired"
            },
            "required": false,
            "description": "A single child content element."
        },
        "closeAfterTransition": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "When set to true the Modal waits until a nested Transition is completed before closing."
        },
        "container": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "object"
                    },
                    {
                        "name": "func"
                    }
                ]
            },
            "required": false,
            "description": "A node, component instance, or function that returns either.\r\nThe `container` will have the portal children appended to it."
        },
        "disableAutoFocus": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the modal will not automatically shift focus to itself when it opens, and\r\nreplace it to the last focused element when it closes.\r\nThis also works correctly with any modal children that have the `disableAutoFocus` prop.\r\n\nGenerally this should never be set to `true` as it makes the modal less\r\naccessible to assistive technologies, like screen readers."
        },
        "disableBackdropClick": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, clicking the backdrop will not fire any callback."
        },
        "disableEnforceFocus": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the modal will not prevent focus from leaving the modal while open.\r\n\nGenerally this should never be set to `true` as it makes the modal less\r\naccessible to assistive technologies, like screen readers."
        },
        "disableEscapeKeyDown": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, hitting escape will not fire any callback."
        },
        "disablePortal": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Disable the portal behavior.\r\nThe children stay within it's parent DOM hierarchy."
        },
        "disableRestoreFocus": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the modal will not restore focus to previously focused element once\r\nmodal is hidden."
        },
        "disableScrollLock": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Disable the scroll lock behavior."
        },
        "hideBackdrop": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the backdrop is not rendered."
        },
        "keepMounted": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Always keep the children in the DOM.\r\nThis prop can be useful in SEO situation or\r\nwhen you want to maximize the responsiveness of the Modal."
        },
        "manager": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "@ignore"
        },
        "onBackdropClick": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the backdrop is clicked."
        },
        "onClose": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component requests to be closed.\r\nThe `reason` parameter can optionally be used to control the response to `onClose`.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"escapeKeyDown\"`, `\"backdropClick\"`."
        },
        "onEscapeKeyDown": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the escape key is pressed,\r\n`disableEscapeKeyDown` is false and the modal is in focus."
        },
        "onRendered": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired once the children has been mounted into the `container`.\r\nIt signals that the `open={true}` prop took effect.\r\n\nThis prop will be deprecated and removed in v5, the ref can be used instead."
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": true,
            "description": "If `true`, the modal is open."
        }
    }
}