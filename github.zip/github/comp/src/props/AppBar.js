/* eslint-disable */
export default {
    "displayName": "AppBar",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'default'",
                        "computed": false
                    },
                    {
                        "value": "'inherit'",
                        "computed": false
                    },
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "position": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'absolute'",
                        "computed": false
                    },
                    {
                        "value": "'fixed'",
                        "computed": false
                    },
                    {
                        "value": "'relative'",
                        "computed": false
                    },
                    {
                        "value": "'static'",
                        "computed": false
                    },
                    {
                        "value": "'sticky'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The positioning type. The behavior of the different options is described\r\n[in the MDN web docs](https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Positioning).\r\nNote: `sticky` is not universally supported and will fall back to `static` when unavailable."
        }
    }
}