/* eslint-disable */
export default {
    "displayName": "MenuList",
    "description": "A permanently displayed menu following https://www.w3.org/TR/wai-aria-practices/#menubutton\r\nIt's exposed to help customization of the [`Menu`](/api/menu/) component. If you\r\nuse it separately you need to move focus into the component manually. Once\r\nthe focus is placed inside the component it is fully keyboard accessible.",
    "methods": [],
    "props": {
        "actions": {
            "type": {
                "name": "shape",
                "value": {
                    "current": {
                        "name": "object",
                        "required": false
                    }
                }
            },
            "required": false,
            "description": "@ignore"
        },
        "autoFocus": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, will focus the `[role=\"menu\"]` container and move into tab order"
        },
        "autoFocusItem": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, will focus the first menuitem if `variant=\"menu\"` or selected item\r\nif `variant=\"selectedMenu\"`"
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "MenuList contents, normally `MenuItem`s."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "disableListWrap": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the menu items will not wrap focus."
        },
        "onKeyDown": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'menu'",
                        "computed": false
                    },
                    {
                        "value": "'selectedMenu'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use. Use `menu` to prevent selected items from impacting the initial focus\r\nand the vertical alignment relative to the anchor element."
        }
    }
}