/* eslint-disable */
export default {
    "displayName": "GridListTileBar",
    "description": "",
    "methods": [],
    "props": {
        "actionIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "An IconButton element to be used as secondary action target\r\n(primary action target is the tile itself)."
        },
        "actionPosition": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'left'",
                        "computed": false
                    },
                    {
                        "value": "'right'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Position of secondary action IconButton."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "subtitle": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "String or element serving as subtitle (support text)."
        },
        "title": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Title to be displayed on tile."
        },
        "titlePosition": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'top'",
                        "computed": false
                    },
                    {
                        "value": "'bottom'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Position of the title bar."
        }
    }
}