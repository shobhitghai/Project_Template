/* eslint-disable */
export default {
    "displayName": "CardActions",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "disableSpacing": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the actions do not have additional margin."
        }
    }
}