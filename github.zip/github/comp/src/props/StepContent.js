/* eslint-disable */
export default {
    "displayName": "StepContent",
    "description": "",
    "methods": [],
    "props": {
        "active": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore\r\nExpands the content."
        },
        "alternativeLabel": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore\r\nSet internally by Step when it's supplied with the alternativeLabel prop."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Step content."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "completed": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "expanded": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "last": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "optional": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore\r\nSet internally by Step when it's supplied with the optional prop."
        },
        "orientation": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'horizontal'",
                        "computed": false
                    },
                    {
                        "value": "'vertical'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "@ignore"
        },
        "TransitionComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
        },
        "transitionDuration": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "shape",
                        "value": {
                            "enter": {
                                "name": "number",
                                "required": false
                            },
                            "exit": {
                                "name": "number",
                                "required": false
                            }
                        }
                    },
                    {
                        "name": "enum",
                        "value": [
                            {
                                "value": "'auto'",
                                "computed": false
                            }
                        ]
                    }
                ]
            },
            "required": false,
            "description": "Adjust the duration of the content expand transition.\r\nPassed as a prop to the transition component.\r\n\nSet to 'auto' to automatically calculate transition time based on height."
        },
        "TransitionProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
        }
    }
}