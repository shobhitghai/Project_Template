/* eslint-disable */
export default {
    "displayName": "FormControl",
    "description": "Provides context such as filled/focused/error/required for form inputs.\r\nRelying on the context provides high flexibility and ensures that the state always stays\r\nconsistent across the children of the `FormControl`.\r\nThis context is used by the following components:\r\n\n - FormLabel\r\n - FormHelperText\r\n - Input\r\n - InputLabel\r\n\nYou can find one composition example below and more going to [the demos](/components/text-fields/#components).\r\n\n```jsx\r\n<FormControl>\r\n  <InputLabel htmlFor=\"my-input\">Email address</InputLabel>\r\n  <Input id=\"my-input\" aria-describedby=\"my-helper-text\" />\r\n  <FormHelperText id=\"my-helper-text\">We'll never share your email.</FormHelperText>\r\n</FormControl>\r\n```\r\n\n⚠️Only one input can be used within a FormControl.",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The contents of the form control."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component."
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the label, input and helper text should be displayed in a disabled state."
        },
        "error": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the label should be displayed in an error state."
        },
        "fullWidth": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the component will take up the full width of its container."
        },
        "hiddenLabel": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the label will be hidden.\r\nThis is used to increase density for a `FilledInput`.\r\nBe sure to add `aria-label` to the `input` element."
        },
        "margin": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'none'",
                        "computed": false
                    },
                    {
                        "value": "'dense'",
                        "computed": false
                    },
                    {
                        "value": "'normal'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "If `dense` or `normal`, will adjust vertical spacing of this and contained components."
        },
        "required": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the label will indicate that the input is required."
        },
        "size": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'small'",
                        "computed": false
                    },
                    {
                        "value": "'medium'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The size of the text field."
        },
        "variant": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'standard'",
                        "computed": false
                    },
                    {
                        "value": "'outlined'",
                        "computed": false
                    },
                    {
                        "value": "'filled'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The variant to use."
        }
    }
}