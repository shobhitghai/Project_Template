/* eslint-disable */
export default {
    "displayName": "DialogTitle",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "The content of the component."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "disableTypography": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the children won't be wrapped by a typography component.\r\nFor instance, this can be useful to render an h4 instead of the default h2."
        }
    }
}