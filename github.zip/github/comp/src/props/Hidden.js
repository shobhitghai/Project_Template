/* eslint-disable */
export default {
    "displayName": "Hidden",
    "description": "Responsively hides children based on the selected implementation.",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The content of the component."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "implementation": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'js'",
                        "computed": false
                    },
                    {
                        "value": "'css'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Specify which implementation to use.  'js' is the default, 'css' works better for\r\nserver-side rendering."
        },
        "initialWidth": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'xs'",
                        "computed": false
                    },
                    {
                        "value": "'sm'",
                        "computed": false
                    },
                    {
                        "value": "'md'",
                        "computed": false
                    },
                    {
                        "value": "'lg'",
                        "computed": false
                    },
                    {
                        "value": "'xl'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "You can use this prop when choosing the `js` implementation with server-side rendering.\r\n\nAs `window.innerWidth` is unavailable on the server,\r\nwe default to rendering an empty component during the first mount.\r\nYou might want to use an heuristic to approximate\r\nthe screen width of the client browser screen width.\r\n\nFor instance, you could be using the user-agent or the client-hints.\r\nhttps://caniuse.com/#search=client%20hint"
        },
        "lgDown": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, screens this size and down will be hidden."
        },
        "lgUp": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, screens this size and up will be hidden."
        },
        "mdDown": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, screens this size and down will be hidden."
        },
        "mdUp": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, screens this size and up will be hidden."
        },
        "only": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "enum",
                        "value": [
                            {
                                "value": "'xs'",
                                "computed": false
                            },
                            {
                                "value": "'sm'",
                                "computed": false
                            },
                            {
                                "value": "'md'",
                                "computed": false
                            },
                            {
                                "value": "'lg'",
                                "computed": false
                            },
                            {
                                "value": "'xl'",
                                "computed": false
                            }
                        ]
                    },
                    {
                        "name": "arrayOf",
                        "value": {
                            "name": "enum",
                            "value": [
                                {
                                    "value": "'xs'",
                                    "computed": false
                                },
                                {
                                    "value": "'sm'",
                                    "computed": false
                                },
                                {
                                    "value": "'md'",
                                    "computed": false
                                },
                                {
                                    "value": "'lg'",
                                    "computed": false
                                },
                                {
                                    "value": "'xl'",
                                    "computed": false
                                }
                            ]
                        }
                    }
                ]
            },
            "required": false,
            "description": "Hide the given breakpoint(s)."
        },
        "smDown": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, screens this size and down will be hidden."
        },
        "smUp": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, screens this size and up will be hidden."
        },
        "xlDown": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, screens this size and down will be hidden."
        },
        "xlUp": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, screens this size and up will be hidden."
        },
        "xsDown": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, screens this size and down will be hidden."
        },
        "xsUp": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, screens this size and up will be hidden."
        }
    }
}