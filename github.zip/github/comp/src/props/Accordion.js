/* eslint-disable */
export default {
    "fileName": "accordion",
    "description": "",
    "methods": [
        {
            "name": "findExpandedPanel",
            "docblock": null,
            "modifiers": [],
            "params": [
                {
                    "name": "children",
                    "type": null
                }
            ],
            "returns": null
        },
        {
            "name": "onChange",
            "docblock": null,
            "modifiers": [],
            "params": [
                {
                    "name": "expanded",
                    "type": null
                }
            ],
            "returns": null
        }
    ],
    "props": {
        "children": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "element"
                    },
                    {
                        "name": "arrayOf",
                        "value": {
                            "name": "element"
                        }
                    }
                ]
            },
            "required": false,
            "description": "",
            "defaultValue": {
                "value": "[]",
                "computed": false
            }
        }
    }
}