/* eslint-disable */
export default {
    "displayName": "Fade",
    "description": "The Fade transition is used by the [Modal](/components/modal/) component.\r\nIt uses [react-transition-group](https://github.com/reactjs/react-transition-group) internally.",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "element"
            },
            "required": false,
            "description": "A single child content element."
        },
        "in": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the component will transition in."
        },
        "onEnter": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onExit": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "style": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "@ignore"
        },
        "timeout": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "shape",
                        "value": {
                            "enter": {
                                "name": "number",
                                "required": false
                            },
                            "exit": {
                                "name": "number",
                                "required": false
                            }
                        }
                    }
                ]
            },
            "required": false,
            "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
        }
    }
}