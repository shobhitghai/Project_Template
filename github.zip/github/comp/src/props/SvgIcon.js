/* eslint-disable */
export default {
    "displayName": "SvgIcon",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Node passed into the SVG element."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "color": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'action'",
                        "computed": false
                    },
                    {
                        "value": "'disabled'",
                        "computed": false
                    },
                    {
                        "value": "'error'",
                        "computed": false
                    },
                    {
                        "value": "'inherit'",
                        "computed": false
                    },
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'secondary'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The color of the component. It supports those theme colors that make sense for this component.\r\nYou can use the `htmlColor` prop to apply a color attribute to the SVG element."
        },
        "component": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
        },
        "fontSize": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'default'",
                        "computed": false
                    },
                    {
                        "value": "'inherit'",
                        "computed": false
                    },
                    {
                        "value": "'large'",
                        "computed": false
                    },
                    {
                        "value": "'small'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "The fontSize applied to the icon. Defaults to 24px, but can be configure to inherit font size."
        },
        "htmlColor": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Applies a color attribute to the SVG element."
        },
        "shapeRendering": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The shape-rendering attribute. The behavior of the different options is described on the\r\n[MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/shape-rendering).\r\nIf you are having issues with blurry icons you should investigate this property."
        },
        "titleAccess": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Provides a human-readable title for the element that contains it.\r\nhttps://www.w3.org/TR/SVG-access/#Equivalent"
        },
        "viewBox": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "Allows you to redefine what the coordinates without units mean inside an SVG element.\r\nFor example, if the SVG element is 500 (width) by 200 (height),\r\nand you pass viewBox=\"0 0 50 20\",\r\nthis means that the coordinates inside the SVG will go from the top left corner (0,0)\r\nto bottom right (50,20) and each unit will be worth 10px."
        }
    }
}