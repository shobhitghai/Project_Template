/* eslint-disable */
export default {
    "displayName": "Step",
    "description": "",
    "methods": [],
    "props": {
        "active": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Sets the step as active. Is passed to child components."
        },
        "alternativeLabel": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore\r\nSet internally by Stepper when it's supplied with the alternativeLabel property."
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "Should be `Step` sub-components such as `StepLabel`, `StepContent`."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "completed": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Mark the step as completed. Is passed to child components."
        },
        "connector": {
            "type": {
                "name": "element"
            },
            "required": false,
            "description": "@ignore\r\nPassed down from Stepper if alternativeLabel is also set."
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Mark the step as disabled, will also disable the button if\r\n`StepButton` is a child of `Step`. Is passed to child components."
        },
        "expanded": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Expand the step."
        },
        "index": {
            "type": {
                "name": "number"
            },
            "required": false,
            "description": "@ignore\r\nUsed internally for numbering."
        },
        "last": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "orientation": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'horizontal'",
                        "computed": false
                    },
                    {
                        "value": "'vertical'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "@ignore"
        }
    }
}