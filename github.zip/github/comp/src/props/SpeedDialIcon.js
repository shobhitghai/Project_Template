/* eslint-disable */
export default {
    "displayName": "SpeedDialIcon",
    "description": "",
    "methods": [],
    "props": {
        "classes": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "icon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon to display in the SpeedDial Floating Action Button."
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore\r\nIf `true`, the SpeedDial is open."
        },
        "openIcon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon to display in the SpeedDial Floating Action Button when the SpeedDial is open."
        }
    }
}