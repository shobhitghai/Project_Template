/* eslint-disable */
export default {
    "displayName": "Tab",
    "description": "",
    "methods": [],
    "props": {
        "children": {
            "type": {
                "name": "custom",
                "raw": "unsupportedProp"
            },
            "required": false,
            "description": "This prop isn't supported.\r\nUse the `component` prop if you need to change the children structure."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "disabled": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the tab will be disabled."
        },
        "disableFocusRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the  keyboard focus ripple will be disabled.\r\n`disableRipple` must also be true."
        },
        "disableRipple": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the ripple effect will be disabled."
        },
        "fullWidth": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "icon": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The icon element."
        },
        "indicator": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "@ignore\r\nFor server-side rendering consideration, we let the selected tab\r\nrender the indicator."
        },
        "label": {
            "type": {
                "name": "node"
            },
            "required": false,
            "description": "The label element."
        },
        "onChange": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "onClick": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "@ignore"
        },
        "selected": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "@ignore"
        },
        "textColor": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'secondary'",
                        "computed": false
                    },
                    {
                        "value": "'primary'",
                        "computed": false
                    },
                    {
                        "value": "'inherit'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "@ignore"
        },
        "value": {
            "type": {
                "name": "any"
            },
            "required": false,
            "description": "You can provide your own value. Otherwise, we fallback to the child position index."
        },
        "wrapped": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "Tab labels appear in a single row.\r\nThey can use a second line if needed."
        }
    }
}