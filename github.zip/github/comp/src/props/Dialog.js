/* eslint-disable */
export default {
    "displayName": "Dialog",
    "description": "Dialogs are overlaid modal paper based components with a backdrop.",
    "methods": [],
    "props": {
        "aria-describedby": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The id(s) of the element(s) that describe the dialog."
        },
        "aria-labelledby": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "The id(s) of the element(s) that label the dialog."
        },
        "BackdropProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "@ignore"
        },
        "children": {
            "type": {
                "name": "node"
            },
            "required": true,
            "description": "Dialog children, usually the included sub-components."
        },
        "classes": {
            "type": {
                "name": "object"
            },
            "required": true,
            "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
        },
        "className": {
            "type": {
                "name": "string"
            },
            "required": false,
            "description": "@ignore"
        },
        "disableBackdropClick": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, clicking the backdrop will not fire the `onClose` callback."
        },
        "disableEscapeKeyDown": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, hitting escape will not fire the `onClose` callback."
        },
        "fullScreen": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the dialog will be full-screen"
        },
        "fullWidth": {
            "type": {
                "name": "bool"
            },
            "required": false,
            "description": "If `true`, the dialog stretches to `maxWidth`.\r\n\nNotice that the dialog width grow is limited by the default margin."
        },
        "maxWidth": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'xs'",
                        "computed": false
                    },
                    {
                        "value": "'sm'",
                        "computed": false
                    },
                    {
                        "value": "'md'",
                        "computed": false
                    },
                    {
                        "value": "'lg'",
                        "computed": false
                    },
                    {
                        "value": "'xl'",
                        "computed": false
                    },
                    {
                        "value": "false",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Determine the max-width of the dialog.\r\nThe dialog width grows with the size of the screen.\r\nSet to `false` to disable `maxWidth`."
        },
        "onBackdropClick": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the backdrop is clicked."
        },
        "onClose": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"escapeKeyDown\"`, `\"backdropClick\"`."
        },
        "onEnter": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired before the dialog enters."
        },
        "onEntered": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the dialog has entered."
        },
        "onEntering": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the dialog is entering."
        },
        "onEscapeKeyDown": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the escape key is pressed,\r\n`disableKeyboard` is false and the modal is in focus."
        },
        "onExit": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired before the dialog exits."
        },
        "onExited": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the dialog has exited."
        },
        "onExiting": {
            "type": {
                "name": "func"
            },
            "required": false,
            "description": "Callback fired when the dialog is exiting."
        },
        "open": {
            "type": {
                "name": "bool"
            },
            "required": true,
            "description": "If `true`, the Dialog is open."
        },
        "PaperComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used to render the body of the dialog."
        },
        "PaperProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Paper`](/api/paper/) element."
        },
        "scroll": {
            "type": {
                "name": "enum",
                "value": [
                    {
                        "value": "'body'",
                        "computed": false
                    },
                    {
                        "value": "'paper'",
                        "computed": false
                    }
                ]
            },
            "required": false,
            "description": "Determine the container for scrolling the dialog."
        },
        "TransitionComponent": {
            "type": {
                "name": "elementType"
            },
            "required": false,
            "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
        },
        "transitionDuration": {
            "type": {
                "name": "union",
                "value": [
                    {
                        "name": "number"
                    },
                    {
                        "name": "shape",
                        "value": {
                            "enter": {
                                "name": "number",
                                "required": false
                            },
                            "exit": {
                                "name": "number",
                                "required": false
                            }
                        }
                    }
                ]
            },
            "required": false,
            "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
        },
        "TransitionProps": {
            "type": {
                "name": "object"
            },
            "required": false,
            "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
        }
    }
}