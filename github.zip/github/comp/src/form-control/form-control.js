import { FormControl } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'


const AUFormControl = class extends React.Component {

    static displayName = 'AUFormControl'

    render() {

        const { props } = this

        return (
            <FormControl {...{
                ...props,
                className: classnames('au-form-control', props.className)
            }} />
        )
    }
}

export default AUFormControl
