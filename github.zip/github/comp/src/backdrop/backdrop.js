import { Backdrop } from '@material-ui/core'
import classnames from 'classnames'
import React from 'react'


const AUBackdrop = class extends React.Component {

    static displayName = 'AUBackdrop'

    static propTypes = Backdrop.propTypes

    render() {

        const { props } = this

        return (
            <Backdrop {...{
                ...props,
                className: classnames('au-backdrop', props.className)
            }} />
        )
    }
}

export default AUBackdrop
