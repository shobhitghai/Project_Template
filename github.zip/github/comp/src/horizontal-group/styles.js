/* eslint-disable */

export default theme => {

    return {
        root: {
            display: 'flex',
            alignItems: 'center'
        }
    }
}
