/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { gutter } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Button from '../button'
import HorizontalGroup from './horizontal-group'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Horizontal Group'
}

export const Basic = () => (
    <HorizontalGroup gutter={gutter()}>
        <Button color="primary">
            Decrease all
        </Button>
        <Button color="primary">
            Decrease
        </Button>
        <Button color="primary">
            Increase
        </Button>
        <Button color="primary">
            Increase all
        </Button>
    </HorizontalGroup>
)
