import classnames from 'classnames'
import flatten from 'lodash/fp/flatten'
import initial from 'lodash/fp/initial'
import isEqual from 'lodash/fp/isEqual'
import isFinite from 'lodash/fp/isFinite'
import map from 'lodash/fp/map'
import PropTypes from 'prop-types'
import React from 'react'
import { withStyles, withTheme } from '../styles'
import styles from './styles'


const AUHorizontalGroup = withTheme(withStyles(styles)(class extends React.Component {

    static displayName = 'AUHorizontalGroup'

    static propTypes = {
        /**
         * The contents of the HorizontalGroup.
         */
        children: PropTypes.oneOfType([
            PropTypes.arrayOf(PropTypes.node),
            PropTypes.node
        ]).isRequired,
        classes: PropTypes.shape({
            root: PropTypes.string.isRequired
        }),
        /**
         * The space between each child.
         */
        gutter: PropTypes.number
    }

    shouldComponentUpdate(nextProps) {

        return !isEqual(nextProps, this.props)
    }

    render() {

        const { props } = this
        const { children, classes, className, gutter, theme, ...rest } = props

        const style = { width: isFinite(gutter) ? gutter : theme.spacing(1) }

        return (
            <div { ...rest } className={classnames('au-horizontal-group', className, classes.root)}>
                {initial(flatten(map(
                    child => [ child, <div key={`spacer-${child.key}`} style={style} /> ],
                    React.Children.toArray(children)
                )))}
            </div>
        )
    }
}))

export default AUHorizontalGroup
