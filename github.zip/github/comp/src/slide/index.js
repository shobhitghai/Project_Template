export { default } from './slide'
