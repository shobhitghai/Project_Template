import { Slide } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'


const AUSlide = class extends React.Component {

    static displayName = 'AUSlide'

    static propTypes = Slide.propTypes

    render() {

        const { props } = this

        return (
            <Slide {...{
                ...props,
                className: classnames('au-slide', props.className)
            }} />
        )
    }
}

export default AUSlide
