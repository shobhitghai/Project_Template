/* eslint-disable */
export const nativeSelectStyles = theme => {
    return {
        
    }
}
