/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import fp from 'lodash/fp'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import list from '../../stories/fixtures/list'
import rootWrapper from '../../stories/root-wrapper'
import FormControl from '../form-control'
import NativeSelect from './native-select'


class NativeSelectExample extends React.Component {
    state = {
        option: ''
    }

    onChange = event => {
        this.setState({ option: event.target.value })
    }

    render() {
        return (
            <NativeSelect {...{
                children: options(),
                onChange: this.onChange,
                value: this.state.option
            }} />
        )
    }
}

const options = () => {
    return fp.map(option => {
        return (
            <option {...{
                key: option,
                value: option
            }}>
                {option}
            </option>
        )
    }, list(5))
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Native Select'
}

export const Basic = () =>(
    <FormControl {...{
        fullWidth: true
    }}>
        <NativeSelectExample />
    </FormControl>
)
