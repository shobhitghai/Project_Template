import { NativeSelect } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import Input from '../input'
import { withTelemetry } from '../telemetry'
import { nativeSelectStyles } from './styles'


const AUNativeSelect = withTelemetry(withStyles(nativeSelectStyles)(class extends React.Component {

    static displayName = 'AUNativeSelect'

    static defaultProps = {
        input: <Input />
    }

    static propTypes = NativeSelect.propTypes

    render() {
        const { props } = this

        return (
            <NativeSelect {... {
                ...props,
                className: classnames('au-native-select', props.className)
            }}/>
        )
    }
}))

export default AUNativeSelect
