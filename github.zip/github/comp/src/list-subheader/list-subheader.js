import { ListSubheader } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { listSubheaderStyles } from './styles'


const AUListSubheader = withTelemetry(withStyles(listSubheaderStyles)(class extends React.Component {

    static displayName = 'AUListSubheader'

    static propTypes = ListSubheader.propTypes

    render() {

        const { props } = this

        return (
            <ListSubheader {... {
                ...props,
                className: classnames('au-list-subheader', props.className)
            }} />
        )
    }
}))

export default AUListSubheader
