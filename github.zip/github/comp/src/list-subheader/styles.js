/* eslint-disable */
export const listSubheaderStyles = theme => {
    return {
        root: {
            fontSize: theme.typography.body2.fontSize,
            fontWeight: 400,
            lineHeight: `${theme.spacing(2)}px`,
            minHeight: theme.spacing(4),
            padding: `${theme.spacing(1)}px ${theme.spacing(2)}px`
        },

        inset: {
            paddingLeft: theme.spacing(7)
        }
    }
}
