import { Toolbar } from '@material-ui/core'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { toolbarStyles } from './styles'


const AUToolbar = withTelemetry(withStyles(toolbarStyles)(class extends React.Component {

    static displayName = 'AUToolbar'

    static propTypes = Toolbar.propTypes

    render() {

        const { props } = this

        return (
            <Toolbar {...{
                ...props,
                className: classnames('au-toolbar', props.className)
            }} />
        )
    }
}))

export default AUToolbar
