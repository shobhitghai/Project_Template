/* eslint-disable */
export const toolbarStyles = theme => {
    return {
        root: {
            height: theme.spacing(7)
        },
        gutters: {
            paddingLeft: theme.spacing(2),
            paddingRight: theme.spacing(2)
        }
    }
}
