import Tabs from '@material-ui/core/Tabs'
import { makeStyles } from '@material-ui/core/styles'
import classnames from 'classnames'
import merge from 'lodash/fp/merge'
import React from 'react'
import { withTelemetry } from '../telemetry'
import { tabsStyles } from './styles'


const useStyles = makeStyles(tabsStyles)

const AUTabs = withTelemetry(React.forwardRef(({ classes, ...other }, ref) => {

    const defaultStyles = useStyles()

    return (
        <Tabs {...{
            ...other,
            classes: merge(defaultStyles, classes),
            className: classnames('au-tabs', other.className),
            ref
        }} />
    )

}))

AUTabs.defaultProps = {
    indicatorColor: 'primary',
    textColor: 'primary',
    value: 0
}
AUTabs.displayName = 'AUTabs'
AUTabs.propTypes = Tabs.propTypes

export default AUTabs
