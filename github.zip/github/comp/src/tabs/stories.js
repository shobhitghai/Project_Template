/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import fp from 'lodash/fp'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { centered, scrollable, scrollButtons, variantTabs } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import tabs from '../../stories/fixtures/tabs'
import Tab from '../tab'
import Tabs from './tabs'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Tabs'
}

const map3 = fp.map.convert({ 'cap': false })

class SimpleTabs extends React.Component {
    state = {
        value: this.props.value
    }

    onChange = (event, value) => {
        this.setState({ value })
    }

    render() {

        const { onChange, props, state } = this

        return (
            <Tabs {...{
                centered: centered(),
                onChange,
                variant: variantTabs(),
                scrollButtons: scrollButtons(),
                value: state.value,
                ...props
            }}/>
        )
    }
}

export const Basic = () => (
    <SimpleTabs>
        {map3((tab, index) => {
            return (
                <Tab {...{
                    disabled: tab.disabled,
                    key: index,
                    label: tab.title,
                    value: index
                }} />
            )
        })(tabs(5))}
    </SimpleTabs>
)

export const Overflow = () => (
    <SimpleTabs {...{
        variant: 'scrollable'
    }}>
        {map3((tab, index) => {
            return (
                <Tab {...{
                    disabled: tab.disabled,
                    key: index,
                    label: tab.title,
                    value: index
                }} />
            )
        })(tabs(15))}
    </SimpleTabs>
)
