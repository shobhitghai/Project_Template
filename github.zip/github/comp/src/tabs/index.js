export { default } from './tabs'
