/* eslint-disable */
export const tabsStyles = theme => {
    return {
        root: {
            height: theme.spacing(4),
            minHeight: theme.spacing(4)
        },

        '@media (max-width: 600px)': {
            scrollButtonsDesktop: {
                display: 'inherit'
            }
        }
    }
}
