/* eslint-disable */
export const cardStyles = theme => {
    return {
        root: {
            borderRadius: 0
        }
    }
}
