import { Card } from '@material-ui/core'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { cardStyles } from './styles'


const AUCard = withTelemetry(withStyles(cardStyles)(class extends React.Component {

    static displayName = 'AUCard'

    static propTypes = Card.propTypes

    render() {

        const { props } = this

        return (
            <Card {...{
                ...props,
                className: classnames('au-card', props.className)
            }} />
        )
    }
}))

export default AUCard
