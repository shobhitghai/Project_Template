/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import jss from 'jss'
import preset from 'jss-preset-default'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { raised } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Button from '../button'
import CardActions from '../card-actions'
import CardContent from '../card-content'
import Typography from '../typography'
import Card from './card'


jss.setup(preset())

const styles = {
    card: {
        margin: '32px',
        maxWidth: 400
    },
    media: {
        height: 0,
        paddingTop: '56.25%' // 16:9
    }
}

const {classes} = jss.createStyleSheet(styles).attach()

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Card'
}

export const Basic = () => (
    <Card {...{
        className: classes.card,
        raised: raised()
    }}>
        <CardContent>
            <Typography {...{
                gutterBottom: true,
                variant: 'h1'
            }}>
                Aura Card
            </Typography>

            <Typography>
                Lorem ipsum dolor sit amet, vim postulant consulatu persecuti te. Elitr virtute iuvaret cu has. Sea falli vocent te, cum posse impetus graecis no. Sit in dicit eleifend honestatis. Ex ancillae indoctum duo.
            </Typography>

        </CardContent>
        <CardActions>
            <Button {...{
                variant: 'outlined'
            }}>Button inside card actions</Button>
        </CardActions>
    </Card>
)
