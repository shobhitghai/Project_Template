
/* eslint-disable */
export const inputStyles = theme => {

    const DEFAULT_PADDING_HEIGHT = `${theme.spacing(4) - 13}px`

    return {
        root: {
            ...theme.typography.body2,

            '&$disabled:after': {
                display: 'none'
            },

            '& + .au-form-helper-text': {
                maxWidth: '100%',
                overflow: 'hidden',
                position: 'relative',
                textOverflow: 'ellipsis',
                top: theme.spacing(1) + 2,
                whiteSpace: 'nowrap'
            }
        },

        multiline: {
            '& > div:first-of-type': {
                // NOTE 13px is the default padding height of the input
                minHeight: DEFAULT_PADDING_HEIGHT
            }
        },

        input: {
            // NOTE 13px is the default padding height of the input
            lineHeight: DEFAULT_PADDING_HEIGHT,
            minHeight: DEFAULT_PADDING_HEIGHT,

        },

        disabled: {
            
        },
    }
}
