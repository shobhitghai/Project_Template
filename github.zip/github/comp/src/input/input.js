import { Input } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { inputStyles } from './styles'


const AUInput = withStyles(inputStyles)(class extends React.Component {

    static displayName = 'AUInput'

    static propTypes = Input.propTypes

    render() {

        const { props } = this

        return (
            <Input {...{
                ...props,
                className: classnames('au-input', props.className, {
                    'au-input-disabled': props.disabled
                })
            }} />
        )
    }
})

export default AUInput
