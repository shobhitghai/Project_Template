import StepIcon from '@material-ui/core/StepIcon'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { stepIconStyles } from './styles'


const AUStepIcon = withStyles(stepIconStyles)(class extends React.Component {

    static displayName = 'AUStepIcon'

    static propTypes = StepIcon.npm

    render() {
        const { props } = this

        return (
            <StepIcon {...{
                ...props,
                className: classnames('au-step-icon', props.className)
            }} />
        )
    }
})

export default AUStepIcon
