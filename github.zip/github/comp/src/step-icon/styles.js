export const stepIconStyles = theme => {
    return {
        label: {
            lineHeight: `${theme.spacing(2)}px`
        }
    }
}
