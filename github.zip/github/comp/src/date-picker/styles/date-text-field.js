/* eslint-disable */
export const dateTextFieldStyles = theme => {

    return {
        input: {
            alignItems: 'end',
            fontSize: theme.typography.body2.fontSize
        }
    }
}
