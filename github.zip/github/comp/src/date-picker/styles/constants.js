export const constants = {
    DIALOG: theme => (
        {
            HEIGHT: theme.spacing(1) * 30 + 60,
            WIDTH: theme.spacing(1) * 20 + 50
        }
    ),
    TOOLBAR_HEIGHT: 64
}


