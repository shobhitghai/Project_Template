/* eslint-disable */
export const dayStyles = theme => {
    return {
        current: {
            fontWeight: 600
        },
        day: {
            borderRadius: 0,
            fontSize: theme.typography.caption.fontSize,
            margin: theme.spacing(0.25)
        },
        disabled: {
            pointerEvents: 'none'
        },
        hidden: {
            opacity: 0,
            pointerEvents: 'none'
        },
        selected: {
            fontWeight: theme.typography.fontWeightMedium
        }
    }
}
