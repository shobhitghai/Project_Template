/* eslint-disable */
import { constants } from './constants'


export const yearSelectionStyles = theme => {

    return {
        container: {
            justifyContent: 'center',
            maxHeight: constants.MODAL_HEIGHT - constants.TOOLBAR_HEIGHT,
            overflowY: 'auto'
        }
    }
}
