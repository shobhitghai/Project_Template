/* eslint-disable */
import { constants } from './constants'


export const modalDialogStyles = theme => {

    return {
        cancelButton: {
            marginLeft: 'auto'
        },
        dialog: {
            '&:first-child': {
                padding: 0
            },

            height: constants.DIALOG(theme).HEIGHT,
            overflow: 'hidden',
            width: constants.DIALOG(theme).WIDTH,
        },
        dialogRoot: {
            minWidth: constants.DIALOG(theme).WIDTH,
        }
    }
}
