/* eslint-disable */
export const calendarStyles = theme => {
    return {
        week: {
            display: 'flex',
            justifyContent: 'center'
        }
    }
}
