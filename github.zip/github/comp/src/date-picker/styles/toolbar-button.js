/* eslint-disable */
export const toolbarButtonStyles = theme => {

    return {
        toolbarBtn: {
            color: theme.palette.text.secondary,
            cursor: 'pointer'
        }
    }
}
