/* eslint-disable */
import { constants } from './constants'


export const pickerToolbarStyles = theme => {

    return {
        toolbar: {
            alignItems: 'flex-start',
            display: 'flex',
            flexDirection: 'column',
            height: constants.TOOLBAR_HEIGHT,
            justifyContent: 'center',
            padding: theme.spacing(1)
        }
    }
}
