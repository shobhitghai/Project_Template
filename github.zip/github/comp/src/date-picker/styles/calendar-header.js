/* eslint-disable */
export const calendarHeaderStyles = theme => {

    return {
        dayLabel: {
            margin: `${theme.spacing(0.25)}px`,
            textAlign: 'center',
            width: theme.spacing(3)
        },
        daysHeader: {
            alignItems: 'center',
            display: 'flex',
            justifyContent: 'center',
            maxHeight: theme.spacing(2)
        },
        iconButton: {
            '& svg': {
                fontSize: theme.typography.body2.fontSize
            }
        },
        root: {
            padding: `${theme.spacing(1)}px 0`
        },
        switchHeader: {
            alignItems: 'center',
            display: 'flex',
            justifyContent: 'space-between',
            marginBottom: theme.spacing(1)
        }
    }
}
