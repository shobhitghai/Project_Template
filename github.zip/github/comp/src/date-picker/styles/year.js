/* eslint-disable */
export const yearStyles = theme => {

    return {
        disabled: {
            color: theme.palette.text.hint,
            pointerEvents: 'none'
        },
        root: {
            '&:focus': {
                color: theme.palette.primary.main,
                fontWeight: theme.typography.fontWeightMedium
            },

            alignItems: 'center',
            cursor: 'pointer',
            display: 'flex',
            fontSize: theme.typography.body2.fontSize,
            height: theme.spacing(3),
            justifyContent: 'center',
            outline: 'none'
        },
        selected: {
            fontSize: theme.typography.h2.fontSize,
            fontWeight: theme.typography.fontWeightMedium,
            margin: `${theme.spacing(1)}px 0`
        }
    }
}
