/* eslint-disable */
import { boolean, select, text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import rootWrapper from '../../stories/root-wrapper'
import DatePicker from './index'


class BasicDatePicker extends React.Component {
    state = {
        selectedDate: new Date()
    }

    onDateChange = date => {
        this.setState({ selectedDate: date })
    }

    render() {
        const { selectedDate } = this.state

        return (
            <DatePicker {...{
                adornmentPosition: select('Adornment Position', {
                    end: 'End',
                    start: 'Start'
                }, 'end'),
                clearable: boolean('Clearable', false),
                disableFuture: boolean('Disable Future', false),
                disableOpenOnEnter: boolean('Disable Open On Enter', false),
                disablePast: boolean('Disable Past', false),
                format: 'MMMM dd yyyy',
                invalidDateMessage: text('Invalid Date Message', 'Invalid Date Format'),
                invalidLabel: text('Invalid Label', 'Invalid Label Example'),
                keyboard: boolean('Keyboard', true),
                label: 'Example date picker',
                onChange: this.onDateChange,
                openToYearSelection: boolean('Open to Year Selection', false),
                value: selectedDate
            }} />
        )
    }
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Date Picker'
}

export const Basic = () => <BasicDatePicker />
