import PropTypes from 'prop-types'
import React, { PureComponent } from 'react'


const DayWrapper = class extends PureComponent {

    static displayName = 'DayWrapper'

    static propTypes = {
        children: PropTypes.node.isRequired,
        dayInCurrentMonth: PropTypes.bool,
        disabled: PropTypes.bool,
        onSelect: PropTypes.func.isRequired,
        value: PropTypes.any.isRequired
    }

    static defaultProps = {
        dayInCurrentMonth: true,
        disabled: false
    }

    handleClick = () => {
        this.props.onSelect(this.props.value)
    }

    render() {
        const {
            children, value, dayInCurrentMonth, disabled, onSelect, ...other
        } = this.props

        return (
            <div {...{
                className: 'au-date-picker-day-wrapper',
                onClick: dayInCurrentMonth && !disabled ? this.handleClick : undefined,
                onKeyPress: dayInCurrentMonth && !disabled ? this.handleClick : undefined,
                role: 'presentation',
                ...other
            }}>
                {children}
            </div>
        )
    }
}

export default DayWrapper
