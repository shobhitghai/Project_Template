import classnames from 'classnames'
import PropTypes from 'prop-types'
import fp from 'lodash/fp'
import React from 'react'
import { withStyles } from '../../styles/'
import IconButton from '../../icon-button'
import Typography from '../../typography'
import { calendarHeaderStyles } from '../styles/calendar-header'
import withUtils from '../with-utils'


export class AUCalendarHeader extends React.Component {

    static propTypes = {
        classes: PropTypes.object.isRequired,
        currentMonth: PropTypes.object.isRequired,
        disableNextMonth: PropTypes.bool,
        disablePrevMonth: PropTypes.bool,
        leftArrowIcon: PropTypes.node,
        onMonthChange: PropTypes.func.isRequired,
        rightArrowIcon: PropTypes.node,
        theme: PropTypes.object.isRequired,
        utils: PropTypes.object.isRequired
    }

    static defaultProps = {
        disableNextMonth: false,
        disablePrevMonth: false,
        leftArrowIcon: 'keyboard_arrow_left',
        rightArrowIcon: 'keyboard_arrow_right'
    }

    render() {
        const {
            classes,
            theme,
            currentMonth,
            onMonthChange,
            leftArrowIcon,
            rightArrowIcon,
            disablePrevMonth,
            disableNextMonth,
            utils
        } = this.props

        const rtl = theme.direction === 'rtl'

        const selectNextMonth = () => onMonthChange(utils.getNextMonth(currentMonth))
        const selectPreviousMonth = () => onMonthChange(utils.getPreviousMonth(currentMonth))

        return (
            <div {...{
                className: classnames('au-date-picker-calendar-header', classes.root)
            }}>
                <div {...{
                    className: classes.switchHeader
                }}>
                    <IconButton {...{
                        className: classes.iconButton,
                        disabled: disablePrevMonth,
                        onClick: selectPreviousMonth
                    }}>
                        {rtl ? rightArrowIcon : leftArrowIcon}
                    </IconButton>

                    <Typography {...{
                        variant: 'body2'
                    }}>
                        {utils.getCalendarHeaderText(currentMonth)}
                    </Typography>

                    <IconButton {...{
                        className: classes.iconButton,
                        disabled: disableNextMonth,
                        onClick: selectNextMonth
                    }}>
                        {rtl ? leftArrowIcon : rightArrowIcon}
                    </IconButton>
                </div>

                <div {...{
                    className: classes.daysHeader
                }}>
                    {fp.map(day => (
                        <Typography
                            className={classes.dayLabel}
                            key={day}
                            variant="caption"
                        >
                            {day}
                        </Typography>
                    ), utils.getWeekdays())}
                </div>
            </div>
        )
    }
}

export default withStyles(
    calendarHeaderStyles,
    { name: 'MuiPickersCalendarHeader', withTheme: true }
)(withUtils()(AUCalendarHeader))
