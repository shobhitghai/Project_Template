import compose from 'recompose/compose'
import lifecycle from 'recompose/lifecycle'
import setDisplayName from 'recompose/setDisplayName'
import withHandlers from 'recompose/withHandlers'
import toRenderProps from 'recompose/toRenderProps'
import withState from 'recompose/withState'
import withUtils from '../with-utils'


const getInitialDate = ({ utils, value, initialFocusedDate }) => {
    const initialDate = value || initialFocusedDate || utils.date()
    const date = utils.date(initialDate)

    return utils.isValid(date) ? date : utils.date()
}

export const AUBasePickerHoc = compose(
    withUtils(),
    setDisplayName('BasePicker'),
    withState('date', 'changeDate', getInitialDate),
    withState('isAccepted', 'handleAcceptedChange', false),
    lifecycle({
        componentDidUpdate(prevProps) {
            if (prevProps.value !== this.props.value) {
                this.props.changeDate(getInitialDate(this.props))
            }
        }
    }),
    withHandlers({
        handleAccept: ({ onChange, date }) => () => onChange(date),
        handleChange: ({
            autoOk,
            changeDate,
            onChange,
            handleAcceptedChange
        }) => (newDate, isFinish = true) => {
            changeDate(newDate, () => {
                if (isFinish && autoOk) {
                    onChange(newDate)
                    handleAcceptedChange(true, () => handleAcceptedChange(false))
                }
            })
        },
        handleClear: ({ onChange }) => () => onChange(null),
        handleSetTodayDate: ({ changeDate, utils }) => () => changeDate(utils.date()),
        handleTextFieldChange: ({ changeDate, onChange }) => date => {
            if (date === null) {
                this.handleClear()
            } else {
                changeDate(date, () => onChange(date))
            }
        },
        pick12hOr24hFormat: ({ format, labelFunc, ampm }) => (default12hFormat, default24hFormat) => {
            if (format || labelFunc) {
                return format
            }

            return ampm ? default12hFormat : default24hFormat
        }
    })
)

export default toRenderProps(AUBasePickerHoc)
