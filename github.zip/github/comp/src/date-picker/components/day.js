import classnames from 'classnames'
import PropTypes from 'prop-types'
import React, { PureComponent } from 'react'
import values from 'lodash/fp/values'
import { withStyles } from '../../styles/'
import IconButton from '../../icon-button'
import { dayStyles } from '../styles/day'


class AUDay extends PureComponent {
    static propTypes = {
        children: PropTypes.node.isRequired,
        classes: PropTypes.object.isRequired,
        current: PropTypes.bool,
        disabled: PropTypes.bool,
        hidden: PropTypes.bool,
        selected: PropTypes.bool
    }

    static defaultProps = {
        current: false,
        disabled: false,
        hidden: false,
        selected: false
    }

    getRestClasses = classes => {
        const { current, day, disabled, hidden, selected, ...other } = classes
        return other
    }

    render() {
        const {
            children, classes, disabled, hidden, current, selected, ...other
        } = this.props

        const restClasses = this.getRestClasses(classes)

        const className = classnames('au-date-picker-day', classes.day, {
            [classes.hidden]: hidden,
            [classes.current]: current,
            [classes.selected]: selected,
            [classes.disabled]: disabled
        }, values(restClasses))

        return (
            <IconButton {...{
                className,
                tabIndex: hidden || disabled ? -1 : 0,
                ...other
            }}
            >
                <span> {children} </span>
            </IconButton>
        )
    }
}

export default withStyles(dayStyles)(AUDay)
