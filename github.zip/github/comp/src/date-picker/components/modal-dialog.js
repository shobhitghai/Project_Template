import classnames from 'classnames'
import PropTypes from 'prop-types'
import React from 'react'
import EventListener from 'react-event-listener'
import { withStyles } from '../../styles/'
import Dialog from '../../dialog'
import DialogContent from '../../dialog-content'
import { modalDialogStyles } from '../styles/modal-dialog'


export class AUModalDialog extends React.Component {

    static propTypes = {
        cancelLabel: PropTypes.node.isRequired,
        children: PropTypes.node.isRequired,
        classes: PropTypes.object.isRequired,
        clearable: PropTypes.bool.isRequired,
        clearLabel: PropTypes.node.isRequired,
        dialogContentClassName: PropTypes.string,
        okLabel: PropTypes.node.isRequired,
        onAccept: PropTypes.func.isRequired,
        onClear: PropTypes.func.isRequired,
        onDismiss: PropTypes.func.isRequired,
        onKeyDown: PropTypes.func.isRequired,
        onSetToday: PropTypes.func.isRequired,
        showTodayButton: PropTypes.bool.isRequired,
        todayLabel: PropTypes.node.isRequired
    }

    static defaultProps = {
        dialogContentClassName: ''
    }

    render() {
        const {
            children,
            classes,
            onKeyDown,
            onAccept,
            onDismiss,
            onClear,
            onSetToday,
            okLabel,
            cancelLabel,
            clearLabel,
            todayLabel,
            dialogContentClassName,
            clearable,
            showTodayButton,
            ...other
        } = this.props

        return (
            <Dialog {...{
                classes: {
                    root: classes.dialogRoot
                },
                onClose: onDismiss,
                ...other
            }}>
                <EventListener {...{
                    onKeyDown,
                    target: 'window'
                }}/>
                <DialogContent {...{
                    className: classnames('au-date-picker-modal-dialog', classes.dialog, dialogContentClassName)
                }}>
                    { children }
                </DialogContent>
            </Dialog>
        )
    }
}

export default withStyles(modalDialogStyles, { name: 'MuiPickersModal' })(AUModalDialog)
