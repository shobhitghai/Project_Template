import classnames from 'classnames'
import keycode from 'keycode'
import PropTypes from 'prop-types'
import React, { Component, Fragment } from 'react'
import EventListener from 'react-event-listener'
import { withStyles } from '../../styles/'
import { findClosestEnabledDate } from '../helpers/date-utils'
import DomainPropTypes from '../constants/prop-types'
import { calendarStyles } from '../styles/calendar'
import withUtils from '../with-utils'
import CalendarHeader from './calendar-header'
import Day from './day'
import DayWrapper from './day-wrapper'


export class AUCalendar extends Component {

    static propTypes = {
        allowKeyboardControl: PropTypes.bool,
        classes: PropTypes.object.isRequired,
        date: PropTypes.object.isRequired,
        disableFuture: PropTypes.bool,
        disablePast: PropTypes.bool,
        leftArrowIcon: PropTypes.node,
        maxDate: DomainPropTypes.date,
        minDate: DomainPropTypes.date,
        onChange: PropTypes.func.isRequired,
        renderDay: PropTypes.func,
        rightArrowIcon: PropTypes.node,
        shouldDisableDate: PropTypes.func,
        theme: PropTypes.object.isRequired,
        utils: PropTypes.object.isRequired
    }

    static defaultProps = {
        allowKeyboardControl: false,
        disableFuture: false,
        disablePast: false,
        leftArrowIcon: undefined,
        maxDate: '2100-01-01',
        minDate: '1900-01-01',
        renderDay: undefined,
        rightArrowIcon: undefined,
        shouldDisableDate: () => false
    }

    state = {
        currentMonth: this.props.utils.getStartOfMonth(this.props.date)
    }

    static getDerivedStateFromProps(nextProps, state) {
        if (!nextProps.utils.isEqual(nextProps.date, state.lastDate)) {
            return {
                currentMonth: nextProps.utils.getStartOfMonth(nextProps.date),
                lastDate: nextProps.date
            }
        }

        return null
    }

    componentDidMount() {
        const {
            date, minDate, maxDate, utils, disableFuture, disablePast
        } = this.props

        if (this.shouldDisableDate(date)) {
            this.onDateSelect(findClosestEnabledDate({
                date,
                disableFuture,
                disablePast,
                maxDate,
                minDate,
                shouldDisableDate: this.shouldDisableDate,
                utils
            }), false)
        }
    }

    handleChangeMonth = newMonth => {
        this.setState({ currentMonth: newMonth })
    }

    validateMinMaxDate = day => {
        const { minDate, maxDate, utils } = this.props

        return (
            (minDate && utils.isBeforeDay(day, utils.date(minDate)))
            || (maxDate && utils.isAfterDay(day, utils.date(maxDate)))
        )
    }

    shouldDisablePrevMonth = () => {
        const { utils, disablePast, minDate } = this.props
        const now = utils.date()
        return !utils.isBefore(
            utils.getStartOfMonth(disablePast && utils.isAfter(now, minDate)
                ? now
                : utils.date(minDate)),
            this.state.currentMonth
        )
    }

    shouldDisableNextMonth = () => {
        const { utils, disableFuture, maxDate } = this.props
        const now = utils.date()
        return !utils.isAfter(
            utils.getStartOfMonth(disableFuture && utils.isBefore(now, maxDate)
                ? now
                : utils.date(maxDate)),
            this.state.currentMonth
        )
    }

    shouldDisableDate = day => {
        const {
            disablePast, disableFuture, shouldDisableDate, utils
        } = this.props

        return (
            (disableFuture && utils.isAfterDay(day, utils.date()))
            || (disablePast && utils.isBeforeDay(day, utils.date()))
            || this.validateMinMaxDate(day)
            || shouldDisableDate(day)
        )
    }

    moveToDay = day => {
        if (day && !this.shouldDisableDate(day)) {
            this.props.onChange(day)
        }
    }

    handleKeyDown = event => {
        const { theme, date, utils } = this.props

        switch (keycode(event)) {
            case 'up':
                this.moveToDay(utils.addDays(date, -7))
                break
            case 'down':
                this.moveToDay(utils.addDays(date, 7))
                break
            case 'left':
                theme.direction === 'ltr'
                    ? this.moveToDay(utils.addDays(date, -1))
                    : this.moveToDay(utils.addDays(date, 1))
                break
            case 'right':
                theme.direction === 'ltr'
                    ? this.moveToDay(utils.addDays(date, 1))
                    : this.moveToDay(utils.addDays(date, -1))
                break
            default:
                return
        }

        event.preventDefault()
    }

    renderWeeks = () => {
        const { utils } = this.props
        const { currentMonth } = this.state
        const weeks = utils.getWeekArray(currentMonth)

        return weeks.map(week => (
            <div
                key={`week-${week[0].toString()}`}
                className={this.props.classes.week}
            >
                {this.renderDays(week)}
            </div>
        ))
    }

    renderDays = week => {
        const { date, renderDay, utils } = this.props

        const selectedDate = utils.startOfDay(date)
        const currentMonthNumber = utils.getMonth(this.state.currentMonth)
        const now = utils.date()

        return week.map(day => {
            const disabled = this.shouldDisableDate(day)
            const dayInCurrentMonth = utils.getMonth(day) === currentMonthNumber

            let dayComponent = (
                <Day {...{
                    current: utils.isSameDay(day, now),
                    disabled,
                    hidden: !dayInCurrentMonth,
                    selected: utils.isSameDay(selectedDate, day)
                }}>
                    {utils.getDayText(day)}
                </Day>
            )

            if (renderDay) {
                dayComponent = renderDay(day, selectedDate, dayInCurrentMonth, dayComponent)
            }

            return (
                <DayWrapper
                    dayInCurrentMonth={dayInCurrentMonth}
                    disabled={disabled}
                    key={day.toString()}
                    onSelect={this.onDateSelect}
                    value={day}
                >
                    {dayComponent}
                </DayWrapper>
            )
        })
    }

    onDateSelect = (day, isFinish = true) => {
        const { date, utils } = this.props

        const withHours = utils.setHours(day, utils.getHours(date))
        const withMinutes = utils.setMinutes(withHours, utils.getMinutes(date))

        this.props.onChange(withMinutes, isFinish)
    }

    render() {
        const { currentMonth } = this.state
        const { classes, utils, allowKeyboardControl } = this.props

        return (
            <Fragment>
                {
                    allowKeyboardControl
                        && <EventListener target="window" onKeyDown={this.handleKeyDown} />
                }

                <CalendarHeader {...{
                    currentMonth,
                    disableNextMonth: this.shouldDisableNextMonth(),
                    disablePrevMonth: this.shouldDisablePrevMonth(),
                    leftArrowIcon: this.props.leftArrowIcon,
                    onMonthChange: this.handleChangeMonth,
                    rightArrowIcon: this.props.rightArrowIcon,
                    utils
                }}/>

                <div {...{
                    autoFocus: true,
                    className: classnames('au-date-picker-calendar', classes.calendar)
                }}>
                    {this.renderWeeks()}
                </div>
            </Fragment>
        )
    }
}

export default withStyles(calendarStyles, {
    name: 'MuiPickersCalendar',
    withTheme: true
})(withUtils()(AUCalendar))
