import classnames from 'classnames'
import PropTypes from 'prop-types'
import React from 'react'
import { withStyles } from '../../styles/'
import Typography from '../../typography'
import { toolbarButtonStyles } from '../styles/toolbar-button'


class AUToolbarButton extends React.Component {

    static propTypes = {
        classes: PropTypes.object.isRequired,
        className: PropTypes.string,
        label: PropTypes.string.isRequired,
        selected: PropTypes.bool.isRequired
    }

    static defaultProps = {
        className: ''
    }

    render() {
        const {
            classes, selected, label, className, ...other
        } = this.props

        return (
            <Typography {...{
                className: classnames('au-date-picker-toolbar-button', classes.toolbarBtn, className, {
                    [classes.toolbarBtnSelected]: selected
                }),
                ...other
            }}>
                { label }
            </Typography>
        )
    }
}

export default withStyles(toolbarButtonStyles, { name: 'MuiPickersToolbarButton' })(AUToolbarButton)
