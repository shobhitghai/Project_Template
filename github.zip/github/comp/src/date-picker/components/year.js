import classnames from 'classnames'
import PropTypes from 'prop-types'
import React, { PureComponent } from 'react'
import { withStyles } from '../../styles/'
import Typography from '../../typography'
import { yearStyles } from '../styles/year'


export class AUYear extends PureComponent {

    static propTypes = {
        children: PropTypes.node.isRequired,
        classes: PropTypes.object.isRequired,
        disabled: PropTypes.bool,
        onSelect: PropTypes.func.isRequired,
        selected: PropTypes.bool,
        value: PropTypes.any.isRequired
    }

    static defaultProps = {
        disabled: false,
        selected: false
    }

    handleClick = () => {
        this.props.onSelect(this.props.value)
    }

    render() {
        const {
            classes, selected, disabled, value, children, ...other
        } = this.props

        return (
            <Typography {...{
                className: classnames('au-date-picker-year', classes.root, {
                    [classes.selected]: selected,
                    [classes.disabled]: disabled
                }),
                color: selected ? 'primary' : 'initial',
                component: 'div',
                onClick: this.handleClick,
                onKeyPress: this.handleClick,
                role: 'button',
                tabIndex: disabled ? -1 : 0,
                variant: selected ? 'h5' : 'subtitle1',
                ...other
            }}>
                {children}
            </Typography>
        )
    }
}

export default withStyles(yearStyles, { name: 'MuiPickersYear' })(AUYear)
