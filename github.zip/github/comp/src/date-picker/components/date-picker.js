import PropTypes from 'prop-types'
import React, { PureComponent, Fragment } from 'react'
import DomainPropTypes from '../constants/prop-types'
import withUtils from '../with-utils'
import Calendar from './calendar'
import PickerToolbar from './picker-toolbar'
import ToolbarButton from './toolbar-button'
import YearSelection from './year-selection'


export class AUDatePicker extends PureComponent {

    static propTypes = {
        allowKeyboardControl: PropTypes.bool,
        animateYearScrolling: PropTypes.bool,
        children: PropTypes.node,
        date: PropTypes.object.isRequired,
        disableFuture: PropTypes.bool,
        disablePast: PropTypes.bool,
        leftArrowIcon: PropTypes.node,
        maxDate: DomainPropTypes.date,
        minDate: DomainPropTypes.date,
        onChange: PropTypes.func.isRequired,
        openToYearSelection: PropTypes.bool,
        renderDay: PropTypes.func,
        rightArrowIcon: PropTypes.node,
        shouldDisableDate: PropTypes.func,
        utils: PropTypes.object.isRequired
    }

    static defaultProps = {
        allowKeyboardControl: false,
        animateYearScrolling: undefined,
        children: null,
        disableFuture: false,
        disablePast: false,
        leftArrowIcon: undefined,
        maxDate: '2100-01-01',
        minDate: '1900-01-01',
        openToYearSelection: false,
        renderDay: undefined,
        rightArrowIcon: undefined,
        shouldDisableDate: undefined
    }

    state = {
        showYearSelection: this.props.openToYearSelection
    }

    get date() {
        return this.props.utils.startOfDay(this.props.date)
    }

    get minDate() {
        return this.props.utils.date(this.props.minDate)
    }

    get maxDate() {
        return this.props.utils.date(this.props.maxDate)
    }

    handleYearSelect = date => {
        this.props.onChange(date, false)
        this.openCalendar()
    }

    openYearSelection = () => {
        this.setState({ showYearSelection: true })
    }

    openCalendar = () => {
        this.setState({ showYearSelection: false })
    }

    render() {
        const {
            disablePast,
            disableFuture,
            onChange,
            animateYearScrolling,
            leftArrowIcon,
            rightArrowIcon,
            renderDay,
            utils,
            shouldDisableDate,
            allowKeyboardControl
        } = this.props
        const { showYearSelection } = this.state

        return (
            <Fragment>
                <PickerToolbar>
                    <ToolbarButton {...{
                        label: utils.getYearText(this.date),
                        onClick: this.openYearSelection,
                        selected: showYearSelection,
                        variant: 'subtitle1'
                    }}/>

                    <ToolbarButton {...{
                        label: utils.getDatePickerHeaderText(this.date),
                        onClick: this.openCalendar,
                        selected: !showYearSelection,
                        variant: 'h4'
                    }}/>
                </PickerToolbar>

                { this.props.children }

                {
                    showYearSelection
                        ? <YearSelection {...{
                            animateYearScrolling,
                            date: this.date,
                            disableFuture: disableFuture,
                            disablePast: disablePast,
                            maxDate: this.maxDate,
                            minDate: this.minDate,
                            onChange: this.handleYearSelect,
                            utils
                        }}/>
                        : <Calendar {...{
                            allowKeyboardControl,
                            date: this.date,
                            disableFuture,
                            disablePast,
                            leftArrowIcon,
                            maxDate: this.maxDate,
                            minDate: this.minDate,
                            onChange,
                            renderDay,
                            rightArrowIcon,
                            shouldDisableDate,
                            utils
                        }}/>
                }
            </Fragment>
        )
    }
}

export default withUtils()(AUDatePicker)
