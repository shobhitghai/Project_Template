import classnames from 'classnames'
import PropTypes from 'prop-types'
import React from 'react'
import { withStyles } from '../../styles/'
import Toolbar from '../../toolbar'
import { pickerToolbarStyles } from '../styles/picker-toolbar'


class AUPickerToolbar extends React.Component {

    static propTypes = {
        children: PropTypes.arrayOf(PropTypes.node).isRequired,
        classes: PropTypes.object.isRequired,
        className: PropTypes.string
    }

    static defaultProps = {
        className: ''
    }

    render() {
        const { children, className, classes, ...other } = this.props

        return (
            <Toolbar {...{
                className: classnames('au-date-picker-toolbar', classes.toolbar, className),
                ...other
            }}>
                { children }
            </Toolbar>
        )
    }
}

export default withStyles(pickerToolbarStyles, { name: 'MuiPickersToolbar' })(AUPickerToolbar)
