import keycode from 'keycode'
import PropTypes from 'prop-types'
import React, { Fragment, PureComponent } from 'react'
import DomainPropTypes from '../constants/prop-types'
import ModalDialog from './modal-dialog'
import DateTextField from './date-text-field'


const ModalWrapper = class extends PureComponent {

    static displayName = 'ModalWrapper'

    static propTypes = {
        cancelLabel: PropTypes.node,
        children: PropTypes.node.isRequired,
        clearable: PropTypes.bool,
        clearLabel: PropTypes.node,
        dialogContentClassName: PropTypes.string,
        format: PropTypes.string,
        invalidLabel: PropTypes.node,
        isAccepted: PropTypes.bool.isRequired,
        labelFunc: PropTypes.func,
        okLabel: PropTypes.node,
        onAccept: PropTypes.func,
        onClear: PropTypes.func,
        onClose: PropTypes.func,
        onDismiss: PropTypes.func,
        onOpen: PropTypes.func,
        onSetToday: PropTypes.func,
        showTodayButton: PropTypes.bool,
        todayLabel: PropTypes.string,
        value: DomainPropTypes.date
    }

    static defaultProps = {
        cancelLabel: 'Cancel',
        clearable: false,
        clearLabel: 'Clear',
        dialogContentClassName: '',
        format: undefined,
        invalidLabel: undefined,
        labelFunc: undefined,
        okLabel: 'OK',
        onAccept: undefined,
        onClear: undefined,
        onClose: undefined,
        onDismiss: undefined,
        onOpen: undefined,
        onSetToday: undefined,
        showTodayButton: false,
        todayLabel: 'Today',
        value: new Date()
    }

    state = {
        open: false
    }

    static getDerivedStateFromProps(nextProps) {

        if (nextProps.isAccepted) {
            return {
                open: false
            }
        }

        return null
    }

    handleKeyDown = event => {

        if (keycode(event) === 'enter') {
            this.handleAccept()
            event.preventDefault()
        }
    }

    handleSetTodayDate = () => {

        if (this.props.onSetToday) {
            this.props.onSetToday()
        }
    }

    open = () => {

        this.setState({ open: true })

        if (this.props.onOpen) {
            this.props.onOpen()
        }
    }

    close = () => {

        this.setState({ open: false })

        if (this.props.onClose) {
            this.props.onClose()
        }
    }

    handleAccept = () => {

        this.close()

        if (this.props.onAccept) {
            this.props.onAccept()
        }
    }

    handleDismiss = () => {

        this.close()

        if (this.props.onDismiss) {
            this.props.onDismiss()
        }
    }

    handleClear = () => {

        this.close()

        if (this.props.onClear) {
            this.props.onClear()
        }
    }

    render() {

        const {
            value,
            format,
            children,
            dialogContentClassName,
            onAccept,
            onDismiss,
            invalidLabel,
            labelFunc,
            okLabel,
            cancelLabel,
            clearLabel,
            clearable,
            todayLabel,
            showTodayButton,
            onOpen,
            onClose,
            onSetToday,
            isAccepted,
            ...other
        } = this.props

        return (
            <Fragment>
                <DateTextField {...{
                    clearable,
                    format,
                    invalidLabel,
                    labelFunc,
                    onClick: this.open,
                    value,
                    ...other
                }}/>

                <ModalDialog {...{
                    cancelLabel,
                    clearable,
                    clearLabel,
                    dialogContentClassName,
                    okLabel,
                    onAccept: this.handleAccept,
                    onClear: this.handleClear,
                    onDismiss: this.handleDismiss,
                    onKeyDown: this.handleKeyDown,
                    onSetToday: this.handleSetTodayDate,
                    open: this.state.open,
                    showTodayButton,
                    todayLabel
                }}>
                    {children}
                </ModalDialog>
            </Fragment>
        )
    }
}

export default ModalWrapper
