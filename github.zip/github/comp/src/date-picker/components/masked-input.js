import PropTypes from 'prop-types'
import React, { PureComponent } from 'react'
import MaskedInput from 'react-text-mask'


const AUMaskedInput = class extends PureComponent {

    static displayName = 'MaskedInput'

    static propTypes = {
        inputRef: PropTypes.func.isRequired,
        mask: PropTypes.any
    }

    static defaultProps = {
        mask: undefined
    }

    render() {
        const { inputRef, ...props } = this.props
        return (
            this.props.mask
                ? <MaskedInput {...{
                    ...props,
                    ref: inputRef
                }}/>
                : <input {...{
                    ...props,
                    ref: inputRef
                }}/>
        )
    }
}

export default AUMaskedInput
