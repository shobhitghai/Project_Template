// NB The DatePicker component is built upon a third party (for Material-UI) library: Material-UI Pickers. In order to use Aura components within it, as well as to maintain consistent styling, it has been necessary to duplicate a lot of the library here. Consult https://material-ui-pickers.firebaseapp.com/ for further information/use cases.
import ArrowBack from '@material-ui/icons/ArrowBack'
import ArrowForward from '@material-ui/icons/ArrowForward'
import PropTypes from 'prop-types'
import React from 'react'
import DomainPropTypes from '../constants/prop-types'
import { showDeprecationWarning } from '../../../utils'
import ModalWrapper from './modal-wrapper'
import BasePicker from './base-picker'
import DatePicker from './date-picker'


showDeprecationWarning('The DatePicker component has been deprecated. Please use DatePicker2 instead')

export class AUDatePickerWrapper extends React.Component {

    static propTypes = {
        allowKeyboardControl: PropTypes.bool,
        animateYearScrolling: PropTypes.bool,
        autoOk: PropTypes.bool,
        clearable: PropTypes.bool,
        disableFuture: PropTypes.bool,
        disablePast: PropTypes.bool,
        format: PropTypes.string,
        forwardedRef: PropTypes.func,
        labelFunc: PropTypes.func,
        leftArrowIcon: PropTypes.node,
        maxDate: DomainPropTypes.date,
        minDate: DomainPropTypes.date,
        onChange: PropTypes.func.isRequired,
        openToYearSelection: PropTypes.bool,
        renderDay: PropTypes.func,
        rightArrowIcon: PropTypes.node,
        shouldDisableDate: PropTypes.func,
        value: DomainPropTypes.date
    }

    static defaultProps = {
        allowKeyboardControl: false,
        animateYearScrolling: false,
        autoOk: true,
        clearable: false,
        disableFuture: false,
        disablePast: false,
        format: 'MMMM Do',
        forwardedRef: undefined,
        labelFunc: undefined,
        leftArrowIcon: <ArrowBack />,
        maxDate: '2100-01-01',
        minDate: '1900-01-01',
        onChange: () => {},
        openToYearSelection: false,
        renderDay: undefined,
        rightArrowIcon: <ArrowForward />,
        shouldDisableDate: undefined,
        value: new Date()
    }

    render() {
        const {
            allowKeyboardControl,
            animateYearScrolling,
            autoOk,
            disableFuture,
            disablePast,
            format,
            forwardedRef,
            labelFunc,
            leftArrowIcon,
            maxDate,
            minDate,
            onChange,
            openToYearSelection,
            renderDay,
            rightArrowIcon,
            shouldDisableDate,
            value,
            ...other
        } = this.props

        return (
            <BasePicker {...{
                ...this.props
            }}>
                {({
                    date,
                    handleAccept,
                    handleChange,
                    handleClear,
                    handleDismiss,
                    handleSetTodayDate,
                    handleTextFieldChange,
                    isAccepted
                }) => (
                    <ModalWrapper {...{
                        disableFuture,
                        disablePast,
                        format,
                        isAccepted,
                        labelFunc,
                        maxDate,
                        minDate,
                        onAccept: handleAccept,
                        onChange: handleTextFieldChange,
                        onClear: handleClear,
                        onDismiss: handleDismiss,
                        onSetToday: handleSetTodayDate,
                        ref: forwardedRef,
                        value,
                        ...other
                    }}>
                        <DatePicker {...{
                            allowKeyboardControl,
                            animateYearScrolling,
                            date,
                            disableFuture,
                            disablePast,
                            leftArrowIcon,
                            maxDate,
                            minDate,
                            onChange: handleChange,
                            openToYearSelection,
                            renderDay,
                            rightArrowIcon,
                            shouldDisableDate
                        }}/>
                    </ModalWrapper>
                )}
            </BasePicker>
        )
    }
}

export default React.forwardRef((props, ref) => (
    <AUDatePickerWrapper {...props} forwardedRef={ref} />
))
