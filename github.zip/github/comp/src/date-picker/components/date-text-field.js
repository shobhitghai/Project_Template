import Event from '@material-ui/icons/Event'
import PropTypes from 'prop-types'
import React, { PureComponent } from 'react'
import { withStyles } from '../../styles/'
import InputAdornment from '../../input-adornment'
import IconButton from '../../icon-button'
import TextField from '../../text-field'
import DomainPropTypes from '../constants/prop-types'
import { dateTextFieldStyles } from '../styles/date-text-field'
import withUtils from '../with-utils'
import MaskedInput from './masked-input'


const getDisplayDate = props => {
    const {
        utils, value, format, invalidLabel, emptyLabel, labelFunc
    } = props

    const isEmpty = value === null
    const date = utils.date(value)

    if (labelFunc) {
        return labelFunc(isEmpty ? null : date, invalidLabel)
    }

    if (isEmpty) {
        return emptyLabel
    }

    return utils.isValid(date)
        ? utils.format(date, format)
        : invalidLabel
}

const getError = (value, props) => {
    const {
        utils,
        maxDate,
        minDate,
        disablePast,
        disableFuture,
        maxDateMessage,
        minDateMessage,
        invalidDateMessage
    } = props

    if (!utils.isValid(value)) {
        if (utils.isNull(value)) {
            return ''
        }

        return invalidDateMessage
    }

    if (
        (maxDate && utils.isAfter(value, maxDate))
        || (disableFuture && utils.isAfter(value, utils.endOfDay(utils.date())))
    ) {
        return maxDateMessage
    }

    if (
        (minDate && utils.isBefore(value, minDate))
        || (disablePast && utils.isBefore(value, utils.startOfDay(utils.date())))
    ) {
        return minDateMessage
    }

    return ''
}

const updateState = props => ({
    displayValue: getDisplayDate(props),
    error: getError(props.utils.date(props.value), props),
    value: props.value
})

const AUDateTextField = withStyles(dateTextFieldStyles)(withUtils()(class DateTextField extends PureComponent {

    static displayName = 'AUDateTextField'

    static propTypes = {
        adornmentPosition: PropTypes.oneOf([ 'start', 'end' ]),
        classes: PropTypes.shape({}).isRequired,
        clearable: PropTypes.bool,
        disabled: PropTypes.bool,
        disableFuture: PropTypes.bool,
        disableOpenOnEnter: PropTypes.bool,
        disablePast: PropTypes.bool,
        emptyLabel: PropTypes.string,
        format: PropTypes.string,
        InputAdornmentProps: PropTypes.object,
        InputProps: PropTypes.shape(),
        invalidDateMessage: PropTypes.node,
        invalidLabel: PropTypes.string,
        keyboard: PropTypes.bool,
        keyboardIcon: PropTypes.node,
        labelFunc: PropTypes.func,
        mask: PropTypes.any,
        maxDate: DomainPropTypes.date,
        maxDateMessage: PropTypes.node,
        minDate: DomainPropTypes.date,
        minDateMessage: PropTypes.node,
        onBlur: PropTypes.func,
        onChange: PropTypes.func.isRequired,
        onClear: PropTypes.func,
        onClick: PropTypes.func.isRequired,
        onError: PropTypes.func,
        TextFieldComponent: PropTypes.oneOfType([ PropTypes.string, PropTypes.func, PropTypes.object ]),
        utils: PropTypes.object.isRequired,
        value: PropTypes.oneOfType([
            PropTypes.object,
            PropTypes.string,
            PropTypes.number,
            PropTypes.instanceOf(Date)
        ])
    }

    static defaultProps = {
        adornmentPosition: 'end',
        clearable: false,
        disabled: false,
        disableFuture: false,
        disableOpenOnEnter: false,
        disablePast: false,
        emptyLabel: '',
        format: undefined,
        InputAdornmentProps: {},
        InputProps: undefined,
        invalidDateMessage: 'Invalid Date Format',
        invalidLabel: 'Unknown',
        keyboard: true,
        keyboardIcon: 'event',
        labelFunc: undefined,
        mask: undefined,
        maxDate: '2100-01-01',
        maxDateMessage: 'Date should not be after maximal date',
        minDate: '1900-01-01',
        minDateMessage: 'Date should not be before minimal date',
        onBlur: undefined,
        onClear: undefined,
        onError: undefined,
        TextFieldComponent: TextField,
        value: new Date()
    }

    state = updateState(this.props)

    componentDidUpdate(prevProps) {
        if (
            !this.props.utils.isEqual(this.props.value, prevProps.value)
            || prevProps.format !== this.props.format
            || prevProps.maxDate !== this.props.maxDate
            || prevProps.minDate !== this.props.minDate
            || prevProps.emptyLabel !== this.props.emptyLabel
            || prevProps.utils !== this.props.utils
        ) {
            this.setState(updateState(this.props))
        }
    }

    commitUpdates = value => {
        const {
            clearable,
            format,
            onClear,
            onError,
            utils
        } = this.props

        if (value === '') {
            if (this.props.value === null) {
                this.setState(updateState(this.props))
            } else if (clearable && onClear) {
                onClear()
            }

            return
        }

        const oldValue = utils.date(this.state.value)
        const newValue = utils.parse(value, format)
        const error = getError(newValue, this.props)

        this.setState({
            displayValue: value,
            error,
            value: error ? newValue : oldValue
        }, () => {
            if (!error && !utils.isEqual(newValue, oldValue)) {
                this.props.onChange(newValue)
            }

            if (error && onError) {
                onError(newValue, error)
            }
        })
    }

    handleBlur = e => {
        if (this.props.keyboard) {
            e.preventDefault()
            e.stopPropagation()

            this.commitUpdates(e.target.value)
            if (this.props.onBlur) {
                this.props.onBlur(e)
            }
        }
    }

    handleChange = e => {
        const { utils, format } = this.props
        const parsedValue = utils.parse(e.target.value, format)

        this.setState({
            displayValue: e.target.value,
            error: getError(parsedValue, this.props)
        })
    }

    handleFocus = e => {
        e.stopPropagation()
        e.preventDefault()

        if (!this.props.keyboard) {
            this.openPicker(e)
        }
    }

    handleKeyPress = e => {
        if (e.key === 'Enter') {
            if (!this.props.disableOpenOnEnter) {
                this.openPicker(e)
            } else {
                this.commitUpdates(e.target.value)
            }
        }
    }

    openPicker = e => {
        const { disabled, onClick } = this.props

        if (!disabled) {
            onClick(e)
        }
    }

    render() {
        const {
            adornmentPosition,
            classes,
            clearable,
            disabled,
            disableFuture,
            disableOpenOnEnter,
            disablePast,
            emptyLabel,
            format,
            InputAdornmentProps,
            InputProps,
            invalidDateMessage,
            invalidLabel,
            keyboard,
            keyboardIcon,
            labelFunc,
            mask,
            maxDate,
            maxDateMessage,
            minDate,
            minDateMessage,
            onBlur,
            onClear,
            onClick,
            TextFieldComponent,
            utils,
            value,
            ...other
        } = this.props

        const { displayValue, error } = this.state
        const localInputProps = {
            className: classes.input,
            inputComponent: MaskedInput,
            inputProps: {
                mask: !keyboard ? null : mask,
                readOnly: !keyboard
            }
        }

        if (keyboard) {
            localInputProps[`${adornmentPosition}Adornment`] = (
                <InputAdornment {...{
                    position: adornmentPosition,
                    ...InputAdornmentProps
                }}>
                    <IconButton {...{
                        disabled,
                        onClick: this.openPicker
                    }}>
                        <Event />
                    </IconButton>
                </InputAdornment>
            )
        }

        return (
            <TextFieldComponent {...{
                disabled,
                error: !!error,
                helperText: error,
                InputProps: {
                    ...localInputProps,
                    ...InputProps
                },
                onBlur: this.handleBlur,
                ...other,
                onChange: this.handleChange,
                onClick: this.handleFocus,
                onKeyPress: this.handleKeyPress,
                value: displayValue
            }}/>
        )
    }
}))

export default AUDateTextField
