/* eslint-disable react/no-find-dom-node */

import classnames from 'classnames'
import fp from 'lodash/fp'
import PropTypes from 'prop-types'
import React, { PureComponent } from 'react'
import { findDOMNode } from 'react-dom'
import { withStyles } from '../../styles/'
import DomainPropTypes from '../constants/prop-types'
import withUtils from '../with-utils'
import Year from './year'


const styles = {
    container: {
        justifyContent: 'center',
        maxHeight: 300 - 64,
        overflowY: 'auto'
    }
}

const AUDatePickerYearSelection = withStyles(styles, { name: 'MuiPickersYearSelection' })(withUtils()(class extends PureComponent {

    static displayName = 'AUDatePickerYearSelection'

    static propTypes = {
        animateYearScrolling: PropTypes.bool,
        classes: PropTypes.object.isRequired,
        date: PropTypes.shape({}).isRequired,
        disableFuture: PropTypes.bool.isRequired,
        disablePast: PropTypes.bool.isRequired,
        maxDate: DomainPropTypes.date.isRequired,
        minDate: DomainPropTypes.date.isRequired,
        onChange: PropTypes.func.isRequired,
        utils: PropTypes.object.isRequired
    }

    static defaultProps = {
        animateYearScrolling: false
    }

    componentDidMount = () => {
        this.scrollToCurrentYear()
    }

    getSelectedYearRef = ref => {
        this.selectedYearRef = ref
    }

    scrollToCurrentYear = () => {
        const { animateYearScrolling } = this.props

        const currentYearElement = findDOMNode(this.selectedYearRef)

        if (currentYearElement && currentYearElement.scrollIntoView) {
            currentYearElement.scrollIntoView({
                behavior: animateYearScrolling ? 'smooth' : 'auto'
            })
        }
    }

    selectedYearRef = undefined

    onYearSelect = year => {
        const { date, onChange, utils } = this.props

        const newDate = utils.setYear(date, year)
        onChange(newDate)
    }

    render() {
        const {
            minDate, maxDate, date, classes, disablePast, disableFuture, utils
        } = this.props

        const currentYear = utils.getYear(date)

        return (
            <div {...{
                className: classnames('au-date-picker-year-selector', classes.container)
            }}>
                {fp.map(year => {
                    const yearNumber = utils.getYear(year)
                    const selected = yearNumber === currentYear

                    return (
                        <Year
                            disabled = {(
                                (disablePast && utils.isBeforeYear(year, utils.date()))
                                || (disableFuture && utils.isAfterYear(year, utils.date()))
                            )}
                            key = {utils.getYearText(year)}
                            onSelect = {this.onYearSelect}
                            ref = {selected
                                ? this.getSelectedYearRef
                                : undefined
                            }
                            selected = {selected}
                            value = {yearNumber}
                        >
                            {utils.getYearText(year)}
                        </Year>
                    )
                }, utils.getYearRange(minDate, maxDate))}
            </div>
        )
    }
}))

export default AUDatePickerYearSelection
