export const YEAR = 'year'

export const DATE = 'date'

export const HOUR = 'hour'

export const MINUTES = 'minutes'
