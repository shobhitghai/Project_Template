import React, { Component } from 'react'
import PropTypes from 'prop-types'


const { Consumer, Provider } = React.createContext()
export const MuiPickersContextConsumer = Consumer

export default class MuiPickersUtilsProvider extends Component {
    static propTypes = {
        children: PropTypes.oneOfType([
            PropTypes.element.isRequired,
            PropTypes.arrayOf(PropTypes.element.isRequired)
        ]).isRequired,
        locale: PropTypes.oneOfType([ PropTypes.object, PropTypes.string ]),
        moment: PropTypes.func,
        utils: PropTypes.func.isRequired
    }

    static defaultProps = {
        locale: undefined,
        moment: undefined
    }

    state = {
        utils: null
    }

    static getDerivedStateFromProps({ utils: Utils, locale, moment }) {
        return {
            utils: new Utils({ locale, moment })
        }
    }

    render() {
        return <Provider value={this.state.utils}>{this.props.children}</Provider>
    }
}
