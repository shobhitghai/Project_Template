import addDays from 'date-fns/addDays'
import addMonths from 'date-fns/addMonths'
import addYears from 'date-fns/addYears'
import differenceInMilliseconds from 'date-fns/differenceInMilliseconds'
import eachDayOfInterval from 'date-fns/eachDayOfInterval'
import endOfDay from 'date-fns/endOfDay'
import endOfMonth from 'date-fns/endOfMonth'
import endOfWeek from 'date-fns/endOfWeek'
import endOfYear from 'date-fns/endOfYear'
import format from 'date-fns/format'
import getHours from 'date-fns/getHours'
import getSeconds from 'date-fns/getSeconds'
import getYear from 'date-fns/getYear'
import isAfter from 'date-fns/isAfter'
import isBefore from 'date-fns/isBefore'
import isEqual from 'date-fns/isEqual'
import isSameDay from 'date-fns/isSameDay'
import isValid from 'date-fns/isValid'
import parse from 'date-fns/parse'
import parseISO from 'date-fns/parseISO'
import setHours from 'date-fns/setHours'
import setMinutes from 'date-fns/setMinutes'
import setSeconds from 'date-fns/setSeconds'
import setYear from 'date-fns/setYear'
import startOfDay from 'date-fns/startOfDay'
import startOfMonth from 'date-fns/startOfMonth'
import startOfWeek from 'date-fns/startOfWeek'
import startOfYear from 'date-fns/startOfYear'


export default class DateFnsUtils {
    constructor({ locale } = {}) {
        this.locale = locale
    }

    date(value) {
        if (typeof value === 'undefined') {
            return new Date()
        }

        if (value === null) {
            return null
        }

        return new Date(value)
    }

    parse(value, format) {
        if (value === '') {
            return null
        }

        if (format) {
            return parse(value, format, new Date())
        }

        return typeof value === 'string' ? parseISO(value) : value
    }

    format(date, formatString) {
        return format(this.parse(date), formatString, { locale: this.locale })
    }

    isEqual(date, comparing) {
        if (date === null && comparing === null) {
            return true
        }

        return isEqual(this.parse(date), this.parse(comparing))
    }

    withParse = func => (...args) => func(...args.map(arg => this.parse(arg)))

    addDays = this.withParse(addDays)

    isValid = isValid

    getDiff = this.withParse(differenceInMilliseconds)

    isNull(date) {
        return date === null
    }

    isAfter = this.withParse(isAfter)

    isBefore = this.withParse(isBefore)

    isAfterDay(date, value) {
        return isAfter(date, endOfDay(this.parse(value)))
    }

    isBeforeDay(date, value) {
        return isBefore(date, startOfDay(this.parse(value)))
    }

    isBeforeYear(date, value) {
        return isBefore(date, startOfYear(this.parse(value)))
    }

    isAfterYear(date, value) {
        return isAfter(date, endOfYear(this.parse(value)))
    }

    startOfDay = this.withParse(startOfDay)

    endOfDay = this.withParse(endOfDay)

    formatNumber(num) {
        return num
    }

    getHours = this.withParse(getHours)

    setHours = this.withParse(setHours)

    getMinutes(date) {
        return date.getMinutes()
    }

    setMinutes = this.withParse(setMinutes)

    getSeconds = this.withParse(getSeconds)

    setSeconds = this.withParse(setSeconds)

    getMonth(date) {
        return date.getMonth()
    }

    isSameDay = this.withParse(isSameDay)

    getMeridiemText(ampm) {
        return ampm === 'am' ? 'AM' : 'PM'
    }

    getStartOfMonth = this.withParse(startOfMonth)

    getNextMonth = this.withParse(date => {
        return addMonths(date, 1)
    })

    getPreviousMonth = this.withParse(date => {
        return addMonths(date, -1)
    })

    getYear = this.withParse(getYear)

    setYear = this.withParse(setYear)

    getWeekdays() {
        const now = new Date()
        return eachDayOfInterval(
            {
                end: endOfWeek(now, { locale: this.locale }),
                start: startOfWeek(now, { locale: this.locale })
            },
            { locale: this.locale }
        ).map(day => format(day, 'EEEEEE', { locale: this.locale }))
    }

    getWeekArray(date) {
        const start = startOfWeek(startOfMonth(date), { locale: this.locale })
        const end = endOfWeek(endOfMonth(date), { locale: this.locale })

        const nestedWeeks = []
        let count = 0
        let current = start

        while (isBefore(current, end)) {
            const weekNumber = Math.floor(count / 7)
            nestedWeeks[weekNumber] = nestedWeeks[weekNumber] || []
            nestedWeeks[weekNumber].push(current)
            current = addDays(current, 1)
            count += 1
        }

        return nestedWeeks
    }

    getYearRange(start, end) {
        const startDate = startOfYear(new Date(start))
        const endDate = endOfYear(new Date(end))
        const years = []

        let current = startDate

        while (isBefore(current, endDate)) {
            years.push(current)
            current = addYears(current, 1)
        }

        return years
    }

    getCalendarHeaderText = this.withParse(date => {
        return format(date, 'MMMM yyyy', { locale: this.locale })
    })

    getYearText = this.withParse(date => {
        return format(date, 'yyyy', { locale: this.locale })
    })

    getDatePickerHeaderText = this.withParse(date => {
        return format(date, 'EEE, MMM d', { locale: this.locale })
    })

    getDateTimePickerHeaderText = this.withParse(date => {
        return format(date, 'MMM d', { locale: this.locale })
    })

    getDayText = this.withParse(date => {
        return format(date, 'd', { locale: this.locale })
    })

    getHourText = this.withParse((date, ampm) => {
        return format(date, ampm ? 'hh' : 'HH', { locale: this.locale })
    })

    getMinuteText = this.withParse(date => {
        return format(date, 'mm', { locale: this.locale })
    })

    getSecondText = this.withParse(date => {
        return format(date, 'ss', { locale: this.locale })
    })
}
