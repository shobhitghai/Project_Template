import React from 'react'
import * as enzyme from 'enzyme'
import DateFnsUtils from '../utils/date-fns-utils'
import MomentUtils from '../utils/moment-utils'


const getUtilToUse = () => {
    switch (process.env.UTILS) {
        case 'moment':
            return new MomentUtils()
        case 'date-fns':
            return new DateFnsUtils()
        default:
            return new DateFnsUtils()
    }
}

export const utilsToUse = getUtilToUse()

const getComponentWithUtils = Component => React.cloneElement(Component, { utils: utilsToUse })

export const shallow = Component => enzyme.shallow(getComponentWithUtils(Component))

export const mount = Component => enzyme.mount(getComponentWithUtils(Component))

jest.doMock('../with-utils', () => {
    const WithUtils = () => Component => {
        const withUtils = props => <Component utils={utilsToUse} {...props} />
        withUtils.displayName = `WithUtils(${Component.displayName || Component.name})`

        return withUtils
    }

    return WithUtils
})
