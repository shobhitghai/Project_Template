import React from 'react'
import { configure, shallow } from 'enzyme'
import EnzymeAdapter from 'enzyme-react-adapter-future'
import DateFnsUtils from '../../utils/date-fns-utils'
import MuiPickersUtilsProvider from '../../utils/mui-pickers-utils-provider'


configure({ adapter: new EnzymeAdapter() })

describe('MuiPickersUtilsProvider', () => {
    let muiPickersUtilsProvider

    beforeEach(() => {
        muiPickersUtilsProvider = shallow(
            <MuiPickersUtilsProvider {...{
                children: <div />,
                utils: DateFnsUtils
            }}/>
        )
    })

    it('Should render', () => {
        expect(muiPickersUtilsProvider).toBeTruthy()
    })
})
