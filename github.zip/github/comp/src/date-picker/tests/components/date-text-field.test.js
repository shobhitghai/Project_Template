import { createMount } from '@material-ui/core/test-utils'
import React from 'react'
import { configure } from 'enzyme'
import EnzymeAdapter from 'enzyme-react-adapter-future'
import DateTextField from '../../components/date-text-field'
import { shallow, utilsToUse } from '../test-utils'


configure({ adapter: new EnzymeAdapter() })

let dateTextField

describe('DateTextField', () => {

    beforeEach(() => {
        dateTextField = shallow(
            <DateTextField {...{
                classes: {},
                format: 'dd/MM/yyyy',
                onChange: jest.fn(),
                onClick: jest.fn(),
                utils: utilsToUse,
                value: utilsToUse.date()
            }}/>
        )
    })

    it('Should renders', () => {
        expect(dateTextField).toBeTruthy()
    })
})

describe('DateTextField keboard mode', () => {

    beforeEach(() => {
        dateTextField = shallow(
            <DateTextField {...{
                classes: {},
                clearable: true,
                format: 'dd/MM/yyyy',
                keyboard: true,
                onChange: jest.fn(),
                onClear: jest.fn(),
                onClick: jest.fn(),
                utils: utilsToUse,
                value: utilsToUse.date()
            }}/>
        )
    })
})

describe('DateTextField with custom TextField', () => {

    it('Should handle a component function', () => {
        function CustomTextField(props) {
            return (
                <li {...props} />
            )
        }

        const dateTextField = shallow(
            <DateTextField {...{
                classes: {},
                format: 'dd/MM/yyyy',
                onChange: jest.fn(),
                onClick: jest.fn(),
                TextFieldComponent: CustomTextField,
                utils: utilsToUse,
                value: utilsToUse.date()
            }}/>)

        // Check InputProps to make sure DateTextField is passing props to the custom component
        expect(dateTextField.props('InputProps')).toBeTruthy()
        expect(dateTextField.find('li')).toBeTruthy()
    })

    it('Should handle a component string', () => {
        const dateTextField = shallow(
            <DateTextField {...{
                classes: {},
                format: 'dd/MM/yyyy',
                onChange: jest.fn(),
                onClick: jest.fn(),
                TextFieldComponent: 'li',
                utils: utilsToUse,
                value: utilsToUse.date()
            }}/>
        )

        expect(dateTextField.props('InputProps')).toBeTruthy()
        expect(dateTextField.find('li')).toBeTruthy()
    })

    it('Should not handle a node', () => {
        const mount = createMount()

        // eslint-disable-next-line
        spyOn(console, 'error')

        expect(() => {
            mount(
                <DateTextField {...{
                    classes: {},
                    format: 'dd/MM/yyyy',
                    onChange: jest.fn(),
                    onClick: jest.fn(),
                    TextFieldComponent: <div />,
                    utils: utilsToUse,
                    value: utilsToUse.date()
                }}/>
            )
        }).toThrow()
    })
})
