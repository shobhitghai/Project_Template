import React from 'react'
import { configure } from 'enzyme'
import EnzymeAdapter from 'enzyme-react-adapter-future'
import ModalDialog from '../../components/modal-dialog'
import { shallow } from '../test-utils'


configure({ adapter: new EnzymeAdapter() })

const initialProps = {
    cancelLabel: 'Cancel',
    children: 'Test',
    classes: {},
    clearable: false,
    clearLabel: 'Clear',
    okLabel: 'OK',
    onAccept: jest.fn(),
    onClear: jest.fn(),
    onDismiss: jest.fn(),
    onKeyDown: jest.fn(),
    onSetToday: jest.fn(),
    showTodayButton: false,
    todayLabel: 'Today'
}

describe('ModalDialog', () => {
    let modalDialog
    const props = { ...initialProps }

    beforeEach(() => {
        modalDialog = shallow(
            <ModalDialog {...props} />
        )
    })

    it('Should renders', () => {
        expect(modalDialog).toBeTruthy()
    })
})
