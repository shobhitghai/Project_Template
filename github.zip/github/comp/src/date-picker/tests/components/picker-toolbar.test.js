import React from 'react'
import { configure } from 'enzyme'
import EnzymeAdapter from 'enzyme-react-adapter-future'
import PickerToolbar from '../../components/picker-toolbar'
import { shallow } from '../test-utils'


configure({ adapter: new EnzymeAdapter() })

describe('PickerToolbar', () => {
    let pickerToolbar

    beforeEach(() => {
        pickerToolbar = shallow(
            <PickerToolbar {...{
                children: []
            }} />
        )
    })

    it('Should renders', () => {
        expect(pickerToolbar).toBeTruthy()
    })
})
