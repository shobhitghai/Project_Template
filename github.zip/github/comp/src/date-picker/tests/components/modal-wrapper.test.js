import React from 'react'
import { configure } from 'enzyme'
import EnzymeAdapter from 'enzyme-react-adapter-future'
import ModalWrapper from '../../components/modal-wrapper'
import { shallow } from '../test-utils'


configure({ adapter: new EnzymeAdapter() })

describe('ModalWrapper', () => {
    let modalWrapper

    beforeEach(() => {
        modalWrapper = shallow(
            <ModalWrapper {...{
                children: <div />,
                classes: {},
                isAccepted: true,
                onAccept: jest.fn(),
                onChange: jest.fn(),
                onClear: jest.fn(),
                onClose: jest.fn(),
                onDismiss: jest.fn(),
                onOpen: jest.fn(),
                value: new Date()
            }} />
        )
    })

    it('Should renders', () => {
        expect(modalWrapper).toBeTruthy()
    })
})
