import React from 'react'
import { configure } from 'enzyme'
import EnzymeAdapter from 'enzyme-react-adapter-future'
import YearSelection from '../../components/year-selection'
import { shallow, utilsToUse } from '../test-utils'


configure({ adapter: new EnzymeAdapter() })

describe('Date Picker', () => {
    it('Should render', () => {
        const yearSelection = shallow(
            <YearSelection {...{
                classes: {},
                date: utilsToUse.date('01-01-2017'),
                disableFuture: false,
                disablePast: false,
                maxDate: '2100-01-01',
                minDate: '1900-01-01',
                onChange: () => {},
                utils: {}
            }}/>
        )

        expect(yearSelection).toBeTruthy()
    })
})
