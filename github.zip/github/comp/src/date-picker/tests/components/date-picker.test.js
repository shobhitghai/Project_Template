import React from 'react'
import { configure } from 'enzyme'
import EnzymeAdapter from 'enzyme-react-adapter-future'
import DatePicker from '../../components/date-picker'
import { shallow, utilsToUse } from '../test-utils'


configure({ adapter: new EnzymeAdapter() })

describe('Date Picker', () => {
    it('Should render', () => {
        const datePicker = shallow(
            <DatePicker {...{
                classes: {},
                date: utilsToUse.date('01-01-2017')
            }}/>
        )

        expect(datePicker).toBeTruthy()
    })
})
