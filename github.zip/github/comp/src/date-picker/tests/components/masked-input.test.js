import React from 'react'
import { configure } from 'enzyme'
import EnzymeAdapter from 'enzyme-react-adapter-future'
import MaskedInput from '../../components/masked-input'
import { shallow } from '../test-utils'


configure({ adapter: new EnzymeAdapter() })

describe('MakedInput', () => {
    let maskedInput

    beforeEach(() => {
        maskedInput = shallow(
            <MaskedInput {...{
                inputRef: jest.fn(),
                mask: []
            }}/>
        )
    })

    it('Should renders', () => {
        expect(maskedInput).toBeTruthy()
    })
})
