import React from 'react'
import { configure } from 'enzyme'
import EnzymeAdapter from 'enzyme-react-adapter-future'
import ToolbarButton from '../../components/toolbar-button'
import { shallow } from '../test-utils'


configure({ adapter: new EnzymeAdapter() })

describe('Toolbar Button', () => {
    let toolbarButton

    beforeEach(() => {
        toolbarButton = shallow(
            <ToolbarButton {...{
                label: '',
                selected: false
            }} />
        )
    })

    it('Should renders', () => {
        expect(toolbarButton).toBeTruthy()
    })
})
