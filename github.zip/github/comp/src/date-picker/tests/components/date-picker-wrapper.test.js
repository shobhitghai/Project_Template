import React from 'react'
import { configure } from 'enzyme'
import EnzymeAdapter from 'enzyme-react-adapter-future'
import DatePickerWrapper from '../../components/date-picker-wrapper'
import { shallow, utilsToUse } from '../test-utils'


configure({ adapter: new EnzymeAdapter() })

const props = {
    format: 'YYYY',
    keyboard: true,
    onChange: jest.fn(),
    value: utilsToUse.date('2018', 'YYYY')
}

describe('DatePickerWrapper', () => {
    let datePickerWrapper

    beforeEach(() => {
        datePickerWrapper = shallow(
            <DatePickerWrapper {...props} />
        )
    })

    it('Should renders', () => {
        expect(datePickerWrapper).toBeTruthy()
    })
})
