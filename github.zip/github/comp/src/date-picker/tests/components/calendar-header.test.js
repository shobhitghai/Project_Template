import React from 'react'
import { configure } from 'enzyme'
import EnzymeAdapter from 'enzyme-react-adapter-future'
import CalendarHeader from '../../components/calendar-header'
import { shallow, utilsToUse } from '../test-utils'


configure({ adapter: new EnzymeAdapter() })

describe('Calendar Header', () => {
    it('Should render', () => {
        const calendarHeader = shallow(
            <CalendarHeader {...{
                classes: {},
                currentMonth: utilsToUse.date('01-01-2017'),
                theme: {}
            }}/>
        )

        expect(calendarHeader).toBeTruthy()
    })
})
