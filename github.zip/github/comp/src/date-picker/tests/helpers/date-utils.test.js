import { findClosestEnabledDate } from '../../helpers/date-utils'
import { utilsToUse } from '../test-utils'


describe('findClosestEnabledDate', () => {
    it('Should return now if its enabled and passed disablePast | disableFuture', () => {
        const today = utilsToUse.format(utilsToUse.date(), 'yyyy-MM-dd')
        const result = findClosestEnabledDate({
            date: utilsToUse.date('2000-01-01'),
            disableFuture: true,
            disablePast: true,
            maxDate: '2100-01-01',
            minDate: '2100-01-01',
            shouldDisableDate: () => false,
            utils: utilsToUse
        })

        expect(utilsToUse.format(result, 'yyyy-MM-dd')).toBe(today)
    })

    it('Should return min date if its closest to now', () => {
        const result = findClosestEnabledDate({
            date: utilsToUse.date('2000-01-01'),
            disableFuture: false,
            disablePast: false,
            maxDate: '2100-01-01',
            minDate: '2010-01-01',
            shouldDisableDate: () => false,
            utils: utilsToUse
        })

        expect(result).toEqual(utilsToUse.date('2010-01-01'))
    })

    it('Should return max date if its closest to now', () => {
        const result = findClosestEnabledDate({
            date: utilsToUse.date('2000-01-01'),
            disableFuture: false,
            disablePast: false,
            maxDate: '2010-01-01',
            minDate: '1900-01-01',
            shouldDisableDate: () => false,
            utils: utilsToUse
        })

        expect(result).toEqual(utilsToUse.date('2010-01-01'))
    })
})
