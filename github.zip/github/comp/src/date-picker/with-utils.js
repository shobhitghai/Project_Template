import React from 'react'
import { MuiPickersContextConsumer } from './utils/mui-pickers-utils-provider'
import Utils from './utils/date-fns-utils'


const utils = new Utils({})

const WithUtils = () => Component => {
    const withUtils = props => (
        <MuiPickersContextConsumer>
            {_ => <Component utils={utils} {...props} />}
        </MuiPickersContextConsumer>
    )

    withUtils.displayName = `WithUtils(${Component.displayName || Component.name})`

    return withUtils
}

export default WithUtils
