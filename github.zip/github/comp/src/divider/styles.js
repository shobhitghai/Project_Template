/* eslint-disable */
export const dividerStyles = theme => {
    return {       
        inset: {
            marginLeft: theme.spacing(4)
        }
    }
}
