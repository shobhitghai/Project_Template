/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { absolute, variantDivider, light } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Divider from './divider'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Divider'
}

export const Basic = () => <Divider {...{
        absolute: absolute(),
        variant: variantDivider(),
        light: light()
    }} />
