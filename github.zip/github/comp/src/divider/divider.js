import { Divider } from '@material-ui/core'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { dividerStyles } from './styles'


const AUDivider = withTelemetry(withStyles(dividerStyles)(class extends React.Component {

    static displayName = 'AUDivider'

    static propTypes = Divider.propTypes

    render() {

        const { props } = this

        return (
            <Divider {...{
                ...props,
                className: classnames('au-divider', props.className)
            }} />
        )
    }
}))

export default AUDivider
