export { default } from './divider'
