/* eslint-disable */
import AddIcon from '@material-ui/icons/Add'
import { action } from '@storybook/addon-actions'
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { color, disabled, size } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Fab from './fab'


const onClick = e => action('click')(e)

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Fab'
}

export const Basic = () => (
    <Fab {...{
        color: color(),
        disabled: disabled(),
        size: size(),
        onClick
    }}>
        <AddIcon />
    </Fab>
)
