export { default } from './fab'
