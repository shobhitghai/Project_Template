/* eslint-disable */

export const buttonStyles = theme => {

    return {
        root: {
            fontSize: theme.typography.button.fontSize,
            lineHeight: `${theme.spacing(2)}px`,
            minHeight: 'auto',
            minWidth: 'auto',

            '& .icon': {
                fontSize: theme.spacing(2)
            },

            '& .iconLeft': {
                marginRight: theme.spacing(1)
            },

            '& .iconRight': {
                marginLeft: theme.spacing(1)
            }
        }
    }
}
