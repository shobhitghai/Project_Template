import Fab from '@material-ui/core/Fab'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { buttonStyles } from './styles'


const AUFab = withTelemetry(withStyles(buttonStyles)(class extends React.Component {

    static displayName = 'AUFab'

    static defaultProps = {
        color: 'primary',
        disabled: false,
        variant: 'round'
    }

    static propTypes = Fab.propTypes

    render() {

        const { props } = this

        return (
            <Fab {...{
                ...props,
                className: classnames('au-fab', props.className, {
                    'au-fab-primary': props.color === 'primary'
                })
            }} />
        )
    }
}))

export default AUFab
