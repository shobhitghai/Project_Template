/* eslint-disable */
export const formControlLabelStyles = theme => {
    return {
        root: {
            height: theme.spacing(4),
            marginLeft: 0
        },
        label: {
            lineHeight: 'normal',
            marginLeft: theme.spacing(0.5),
            userSelect: 'none'
        }  
    }
}
