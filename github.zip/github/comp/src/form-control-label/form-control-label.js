import { FormControlLabel } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { formControlLabelStyles } from './styles'


const AUFormControlLabel = withStyles(formControlLabelStyles)(class extends React.Component {

    static displayName = 'AUFormControlLabel'

    render() {

        const { props } = this

        return (
            <FormControlLabel {...{
                ...props,
                className: classnames('au-form-control-label', props.className)
            }} />
        )
    }
})

export default AUFormControlLabel
