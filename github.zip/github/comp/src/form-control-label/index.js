export { default } from './form-control-label'
