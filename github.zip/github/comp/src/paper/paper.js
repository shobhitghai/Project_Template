import { Paper } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { paperStyles } from './styles'


const AUPaper = withTelemetry(withStyles(paperStyles)(class extends React.Component {

    static displayName = 'AUPaper'

    static propTypes = Paper.propTypes

    static defaultProps = {
        elevation: 0,
        square: true
    }

    render() {

        const { props } = this

        return (
            <Paper {... {
                ...props,
                className: classnames('au-paper', props.className)
            }} />
        )
    }
}))

export default AUPaper
