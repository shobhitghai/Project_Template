/* eslint-disable */
export const paperStyles = theme => {
    return {
        root: {
            borderRadius: 0,
            padding: theme.spacing(2)
        }
    }
}
