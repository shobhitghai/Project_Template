export default {
    classes: {
        root: 'au-paper'
    },
    square: true
}
