export { default } from './paper'
