/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import jss from 'jss'
import preset from 'jss-preset-default'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { elevation } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Paper from './paper'


jss.setup(preset())

const styles = {
    paper: {
        height: 320,
        margin: '32px',
        width: 320
    }
}

const {classes} = jss.createStyleSheet(styles).attach()

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Paper'
}

export const Basic = () => (
    <Paper {...{
        className: classes.paper,
        elevation: elevation()
    }} />
)
