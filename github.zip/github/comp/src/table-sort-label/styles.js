/* eslint-disable */
export const tableSortLabelStyles = theme => {

    return {       
        root: {
            '& svg': {
                fontSize: theme.typography.body2.fontSize
            }
        }
    }
}
