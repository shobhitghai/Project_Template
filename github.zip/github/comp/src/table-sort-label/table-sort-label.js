import { TableSortLabel } from '@material-ui/core'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { tableSortLabelStyles } from './styles'


const AUTableSortLabel = withTelemetry(withStyles(tableSortLabelStyles)(class extends React.Component {

    static displayName = 'AUTableSortLabel'

    static propTypes = TableSortLabel.propTypes

    render() {

        const { props } = this

        return (
            <TableSortLabel {...{
                ...props,
                className: classnames('au-table-sort-label', props.className)
            }} />
        )
    }
}))

export default AUTableSortLabel
