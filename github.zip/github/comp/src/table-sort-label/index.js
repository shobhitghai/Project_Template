export { default } from './table-sort-label'
