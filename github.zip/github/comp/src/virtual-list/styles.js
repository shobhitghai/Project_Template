/* eslint-disable */

export const listStyles = theme => {

    return {
        row: {
            display: 'flex',
            alignItems: 'center',
            alignContent: 'center',
            justifyContent: 'center'
        }
    }
}
