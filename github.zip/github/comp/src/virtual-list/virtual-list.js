import classnames from 'classnames'
import PropTypes from 'prop-types'
import React from 'react'
import { AutoSizer, List as VList, CellMeasurerCache } from 'react-virtualized'
import ListItem from '../list-item'
import ListItemText from '../list-item-text'
import { withStyles } from '../styles'
import NoRows from './components/no-rows'
import { listStyles } from './styles'


const AUVirtualList = withStyles(listStyles)(class extends React.Component {

    static displayName = 'AUList'

    static propTypes = {
        classes: PropTypes.object.isRequired,
        /**
          * instance of CellMeasurerCache
          */
        deferredMeasurementCache: PropTypes.instanceOf(CellMeasurerCache),
        /**
         * Height constraint for list (determines how many actual rows are rendered)
         */
        height: PropTypes.number,
        /**
         * An array of items to be rendered in the list
         */
        items: PropTypes.oneOfType([
            PropTypes.arrayOf(PropTypes.object),
            PropTypes.arrayOf(PropTypes.string)
        ]),
        /**
         * Callback used to render placeholder content when rowCount is 0
         */
        noRowsRenderer: PropTypes.func,
        /**
         * Either a fixed row height (number) or a function that returns the
         * height of a row given its index: ({ index: number }): number
         */
        rowHeight: PropTypes.oneOfType([
            PropTypes.func,
            PropTypes.number
        ]),
        /**
         * Function that returns a React element for a given row
         *
         * @param {object} The row data
         * @return {element} The Row to be renderered
         */
        rowRenderer: PropTypes.func,
        /**
         * The list width
         */
        width: PropTypes.number
    }

    static defaultProps = {
        items: [],
        noRowsRenderer: () => <NoRows />,
        rowHeight: () => 32,
        rowRenderer: ({ isScrolling, isVisible, row }) => {

            return (
                <ListItem component="div">
                    <ListItemText className={this.props.classes.listItemText} primary={row.name} />
                </ListItem>
            )
        }
    }

    vlistRef = React.createRef()
    renderRow = ({ index, isScrolling, isVisible, key, style, ...rest }) => {

        return (
            <div className={this.props.classes.row} key={key} style={style}>
                {this.props.rowRenderer({
                    index,
                    isScrolling,
                    isVisible,
                    row: this.props.items[index],
                    ...rest
                })}
            </div>
        )
    }

    refreshList = () => {
        this.vlistRef.current.recomputeRowHeights()
    }

    render() {

        const { props } = this

        const { className, getRowHeight, items, rowRenderer, ...rest } = props

        const isFixedHeight = isFinite(props.height)
        const isFixedWidth = isFinite(props.width)
        return (
            <AutoSizer disableHeight={isFixedHeight} disableWidth={isFixedWidth}>
                {({ width, height }) => {

                    return (
                        <VList
                            {...rest}
                            ref={this.vlistRef}
                            className={classnames('au-virtual-list', className)}
                            height={isFixedHeight ? props.height : height}
                            rowCount={items.length}
                            rowRenderer={this.renderRow}
                            width={isFixedWidth ? props.width : width}
                        />
                    )
                }}
            </AutoSizer>
        )
    }
})

export default AUVirtualList
