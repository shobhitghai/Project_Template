/* eslint-disable */

import { number, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import list from '../../stories/fixtures/list'
import { scrollToIndex } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import ListItem from '../list-item'
import ListItemText from '../list-item-text'
import VirtualList from './virtual-list'


const items = list(10000).map((name, index) => ({
    height: index % 5 === 0 ? 240 : 32,
    name
}))

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Virtual List'
}

export const Basic = () => (
    <div style={{ height: 400 }}>
        <VirtualList {...{
            items,
            rowHeight: ({ index }) => items[index].height,
            rowRenderer: ({ row }) => {

                const backgroundColor = row.height !== 32
                    ? '#fff'
                    : 'transparent'

                return (
                    <ListItem component="div" style={{
                        backgroundColor,
                        height: row.height
                    }}>
                        <ListItemText primary={row.name} />
                    </ListItem>
                )
            },
            scrollToIndex: scrollToIndex()
        }} />
    </div>
)
