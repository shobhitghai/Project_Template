import { configure, mount } from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import toJson from 'enzyme-to-json'
import PropTypes from 'prop-types'
import React from 'react'
import list from '../../stories/fixtures/list'
import VirtualList from './virtual-list'


configure({ adapter: new Adapter() })

const items = list(10000).map((name, index) => ({
    height: index % 5 === 0 ? 240 : 32,
    name
}))

const RowRenderer = ({ row }) => {

    return (
        <div>{row.name}</div>
    )
}

RowRenderer.propTypes = {
    row: PropTypes.object
}

describe('<VirtualList />', () => {

    let component

    beforeEach(() => {

        component = mount(
            <VirtualList {...{
                items,
                rowHeight: ({ index }) => items[index].height,
                rowRenderer: RowRenderer,
                scrollToIndex: 0
            }} />
        )
    })

    it('should render correctly', () => {
        expect(toJson(component)).toMatchSnapshot()
    })
})
