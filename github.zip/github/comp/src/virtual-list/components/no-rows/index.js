import PropTypes from 'prop-types'
import React from 'react'
import { withStyles } from '../../../styles'
import Typography from '../../../typography'
import styles from './styles'


const NoRows = ({ classes }) => {
    return (
        <div className={classes.root}>
            <Typography>No rows</Typography>
        </div>
    )
}

NoRows.displayName = 'NoRows'

NoRows.propTypes = {
    classes: PropTypes.shape({
        root: PropTypes.string.isRequired
    }).isRequired
}

export default withStyles(styles)(NoRows)
