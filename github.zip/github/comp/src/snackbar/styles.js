/* eslint-disable */
export const snackbarStyles = theme => {
    return {
        root: {
            left: 'auto',
            maxWidth: theme.spacing(40),
            right: 'auto'
        },
        anchorOriginTopCenter: {
            top: theme.spacing(2)
        },
        anchorOriginBottomCenter: {
            bottom: theme.spacing(2)
        },
        anchorOriginTopRight: {
            right: theme.spacing(2),
            top: theme.spacing(2)
        },
        anchorOriginBottomRight: {
            bottom: theme.spacing(2),
            right: theme.spacing(2)
        },
        anchorOriginTopLeft: {
            left: theme.spacing(2),
            right: 'auto',
            top: theme.spacing(2)
        },
        anchorOriginBottomLeft: {
            bottom: theme.spacing(2),
            left: theme.spacing(2),
            right: 'auto'
        }
    }
}
