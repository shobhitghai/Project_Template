/* eslint-disable */
import CloseIcon from '@material-ui/icons/Close'
import { number, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import jss from 'jss'
import preset from 'jss-preset-default'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { anchorOriginHorizontal, anchorOriginVertical } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Button from '../button'
import IconButton from '../icon-button'
import Typography from '../typography'
import Snackbar from './snackbar'


jss.setup(preset())

const styles = {
    wrapper: {
        alignItems: 'center',
        display: 'flex',
        height: 400,
        justifyContent: 'center',
        width: '100%'
    }
}

const { classes } = jss.createStyleSheet(styles).attach()

class SimpleSnackbar extends React.Component {
    state = {
        open: false
    }

    onClick = () => {
        this.setState({ open: true })
    }

    onClose = (event, reason) => {
        if (reason !== 'clickaway') {
            this.setState({ open: false })
        }
    }

    render() {
        return (
            <div {...{
                className: classes.wrapper
            }}>
                <Button {...{
                    children: 'Open snackbar',
                    onClick: this.onClick
                }}/>

                <Snackbar {...{
                    action:
                        <IconButton {...{
                            'aria-label': 'Close',
                            key: 'close',
                            onClick: this.onClose
                        }}>
                            <CloseIcon />
                        </IconButton>,
                    anchorOrigin: {
                        horizontal: anchorOriginHorizontal(),
                        vertical: anchorOriginVertical()
                    },
                    ContentProps: {
                        'aria-describedby': 'message-id'
                    },
                    message: (
                        <span>
                            <Typography {...{
                                color: 'primary',
                                gutterBottom: true,
                                variant: 'h4'
                            }}>
                                Snackbar Header
                            </Typography>
                            Lorem ipsum dolor sit amet, qui te detraxit iracundia conceptam, vim cu omnium offendit. Exerci labore scripserit his eu, partem prodesset neglegentur in quo, solum iracundia et vel. Te sea quot vide lorem, no per nihil theophrastus, cu sed agam veritus. Vim eu amet nisl perpetua, nec solet tantas temporibus cu.
                        </span>
                    ),
                    onClose: this.onClose,
                    open: this.state.open
                }} />
            </div>
        )
    }
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Snackbar'
}

export const Basic = () => <SimpleSnackbar />
