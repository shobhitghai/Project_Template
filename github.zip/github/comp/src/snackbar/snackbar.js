import { Snackbar } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import SnackbarContent from '../snackbar-content'
import { snackbarStyles } from './styles'


const AUSnackbar = withTelemetry(withStyles(snackbarStyles)(class extends React.Component {

    static displayName = 'AUSnackbar'

    static propTypes = Snackbar.proptypes

    render() {

        const { props } = this

        return (
            <Snackbar {...{
                ...props,
                children:
                    <SnackbarContent {...{
                        action: props.action,
                        message: props.message
                    }} />,
                className: classnames('au-snackbar', props.className)
            }} />
        )
    }
}))

export default AUSnackbar
