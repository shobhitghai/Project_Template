/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { open } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Button from '../button'
import MenuItem from '../menu-item'
import Menu from './menu'


const options = [
    'Option 1',
    'Option 2',
    'Option 3',
    'Option 4',
    'Option 5'
]

class MenuWithButton extends React.Component {

    state = {
        anchorEl: null,
        selectedIndex: null
    }

    handleClickButton = event => {
        this.setState({ anchorEl: event.currentTarget })
    }

    handleMenuItemClick = (event, index) => {
        this.setState({
            anchorEl: null,
            selectedIndex: index
        })
    }

    handleClose = () => {
        this.setState({ anchorEl: null })
    }

    render() {

        const { anchorEl, selectedIndex } = this.state

        return (
            <div>
                <Button {...{
                    onClick: this.handleClickButton
                }}>
                    Open the menu and select one of the options
                </Button>

                <Menu {...{
                    anchorEl: anchorEl,
                    onClose: this.handleClose,
                    open: Boolean(anchorEl)
                }}>
                    {options.map((option, index) => (
                        <MenuItem {...{
                            key: option,
                            onClick: event => this.handleMenuItemClick(event, index),
                            selected: index === selectedIndex
                        }}>
                            {option}
                        </MenuItem>
                    ))}
                </Menu>
            </div>
        )
    }
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Menu'
}

export const Basic = () => (
    <Menu {...{
        open: open()
    }}>
        <MenuItem>Option 1</MenuItem>
        <MenuItem>Option 2</MenuItem>
        <MenuItem>Option 3</MenuItem>
        <MenuItem>Option 4</MenuItem>
        <MenuItem>Option 5</MenuItem>
    </Menu>
)

export const WithButton = () => <MenuWithButton />
