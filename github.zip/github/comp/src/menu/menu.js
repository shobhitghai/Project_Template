import { Menu } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withTelemetry } from '../telemetry'
import menuListProps from '../menu-list/menu-list-props'


export default withTelemetry(class extends React.Component {

    static displayName = 'AUMenu'

    static propTypes = Menu.propTypes

    render() {
        const { props } = this

        return (
            <Menu {...{
                ...props,
                className: classnames('au-menu', props.className).propTypes,
                ...menuListProps
            }} />
        )
    }
})
