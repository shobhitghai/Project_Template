import React from 'react'
import getOr from 'lodash/fp/getOr'
import PropTypes from 'prop-types'
import { DragDropContext, Droppable } from 'react-beautiful-dnd'
import AddIcon from '@material-ui/icons/AddBox'
import classnames from 'classnames'
import IconButton from '../icon-button'
import MenuItem from '../menu-item'
import Select from '../select'
import Tabs from '../tabs'
import Tab from '../tab'
import { withStyles } from '../styles'
import DraggableComponent from './draggable'
import TabLabel from './tab-label'
import styles from './styles'


const defaultTabTitle = 'Drag to re-arrange drill downs Double click to edit name'

const renderEmpty = () => ''

const EnhancedTabs = withStyles(styles)(class extends React.Component {

    static displayName = 'EnhancedTabs'

    static propTypes = {
        classes: PropTypes.object,
        className: PropTypes.string,
        label: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.node
        ]),
        onAddTab: PropTypes.func.isRequired,
        onChange: PropTypes.func.isRequired,
        onDragEnd: PropTypes.func.isRequired,
        onTabDelete: PropTypes.func.isRequired,
        onTabRename: PropTypes.func.isRequired,
        tabs: PropTypes.arrayOf(
            PropTypes.shape({
                label: PropTypes.string.isRequired,
                options: PropTypes.arrayOf(
                    PropTypes.shape({
                        action: PropTypes.func.isRequired,
                        label: PropTypes.string.isRequired
                    })
                ),
                value: PropTypes.string.isRequired
            })
        )
    }

    static defaultProps = {
        label: 'Add',
        tabs: []
    }

    constructor(props) {
        super(props)

        this.state = {
            activeTab: ''
        }

    }

    componentDidMount() {
        this.setState({
            activeTab: getOr('', 'tabs[0].value', this.props)
        })
    }

    labelComponent = (index, label, options) => {
        return <TabLabel
            onDelete={this.onTabDelete(index)}
            onRename={this.onTabRename(index)}
            label={label}
            options={options}
        />
    }

    tabs = () => {
        return this.props.tabs.map(tab =>
            <MenuItem
                classes={{selected: this.props.classes.selectedItem}}
                divider
                key={tab.value}
                value={tab.value}
            >
                {tab.label}
            </MenuItem>
        )
    }

    onDragEnd = result => {
        const { source, destination } = result

        if (source.index !== destination.index) {
            const { tabs } = this.props
            const newTabs = tabs.slice(0)

            newTabs[source.index] = newTabs.splice(destination.index, 1, newTabs[source.index])[0]
            this.props.onDragEnd(newTabs)
        }
    }

    onTabDelete = index => () => {
        const { onTabDelete, tabs } = this.props
        const newTabs = tabs.slice(0)

        newTabs.splice(index, 1)

        onTabDelete(newTabs, index)
    }

    onTabRename = index => newName => {
        const { onTabRename, tabs } = this.props
        const newTabs = tabs.slice(0)

        newTabs[index] = {...newTabs[index], label: newName}

        onTabRename(newTabs)
    }

    onSelectedTabChange = event => {
        this.onTabChange(event, event.target.value)
    }

    onTabChange = (e, value) => {
        this.setState({
            activeTab: value
        })
        this.props.onChange(value)
    }

    render() {
        const { classes, label, onDragEnd, onChange, onTabDelete, onTabRename, onAddTab, tabs, ...rest } = this.props
        const { addIcon, enhancedTabs, checkedIcon, dropdownInput, inset, select, selectedItem, ...otherClasses } = classes

        return (
            <DragDropContext onDragEnd={this.onDragEnd}>
                <Droppable droppableId="droppable" direction="horizontal">
                    {provided => (
                        <div className={classnames('au-enhanced-tabs', this.props.classes.enhancedTabs, this.props.className)} ref={provided.innerRef}>
                            <Tabs variant="scrollable" {...rest} classes={otherClasses} onChange={this.onTabChange} >
                                {tabs.map((tab, index) => <Tab
                                    disableFocusRipple={true}
                                    key={index}
                                    {...tab}
                                    id={`id-${index}`}
                                    index={index}
                                    component={DraggableComponent}
                                    label={this.labelComponent(index, tab.label, tab.options)}
                                    title={getOr(defaultTabTitle, 'title')(tab)}
                                />)}
                            </Tabs>
                            <IconButton onClick={this.props.onAddTab} title='Add new tab'>
                                <AddIcon className={this.props.classes.addIcon}/>
                            </IconButton>
                            <Select
                                classes={{select: this.props.classes.select}}
                                className={this.props.classes.dropdownInput}
                                onChange={this.onSelectedTabChange}
                                renderValue={renderEmpty}
                                value={this.state.activeTab}
                            >
                                {this.tabs()}
                            </Select>
                        </div>
                    )}
                </Droppable>
            </DragDropContext>
        )
    }
})

export default EnhancedTabs
