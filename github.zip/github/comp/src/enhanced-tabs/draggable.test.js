import React from 'react'
import { configure, mount } from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import toJson from 'enzyme-to-json'
import { DragDropContext, Droppable } from 'react-beautiful-dnd'
import DraggableComponent from './draggable'


configure({ adapter: new Adapter() })

const props = {
    id: '1',
    index: 0,
    onMouseDown: jest.fn()
}

const onDragEnd = jest.fn()

describe('enhanced-tabs/draggable.js', () => {
    let draggableComponent

    beforeEach(() => {
        props.onMouseDown.mockReset()

        const root = document.createElement('div')
        root.id = 'root'
        document.body.appendChild(root)

        const component = <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="droppable" direction="horizontal">
                {provided => (
                    <div ref={provided.innerRef}>
                        <DraggableComponent {...props} />
                    </div>
                )}
            </Droppable>
        </DragDropContext>
        draggableComponent = mount(component, { attachTo: root })
    })

    it('should render correctly', () => {
        expect(toJson(draggableComponent)).toMatchSnapshot('draggable-component')
    })

    describe('when user mouse downs on the component', () => {
        let elem

        beforeEach(() => {
            elem = draggableComponent.find('Draggable').at(0).find('div').at(0)
        })

        it('should call props.onMouseDown function', () => {
            elem.simulate('mousedown')

            expect(props.onMouseDown).toBeCalled()
        })
    })

})
