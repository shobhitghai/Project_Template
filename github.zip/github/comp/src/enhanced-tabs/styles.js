export default theme => {
    return {
        addIcon: {
            fontSize: theme.spacing(2)
        },
        dropdownInput: {
            '&:after': {
                borderBottom: 'none'
            },
            '&:before': {
                borderBottom: 'none'
            },
            '&:hover:before': {
                borderBottom: 'none !important'
            }
        },
        enhancedTabs: {
            alignItems: 'center',
            display: 'flex',
            width: '100%'
        },
        root: {
            borderBottom: 'none',
            height: theme.spacing(4),
            minHeight: theme.spacing(4)
        },
        select: {
            paddingRight: [ theme.spacing(1), '!important' ]
        }
    }
}
