import { configure, mount } from 'enzyme'
import React from 'react'
import Adapter from 'enzyme-adapter-react-16'
import toJson from 'enzyme-to-json'
import IconButton from '../icon-button'
import Tab from '../tab'
import Tabs from '../tabs'
import EnhancedTabs from './enhanced-tabs'


configure({ adapter: new Adapter() })

// eslint-disable-next-line react/display-name, react/prop-types
jest.mock('../tabs', () => props => <div >{props.children}</div>)
// eslint-disable-next-line react/display-name, react/prop-types
jest.mock('../tab', () => props => <div >{props.children}</div>)
// eslint-disable-next-line react/display-name, react/prop-types
jest.mock('./draggable', () => props => <div >{props.children}</div>)
// eslint-disable-next-line react/display-name, react/prop-types
jest.mock('./tab-label', () => props => <div>{props.children}</div>)


const props = {
    onAddTab: jest.fn(),
    onChange: jest.fn(),
    onDragEnd: jest.fn(),
    onTabDelete: jest.fn(),
    onTabRename: jest.fn(),
    tabs: [
        {label: 'Label A', value: '1'},
        {label: 'Label B', value: '2'}
    ]
}

const mountTab = props => mount(<EnhancedTabs label='Add' {...props} />)

describe('enhanced-tabs/enhanced-tabs.js', () => {
    let wrapper

    it('should render correctly', () => {
        wrapper = mountTab(props)
        expect(toJson(wrapper)).toMatchSnapshot()
    })

    it('should have the first tab with the expected tab value', () => {
        wrapper = mountTab(props).find(Tab).at(0).props()
        expect(wrapper.value).toEqual(props.tabs[0].value)
    })

    describe('when onChange is triggered', () => {
        it('should call props.onAddTab when user clicks on "add tab"', () => {
            wrapper = mountTab(props).find(IconButton).at(0)
            wrapper.simulate('click')
            expect(props.onAddTab).toHaveBeenCalled()
        })

        it('should call props.onChange when user clicks on a tab', () => {
            wrapper = mountTab(props).find(Tabs).at(0)
            wrapper.props().onChange({}, 1)
            expect(props.onChange).toHaveBeenCalledWith(1)
        })
    })

    describe('when "drag ends"', () => {
        afterEach(() => {
            props.onDragEnd.mockReset()
        })

        it('should call props.onDragEnd when source and target are diferent', () => {
            const result = { destination: { index: 1 }, source: { index: 0 } }

            wrapper = mountTab(props).find('DragDropContext').at(0)
            wrapper.props().onDragEnd(result)
            expect(props.onDragEnd).toHaveBeenCalledWith(
                [ {label: 'Label B', value: '2'}, {label: 'Label A', value: '1'} ]
            )
        })

        it('should not call props.onDragEnd when source and target are equal', () => {
            const result = { destination: { index: 1 }, source: { index: 1 } }

            wrapper = mountTab(props).find('DragDropContext').at(0)
            wrapper.props().onDragEnd(result)
            expect(props.onDragEnd).not.toHaveBeenCalled()
        })
    })

    describe('when "on delete" is triggered', () => {
        it('should call props.onTabDelete with the remaining tabs', () => {
            wrapper = mountTab(props).childAt(0).instance()
            wrapper.onTabDelete(0)()
            expect(props.onTabDelete).toHaveBeenCalledWith([ props.tabs[1] ], 0)
        })
    })

    describe('when "on rename" is triggered', () => {
        it('should call props.onTabRename with the new tab label', () => {
            const newLabel = 'new tab label'
            wrapper = mountTab(props).childAt(0).instance()
            wrapper.onTabRename(0)(newLabel)
            expect(props.onTabRename).toHaveBeenCalledWith(
                [ {label: newLabel, value: '1'}, {label: 'Label B', value: '2'} ]
            )
        })
    })
})
