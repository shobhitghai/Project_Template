import React from 'react'
import { configure, mount } from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import toJson from 'enzyme-to-json'
import DrilldownTabLabel from './component'


configure({ adapter: new Adapter() })

const props = {
    deletable: false,
    label: 'test',
    onDelete: jest.fn(),
    onRename: jest.fn()
}

const propsWithOptions = {
    ...props,
    options: [
        { action: jest.fn(), label: 'Clone' }
    ]
}

const propsAdd = {
    add: true
}

const mountTabLabel = props => mount(<DrilldownTabLabel {...{ options: [] }} {...props} />)

describe('components/deletable-tab-label/component.js', () => {
    let drillDownTabLabel

    afterEach(() => {
        props.onDelete.mockReset()
    })

    it('should render correctly', () => {
        drillDownTabLabel = mountTabLabel(props)
        expect(toJson(drillDownTabLabel)).toMatchSnapshot()
        drillDownTabLabel.unmount()
    })

    describe('when deletable is true', () => {
        let elem

        beforeEach(() => {
            props.deletable = true
            drillDownTabLabel = mountTabLabel(props)
        })

        afterEach(() => {
            drillDownTabLabel.unmount()
        })

        it('should render delete icon', () => {
            expect(toJson(drillDownTabLabel)).toMatchSnapshot()
        })

        it('should call props.onDelete when clicked', () => {
            elem = drillDownTabLabel
                .childAt(0)
                .childAt(0)
                .childAt(1)

            elem.simulate('click')
            expect(props.onDelete).toBeCalled()
        })
    })

    describe('when tab has additional options', () => {

        beforeEach(() => {
            propsWithOptions.deletable = true
            drillDownTabLabel = mountTabLabel(propsWithOptions)
        })

        afterEach(() => {
            drillDownTabLabel.unmount()
        })

        it('should render "more options" icon', () => {
            expect(toJson(drillDownTabLabel)).toMatchSnapshot()
        })
    })

    describe('when tab is "Add"', () => {

        beforeEach(() => {
            drillDownTabLabel = mountTabLabel(propsAdd)
        })

        afterEach(() => {
            drillDownTabLabel.unmount()
        })

        it('should render "add" icon', () => {
            expect(toJson(drillDownTabLabel)).toMatchSnapshot()
        })
    })

    describe('edit mode', () => {
        let component
        let labelElement

        beforeEach(() => {
            props.deletable = true
            drillDownTabLabel = mountTabLabel(props)

            component = drillDownTabLabel.childAt(0)
            labelElement = component.childAt(0).childAt(0)

            labelElement.simulate('dblclick')
        })

        afterEach(() => {
            drillDownTabLabel.unmount()
        })

        it('should render the input box on double click', () => {
            expect(toJson(drillDownTabLabel)).toMatchSnapshot()
        })

        it('should set state.isEditingName to true', () => {
            expect(component.instance().state.isEditingName).toBe(true)
        })

        it('should set state.labelValue to props.label', () => {
            expect(component.instance().state.labelValue).toBe(props.label)
        })

        describe('input events', () => {
            let input

            beforeEach(() => {
                input = drillDownTabLabel.find('input').at(0)
            })

            afterEach(() => {
                input.value = props.label
            })

            it('should set state.labelValue to new value when change event happens', () => {
                input.value = 'newValue'
                input.simulate('change', { target: input })
                expect(component.instance().state.labelValue).toBe('newValue')
            })

            it('should revert the changed value on Escape', () => {
                input.value = 'newValue'
                input.simulate('change', { target: input })
                expect(component.instance().state.labelValue).toBe('newValue')

                input.simulate('keydown', { key: 'Escape' })
                expect(component.instance().state.labelValue).toBe(props.label)
            })

            it('should update the value on Enter and reset the state', () => {
                input.value = 'newValue'
                input.simulate('change', { target: input })
                input.simulate('keydown', { key: 'Enter' })

                expect(props.onRename).toBeCalledWith('newValue')

                expect(component.instance().state.isEditingName).toBe(false)
                expect(component.instance().state.labelValue).toBe('')
            })

            it('should trim the value on Enter', () => {
                input.value = '  newValue     '
                input.simulate('change', { target: input })
                input.simulate('keydown', { key: 'Enter' })

                expect(props.onRename).toBeCalledWith('newValue')
            })
        })

    })
})
