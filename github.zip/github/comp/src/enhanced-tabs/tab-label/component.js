import classnames from 'classnames'
import React from 'react'
import PropTypes from 'prop-types'
import DeleteForeverIcon from '@material-ui/icons/Close'
import MoreVertIcon from '@material-ui/icons/MoreVert'
import map from 'lodash/fp/map'
import memoize from 'lodash/fp/memoize'
import { withStyles } from '../../styles'
import FormControl from '../../form-control'
import Input from '../../input'
import Menu from '../../menu'
import MenuItem from '../../menu-item'
import styles from './styles'


const DELETE_LABEL = 'Delete'

export default withStyles(styles)(class extends React.Component {
    static displayName = 'TabLabel'

    static propTypes = {
        add: PropTypes.bool,
        classes: PropTypes.object,
        deletable: PropTypes.bool,
        label: PropTypes.string,
        onDelete: PropTypes.func,
        onRename: PropTypes.func,
        options: PropTypes.arrayOf(
            PropTypes.shape({
                action: PropTypes.func.isRequired,
                label: PropTypes.string.isRequired
            })
        )
    }

    static defaultProps = {
        deletable: true,
        onDelete: () => {},
        onRename: () => {},
        options: []
    }

    state = {
        anchorEl: null,
        isEditingName: false,
        labelValue: ''
    }

    clickHandler = event => {
        event.stopPropagation()
        this.props.onDelete()
    }

    doubleClickHandler = event => {
        this.setState({
            isEditingName: true,
            labelValue: this.props.label
        })
    }

    labelChangeHandler = event => {
        this.setState({ labelValue: event.target.value })
    }

    updateLabel = () => {
        this.props.onRename(this.state.labelValue.trim())
        this.setState({
            isEditingName: false,
            labelValue: ''
        })
    }

    handleKeyDown = event => {
        if (event.key === 'Enter') {
            this.updateLabel()
        } else if (event.key === 'Escape') {
            event.preventDefault() // To prevent dialog from closing
            this.setState({
                isEditingName: false,
                labelValue: this.props.label
            })
        }
    }

    onAction = memoize(action => e => {

        e.stopPropagation()
        action()

        this.setState({ anchorEl: null })
    })

    onHideMenu = e => {

        e.stopPropagation()
        this.setState({ anchorEl: null })
    }

    onShowMenu = e => {

        e.stopPropagation()
        this.setState({ anchorEl: e.currentTarget })
    }

    onInputClick = e => {
        e.stopPropagation()
    }

    render() {
        const { classes, label, deletable } = this.props
        const { isEditingName, labelValue } = this.state

        const options = [ ...this.props.options ]

        if (deletable) {
            options.unshift({ action: this.props.onDelete, label: DELETE_LABEL })
        }

        const deleteOnly = options.length === 1 && options[0].label === DELETE_LABEL
        const otherOptions = options.filter(o => o.label !== DELETE_LABEL).length > 0

        return (
            <span className={classes.deletableTabLabel}>
                { isEditingName
                    ? (
                        <FormControl fullWidth={true} required={true}>
                            <Input
                                defaultValue={labelValue}
                                disableUnderline={true}
                                autoFocus={true}
                                inputProps={{ size: labelValue.length }}
                                onChange={this.labelChangeHandler}
                                onClick={this.onInputClick}
                                onBlur={this.updateLabel}
                                onKeyDown={this.handleKeyDown}
                            />
                        </FormControl>
                    )

                    : (
                        <React.Fragment>
                            <span
                                className={classes.label}
                                onDoubleClick={this.doubleClickHandler}
                            >
                                {label}
                            </span>
                            {deleteOnly && (
                                <span
                                    className={classnames('delete-icon-wrapper', classes.deleteIconWrapper)}
                                    onClick={this.clickHandler}
                                    title={`Remove ${label}`}
                                >
                                    <DeleteForeverIcon
                                        className={classes.deleteIcon}
                                        fontSize="inherit"
                                    />
                                </span>
                            )}
                            {otherOptions && (
                                <React.Fragment>
                                    <span
                                        className={classnames('options-icon-wrapper', classes.optionsIconWrapper)}
                                        onClick={this.onShowMenu}
                                        title="Options"
                                    >
                                        <MoreVertIcon
                                            className={classes.optionsIcon}
                                            fontSize="inherit"
                                        />
                                    </span>
                                    <Menu
                                        anchorEl={this.state.anchorEl}
                                        open={!!this.state.anchorEl}
                                        onClose={this.onHideMenu}
                                        anchorOrigin={{
                                            horizontal: 'left',
                                            vertical: 'top'
                                        }}
                                        transformOrigin={{
                                            horizontal: 'left',
                                            vertical: 'top'
                                        }}
                                    >
                                        {map(({ action, label }) => {

                                            return (
                                                <MenuItem key={label} onClick={this.onAction(action)}>
                                                    {label}
                                                </MenuItem>
                                            )

                                        }, options)}
                                    </Menu>
                                </React.Fragment>
                            )}
                        </React.Fragment>
                    )
                }
            </span>
        )
    }
})
