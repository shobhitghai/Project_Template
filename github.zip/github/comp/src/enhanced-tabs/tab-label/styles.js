export default theme => {
    return {
        deletableTabLabel: {
            '&:hover': {
                '& .delete-icon-wrapper': {
                    opacity: 1
                },
                '& .options-icon-wrapper': {
                    opacity: 1
                }
            },
            alignItems: 'center',
            display: 'flex',
            padding: '0 !important'
        },
        deleteIconWrapper: {
            cursor: 'pointer',
            display: 'flex',
            fontSize: theme.spacing(2),
            marginLeft: 6,
            opacity: 0
        },
        label: {
            flex: '1',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap'
        },
        optionsIcon: {
            '&:hover': {
                color: theme.palette.primary.main
            }
        },
        optionsIconWrapper: {
            cursor: 'pointer',
            display: 'flex',
            fontSize: theme.spacing(2),
            marginLeft: 6,
            opacity: 0
        }
    }
}
