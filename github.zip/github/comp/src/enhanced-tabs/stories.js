/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import classnames from 'classnames'
import jss from 'jss'
import preset from 'jss-preset-default'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { anchor, elevation } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Tab from '../tab'
import Typography from '../typography'
import Tabs from './enhanced-tabs'


jss.setup(preset())

class Component extends React.Component {
            
    state= {
        current: '1',
        tabs: [{ label: 'Tab Looooooooooooooooooooooooooooong Title', options: [ { action: () => {}, label: 'Custom Action' } ], value: '1' }, { label: 'Tab B', value: '2' }]
    }

    onDragEnd = tabs => {
        this.setState({tabs})
    }

    onTabRename = tabs => {
        this.setState({tabs})
    }

    onTabDelete = tabs => {
        this.setState({tabs})
    }

    onAddTab = () => {
        const { tabs } = this.state

        this.setState({
            tabs: tabs.concat([{
                value: tabs[tabs.length - 1].value + 1,
                label: 'New Tab'
            }])
        })
    }

    onChange = value => {
        this.setState({current: value})
    }

    render() {
        const { tabs, current } = this.state
        
        return (
            <React.Fragment>
                <Tabs
                    value={current}
                    variant="scrollable"
                    onDragEnd={this.onDragEnd}
                    onAddTab={this.onAddTab}
                    onChange={this.onChange}
                    onTabRename={this.onTabRename}
                    onTabDelete={this.onTabDelete}
                    tabs={tabs}
                />
                {current === 1 && <Typography>Item A</Typography>}
                {current === 2 && <Typography>Item B</Typography>}
            </React.Fragment>
        )
    }
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Enhanced Tabs'
}

export const Basic = () => <Component/>
