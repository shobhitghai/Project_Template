export { default } from './enhanced-tabs'
