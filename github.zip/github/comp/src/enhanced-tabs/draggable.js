import React from 'react'
import PropTypes from 'prop-types'
import { Draggable } from 'react-beautiful-dnd'
import noop from 'lodash/noop'


const getItemStyle = (isDragging, draggableStyle) => ({
    // styles we need to apply on draggables
    ...draggableStyle
})

const DraggableComponent = class extends React.Component {
    static displayName = 'DraggableComponent'

    static propTypes = {
        children: PropTypes.oneOfType([
            PropTypes.arrayOf(PropTypes.node),
            PropTypes.node
        ]),
        id: PropTypes.string.isRequired,
        index: PropTypes.number.isRequired,
        onMouseDown: PropTypes.func
    }

    static defaultProps = {
        onMouseDown: noop
    }

    render() {
        const { id, index, children, onMouseDown, ...otherProps } = this.props

        return (
            <Draggable draggableId={id} index={index}>
                {(provided, snapshot) => {

                    return (
                        <div
                            ref={provided.innerRef }
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            style={getItemStyle(
                                snapshot.isDragging,
                                provided.draggableProps.style
                            )}
                            onMouseDown={this.props.onMouseDown}
                            {...otherProps}
                        >
                            { children }
                        </div>
                    )
                }}
            </Draggable>
        )
    }
}

export default DraggableComponent
