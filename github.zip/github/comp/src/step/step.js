import { Step } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'


const AUStep = class extends React.Component {

    static displayName = 'AUStep'

    render() {

        const { props } = this

        return (
            <Step {...{
                ...props,
                className: classnames('au-step', props.className)
            }} />
        )
    }
}

export default AUStep
