import { Checkbox } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import CheckboxCheckedIcon from './checkbox-checked-icon'
import CheckboxUncheckedIcon from './checkbox-unchecked-icon'
import IndeterminateCheckBox from './indeterminate-checkbox'
import { checkboxStyles } from './styles'


const iconNode = <CheckboxUncheckedIcon />
const checkedIconNode = <CheckboxCheckedIcon />
const indeterminateIconNode = <IndeterminateCheckBox />

const nonOverwritable = (props, propName) => {
    if (Object.keys(props).includes(propName)) {
        return new Error(`You cannot override "${propName}" property`)
    }
}

const AUCheckbox = withTelemetry(withStyles(checkboxStyles)(class extends React.Component {

    static displayName = 'AUCheckbox'

    static defaultProps = {
        color: 'primary'
    }

    static propTypes = {
        ...Checkbox.propTypes,
        /**
         * @ignore
         */
        checkedIcon: nonOverwritable,
        /**
         * @ignore
         */
        icon: nonOverwritable,
        /**
         * @ignore
         */
        indeterminateIcon: nonOverwritable
    }

    render() {

        const { props } = this

        return (
            <Checkbox
                {... {
                    ...props,
                    checkedIcon: checkedIconNode,
                    className: classnames('au-checkbox', props.className),
                    disableRipple: true,
                    icon: iconNode,
                    indeterminateIcon: indeterminateIconNode
                }}
            />
        )
    }
}))

export default AUCheckbox
