/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { checked, disabled, indeterminate } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Checkbox from './checkbox'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Checkbox'
}

export const Basic = () => (
    <Checkbox {...{
        checked: checked(),
        checkedIcon: {},
        disabled: disabled(),
        indeterminate: indeterminate()
    }} />
)
