import CheckBox from '@material-ui/icons/CheckBox'
import classnames from 'classnames'
import PropTypes from 'prop-types'
import React from 'react'
import { withStyles } from '../styles/'
import { checkBoxIconStyles } from './styles'


const AUCheckBoxOutlineChecked = withStyles(checkBoxIconStyles)(class extends React.Component {

    static displayName = 'AUCheckBoxOutlineChecked'

    static propTypes = {
        className: PropTypes.string
    }

    render() {

        const { props } = this

        return (
            <CheckBox {... {
                ...props,
                className: classnames('au-checkbox-outline-checked', props.className)
            }} />
        )
    }
})

export default AUCheckBoxOutlineChecked
