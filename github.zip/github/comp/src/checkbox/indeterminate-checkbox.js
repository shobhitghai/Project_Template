import IndeterminateCheckBox from '@material-ui/icons/IndeterminateCheckBox'
import classnames from 'classnames'
import PropTypes from 'prop-types'
import React from 'react'
import { withStyles } from '../styles/'
import { checkBoxIconStyles } from './styles'


const AUIndeterminateCheckBox = withStyles(checkBoxIconStyles)(class extends React.Component {

    static displayName = 'AUIndeterminateCheckBox'

    static propTypes = {
        className: PropTypes.string
    }

    render() {

        const { props } = this

        return (
            <IndeterminateCheckBox {... {
                ...props,
                className: classnames('au-indeterminate-checkbox', props.className)
            }} />
        )
    }
})

export default AUIndeterminateCheckBox
