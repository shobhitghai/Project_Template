/* eslint-disable */
export const checkboxStyles = theme => {
    return {
        root: {
            height: theme.spacing(2),
            width: theme.spacing(2),

            '&:hover': {
                background: 'none !important'
            }
        }
    }
}

export const checkBoxIconStyles = theme => {
    return {
        root: {
            fontSize: theme.typography.body2.fontSize
        }
    }
}
