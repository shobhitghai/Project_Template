import CheckBoxOutlineBlank from '@material-ui/icons/CheckBoxOutlineBlank'
import classnames from 'classnames'
import PropTypes from 'prop-types'
import React from 'react'
import { withStyles } from '../styles/'
import { checkBoxIconStyles } from './styles'


const AUCheckBoxOutlineBlank = withStyles(checkBoxIconStyles)(class extends React.Component {

    static displayName = 'AUCheckBoxOutlineBlank'

    static propTypes = {
        className: PropTypes.string
    }

    render() {

        const { props } = this

        return (
            <CheckBoxOutlineBlank {... {
                ...props,
                className: classnames('au-checkbox-outline-blank', props.className)
            }} />
        )
    }
})

export default AUCheckBoxOutlineBlank
