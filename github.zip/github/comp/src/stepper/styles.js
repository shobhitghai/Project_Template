/* eslint-disable */
export const stepperStyles = theme => {
    return {
        root: {
            padding: `${theme.spacing(1)}px ${theme.spacing(2)}px`
        },
        alternativeLabel: {
            '& span.au-typography': {
                textAlign: 'center'
            }
        }
    }
}
