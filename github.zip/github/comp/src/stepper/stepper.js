import { Stepper } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import StepConnector from '../step-connector'
import { stepperStyles } from './styles'


const AUStepper = withTelemetry(withStyles(stepperStyles)(class extends React.Component {

    static displayName = 'AUStepper'

    static defaultProps = {
        ...Stepper.defaultProps,
        connector: <StepConnector />
    }

    render() {

        const { props } = this

        return (
            <Stepper {...{
                ...props,
                className: classnames('au-stepper', props.className)
            }} />
        )
    }
}))

export default AUStepper
