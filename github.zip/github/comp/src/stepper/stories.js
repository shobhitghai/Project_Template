/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import jss from 'jss'
import preset from 'jss-preset-default'
import fp from 'lodash/fp'
import React, { Fragment } from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { alternativeLabel } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Button from '../button'
import Step from '../step'
import StepButton from '../step-button'
import StepLabel from '../step-label'
import Typography from '../typography'
import Stepper from './stepper'


jss.setup(preset())

const styles = {
    alreadyCompletedText: {
        marginLeft: 8
    },
    button: {
        '&+ .au-button': {
            marginLeft: 8
        }
    },
    buttonWrapper: {
        alignItems: 'center',
        display: 'flex'
    },
    wrapper: {
        padding: 16
    }
}

const { classes } = jss.createStyleSheet(styles).attach()

const map3 = fp.map.convert({ 'cap': false })

function getSteps() {
    return ['Step 1', 'Step 2', 'Step 3', 'Step 4']
}

function getStepContent(step) {
    return `You're currently at step ${step + 1}`
}

class HorizontalLinearStepper extends React.Component {
    state = {
        activeStep: 0,
        skipped: new Set()
    }

    isStepOptional = step => {
        return step === 1
    }

    isStepFailed = step => {
        return step === 2
    }

    onNext = () => {
        const { activeStep } = this.state
        let { skipped } = this.state

        if (this.isStepSkipped(activeStep)) {
            skipped = new Set(skipped.values())
            skipped.delete(activeStep)
        }

        this.setState({
            activeStep: activeStep + 1,
            skipped
        })
    }

    onBack = () => {
        const { activeStep } = this.state

        this.setState({
            activeStep: activeStep - 1
        })
    }

    onSkip = () => {
        const { activeStep } = this.state

        if (!this.isStepOptional(activeStep)) {
            throw new Error('You can\'t skip a set that isn\'t optional')
        }

        this.setState(state => {
            const skipped = new Set(state.skipped.values())
            skipped.add(activeStep)
            return {
                activeStep: state.activeStep + 1,
                skipped
            }
        })
    }

    onReset = () => {
        this.setState({
            activeStep: 0
        })
    }

    isStepSkipped(step) {
        return this.state.skipped.has(step)
    }

    render() {
        const steps = getSteps()
        const { activeStep } = this.state

        return (
            <Fragment>
                <Stepper {...{
                    activeStep,
                    alternativeLabel: alternativeLabel()
                }}>
                    {map3((label, index) => {
                        const props = {}
                        const labelProps = {}

                        if (this.isStepOptional(index)) {
                            labelProps.optional
                                = <Typography {...{
                                    variant: 'caption'
                                }}>
                                    Optional
                                </Typography>
                        }

                        if (this.isStepFailed(index)) {
                            labelProps.error = true
                        }

                        if (this.isStepSkipped(index)) {
                            props.completed = false
                        }

                        return (
                            <Step {...{
                                ...props,
                                key: label
                            }}>
                                <StepLabel {...{
                                    ...labelProps
                                }}>
                                    {label}
                                </StepLabel>
                            </Step>
                        )
                    }, steps)

                    }
                </Stepper>

                <div {...{
                    className: classes.wrapper
                }}>
                    {activeStep === steps.length ? (
                        <Fragment>
                            <Typography {...{
                                gutterBottom: true
                            }}>
                                All steps completed
                            </Typography>
                            <Button {...{
                                className: classes.button,
                                onClick: this.onReset
                            }}>
                                Reset
                            </Button>
                        </Fragment>
                    ) : (
                        <Fragment>
                            <Typography {...{
                                gutterBottom: true
                            }}>
                                {getStepContent(activeStep)}
                            </Typography>
                            <div>
                                <Button {...{
                                    className: classes.button,
                                    disabled: activeStep === 0,
                                    onClick: this.onBack,
                                    variant: 'text'
                                }}>
                                    Back
                                </Button>
                                {this.isStepOptional(activeStep)
                                    && (<Button {...{
                                        className: classes.button,
                                        onClick: this.onSkip
                                    }}>
                                        Skip
                                    </Button>
                                )}
                                <Button {...{
                                    className: classes.button,
                                    onClick: this.onNext
                                }}>
                                    {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
                                </Button>
                            </div>
                        </Fragment>
                    )}
                </div>
            </Fragment>
        )
    }
}

class HorizontalNonLinearStepper extends React.Component {
    state = {
        activeStep: 0,
        completed: {}
    }

    completedSteps() {
        return Object.keys(this.state.completed).length
    }

    totalSteps = () => {
        return getSteps().length
    }
    
    allStepsCompleted() {
        return this.completedSteps() === this.totalSteps()
    }
    
    isLastStep() {
        return this.state.activeStep === this.totalSteps() - 1
    }

    onNext = () => {
        let activeStep

        if (this.isLastStep() && !this.allStepsCompleted()) {
            const steps = getSteps()
            activeStep = steps.findIndex((step, i) => !(i in this.state.completed))
        } else {
            activeStep = this.state.activeStep + 1
        }

        this.setState({
            activeStep
        })
    }

    onBack = () => {
        const { activeStep } = this.state
        this.setState({
            activeStep: activeStep - 1
        })
    }

    onStep = step => () => {
        this.setState({
            activeStep: step
        })
    }

    onComplete = () => {
        const { completed } = this.state
        completed[this.state.activeStep] = true
        this.setState({
            completed
        })
        this.onNext()
    }
    
    onReset = () => {
        this.setState({
            activeStep: 0,
            completed: {}
        })
    }

    render() {
        const steps = getSteps()
        const { activeStep } = this.state

        return (
            <Fragment>
                <Stepper {...{
                    activeStep,
                    alternativeLabel: alternativeLabel(),
                    nonLinear: true
                }}>
                    {map3((label, index) => {
                        return (
                            <Step {...{
                                key: label
                            }}>
                                <StepButton {...{
                                    completed: this.state.completed[index],
                                    onClick: this.onStep(index)
                                }}>
                                    {label}
                                </StepButton>
                            </Step>
                        )
                    }, steps)}

                </Stepper>

                <div {...{
                    className: classes.wrapper
                }}>
                    <Typography {...{
                        gutterBottom: true
                    }}>
                        {getStepContent(activeStep)}
                    </Typography>

                    <div {...{
                        className: classes.buttonWrapper
                    }}>
                        <Button {...{
                            className: classes.button,
                            disabled: activeStep === 0,
                            onClick: this.onBack,
                            variant: 'text'
                        }}>
                            Back
                        </Button>
                        <Button {...{
                            className: classes.button,
                            onClick: this.onNext
                        }}>
                            Next
                        </Button>

                        {activeStep !== steps.length
                            && (this.state.completed[this.state.activeStep] ? (
                                <Typography {...{
                                    className: classes.alreadyCompletedText,
                                    variant: 'caption'
                                }}>
                                    Step {activeStep + 1} already completed
                                </Typography>
                            ): (
                                <Button {...{
                                    onClick: this.onComplete
                                }}>
                                    {this.completedSteps() === this.totalSteps() - 1 ? 'Finish' : 'Complete Step'}
                                </Button>
                            ))
                        }
                    </div>
                </div>
            </Fragment>
        )
    }
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Stepper'
}

export const HorizontalLinear = () => <HorizontalLinearStepper />

export const HorizontalNonLinear = () => <HorizontalNonLinearStepper />
