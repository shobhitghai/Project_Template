import AccountCircle from '@material-ui/icons/AccountCircle'
import map from 'lodash/fp/map'
import PropTypes from 'prop-types'
import React from 'react'
import InputAdornment from '../../../input-adornment'
import Root from '../../../root'
import TextField from '../../../text-field'
import { withStyles } from '../../../styles'
import styles from './styles'


const map3 = map.convert({ cap: false })

const baseProps = {
    disabled: false,
    error: false,
    helperText: '',
    label: '',
    margin: 'none',
    placeholder: ''
}

const VARIANTS = map(variant => ({ ...baseProps, ...variant }), [

    { value: 'Default' },
    { disabled: true, value: 'Disabled' },
    { error: true, value: 'Error' },
    { placeholder: 'Placeholder' },
    { helperText: 'Helper text', label: 'Label', value: 'TextField' },
    { label: 'Label' },
    {
        InputLabelProps: {
            shrink: true
        },
        InputProps: {
            startAdornment: <InputAdornment position="start">$</InputAdornment>
        },
        label: 'Start adornment'
    },
    {
        InputLabelProps: {
            shrink: true
        },
        InputProps: {
            endAdornment: <InputAdornment position="end"><AccountCircle /></InputAdornment>
        },
        label: 'End adornment'
    },
    { label: 'Multiline', multiline: true, rows: 4 },
    { label: 'Expnding multiline', multiline: true, rowsMax: 4 }
])

export default withStyles(styles)(class extends React.Component {

    static displayName = 'TextFieldGrid'

    static propTypes = {
        classes: PropTypes.shape({
            cell: PropTypes.string.isRequired,
            container: PropTypes.string.isRequired
        }).isRequired
    }

    render() {

        const classes = this.props.classes

        return (
            <Root>
                <div className={classes.container}>
                    {map3((props, index) => (
                        <div className={classes.cell} key={index}>
                            <TextField { ...props } />
                        </div>
                    ), VARIANTS)}
                </div>
            </Root>
        )
    }
})
