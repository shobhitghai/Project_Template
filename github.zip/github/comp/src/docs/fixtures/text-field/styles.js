/* eslint-disable */

export default theme => {

    return {

        container: {
            display: 'flex',
            flexWrap: 'wrap'
        },

        cell: {
            flex: `0 1 ${theme.spacing(20)}px`,
            margin: theme.spacing(1)
        }
    }
}
