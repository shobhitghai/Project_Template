import map from 'lodash/fp/map'
import PropTypes from 'prop-types'
import React from 'react'
import Root from '../../../root'
import Typography from '../../../typography'
import { withStyles } from '../../../styles'
import styles from '../styles'


const VARIANTS = [
    'h5',
    'h1',
    'h2',
    'h3',
    'h4',
    'h6',
    'subtitle1',
    'body1',
    'body2',
    'caption'
]

export default withStyles(styles)(class extends React.Component {

    static displayName = 'TypographyGrid'

    static propTypes = {
        classes: PropTypes.shape({
            cell: PropTypes.string.isRequired,
            table: PropTypes.string.isRequired
        }).isRequired
    }

    render() {

        const classes = this.props.classes

        return (
            <Root>
                <table className={classes.table}>
                    <tbody>
                        {map(variant => (
                            <tr key={variant}>
                                <td className={classes.cell}>{variant}</td>
                                <td className={classes.cell}>
                                    <Typography variant={variant}>{variant}</Typography>
                                </td>
                            </tr>
                        ), VARIANTS)}
                    </tbody>
                </table>
            </Root>
        )
    }
})
