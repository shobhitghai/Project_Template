/* eslint-disable */

export default theme => {

    return {

        table: {
            width: '100%'
        },

        cell: {
            padding: theme.spacing(1),
            textAlign: 'center'
        }
    }
}
