import map from 'lodash/fp/map'
import PropTypes from 'prop-types'
import React from 'react'
import Button from '../../../button'
import Fab from '../../../fab'
import Root from '../../../root'
import { withStyles } from '../../../styles'
import styles from '../styles'


const map3 = map.convert({ cap: false })

const VARIANTS = [ 'contained', 'text', 'outlined' ]
const FAB_VARIANTS = [ 'round', 'extended' ]

const props = [
    { },
    { disabled: true },
    { size: 'small' },
    { size: 'large' }
]

const rows = [
    {
        name: 'Default',
        variants: props
    },
    {
        name: 'Primary',
        variants: map(
            item => ({ ...item, color: 'primary' }),
            props
        )
    },
    {
        name: 'Secondary',
        variants: map(
            item => ({ ...item, color: 'secondary' }),
            props
        )
    }
]

export default withStyles(styles)(class extends React.Component {

    static displayName = 'ButtonGrid'

    static propTypes = {
        classes: PropTypes.shape({
            cell: PropTypes.string.isRequired,
            table: PropTypes.string.isRequired
        }).isRequired
    }

    renderCell = props => (

        <td key={props.variant} className={this.props.classes.cell}>
            <Button {...props}>
                {props.variant}
            </Button>
        </td>
    )

    renderFab = props => (

        <td key={props.variant} className={this.props.classes.cell}>
            <Fab {...props}>
                {props.variant}
            </Fab>
        </td>
    )

    render() {

        const classes = this.props.classes

        return (
            <Root>
                <table className={classes.table}>
                    <thead>
                        <tr>
                            {map(variant => (
                                <th key={variant}>{variant}</th>
                            ), VARIANTS)}
                            {map(variant => (
                                <th key={variant}>Fab - {variant}</th>
                            ), FAB_VARIANTS)}
                        </tr>
                    </thead>
                    <tbody>
                        {map(({ name, variants }) => (
                            <React.Fragment key={name}>
                                <tr>
                                    <td>{name}</td>
                                </tr>
                                {map3((props, index) => (
                                    <tr key={index}>
                                        {map(
                                            variant => this.renderCell({ ...props, variant }),
                                            VARIANTS
                                        )}
                                        {map(
                                            variant => this.renderFab({ ...props, variant }),
                                            FAB_VARIANTS
                                        )}
                                    </tr>
                                ), variants)}
                            </React.Fragment>
                        ), rows)}
                    </tbody>
                </table>
            </Root>
        )
    }
})
