/* eslint-disable */
import React from 'react'
import SingleProp from './single'


export default ({ value }) => (
    <ul>
        {Object.keys(value).map(prop => (
            <SingleProp prop={prop} value={value[prop]} />
        ))}
    </ul>
)