/* eslint-disable */
import React from 'react'
import ValueRenderer from '../value-renderer'


export default ({ prop, value }) => (
    <li style={{ marginBottom: 4 }}>
        {prop}: <ValueRenderer value={value} />
    </li>
)