/* eslint-disable */
import React from 'react'
import ColorRenderer from './color'


export default ({ value }) => {
    const valueStr = '' + value
    if (valueStr.startsWith`#` || valueStr.startsWith`rgb`) { // color
        return (
            <ColorRenderer color={value} />
        )
    }
    return <span>{value}</span>
}