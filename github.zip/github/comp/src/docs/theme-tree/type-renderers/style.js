export default color => ({
    backgroundColor: color,
    borderColor: 'gray',
    borderStyle: 'solid',
    borderWidth: 1,
    height: 16,
    marginLeft: 4,
    width: 32
})
