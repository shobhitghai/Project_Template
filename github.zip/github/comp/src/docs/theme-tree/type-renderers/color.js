/* eslint-disable */
import React from 'react'
import style from './style'


export default ({ color }) => (
    <span style={{ alignItems: 'center', display: 'inline-flex' }}>
        {color}
        <div style={style(color)}></div>
    </span>
)
