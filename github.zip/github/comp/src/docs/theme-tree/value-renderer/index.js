/* eslint-disable */
import React from 'react'
import TypeRenderer from '../type-renderers'
import ComplexProp from '../prop-renderers/complex'


export default ({ value }) => (
    typeof(value) === 'object' ? <ComplexProp value={value} /> : <TypeRenderer value={value} />
)