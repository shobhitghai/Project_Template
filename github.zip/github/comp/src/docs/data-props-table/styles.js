/* eslint-disable */

export const dataPropsTableStyles = theme => {

    return {

        root: {

            padding: 0,
            tableLayout: 'auto',
            boxShadow: '0 0 0 1px #CED4DE',
            backgroundColor: 'transparent',
            borderSpacing: 0,
            borderCollapse: 'collapse',
            borderStyle: 'hidden',
            borderRadius: 5,
            color: '#13161F',
            marginBottom: 20,
            overflowY: 'hidden',
            display: 'block',
            width: '100%',
            fontFamily: '"Source Code Pro", monospace',
            fontSize: 14,

            '@media (min-width: 420px)': {

                overflowY: 'hidden',
                display: 'block',
                marginBottom: 40
            },
            
            '@media (min-width: 920px)': {

                overflowY: 'hidden',
                display: 'block',

                'thead th:nth-child(1)': {
                    width: '20%'
                },

                'thead th:nth-child(2)': {
                    width: '10%'
                },

                'thead th:nth-child(3)': {
                    width: '10%'
                },

                'thead th:nth-child(4)': {
                    width: '10%'
                },

                'thead th:nth-child(5)': {
                    width: '20%'
                }
            },
        },

        head: {

            color: '#7D899C',
            background: '#EEF1F5'
        },

        headCell: {

            textAlign: 'left',
            fontWeight: 400,
            padding: '20px 20px'
        },

        row: {

            display: 'table-row',
            borderTop: '1px solid #CED4DE'
        },

        cell: {

            padding: '12px 20px',
            lineHeight: 2,
            fontWeight: 200,
            whiteSpace: 'pre'
        },

        link: {

            textDecoration: 'underline'
        }
    }
}
