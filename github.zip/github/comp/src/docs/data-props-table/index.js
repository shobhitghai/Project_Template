import capitalize from 'lodash/fp/capitalize'
import getOr from 'lodash/fp/getOr'
import isEmpty from 'lodash/fp/isEmpty'
import join from 'lodash/fp/join'
import map from 'lodash/fp/map'
import PropTypes from 'prop-types'
import React from 'react'
import { withStyles } from '../../styles/'
import Tooltip from '../../tooltip'
import { dataPropsTableStyles } from './styles'


export default withStyles(dataPropsTableStyles)(class extends React.Component {

    static displayName = 'DataPropsTable'

    static propTypes = {
        classes: PropTypes.shape({
            cell: PropTypes.string.isRequired,
            head: PropTypes.string.isRequired,
            headCell: PropTypes.string.isRequired,
            link: PropTypes.string.isRequired,
            root: PropTypes.string.isRequired,
            row: PropTypes.string.isRequired
        }).isRequired
    }

    getPropType = (prop, Tooltip) => {

        const propName = getOr('', 'type.name', prop)
        const isEnum = propName.startsWith('"') || propName === 'enum'
        const name = capitalize(isEnum ? 'enum' : propName)
        const value = prop.type && prop.type.value

        if (!name) {
            return null
        }

        if (
            !Tooltip
            || (isEnum && typeof value === 'string')
            || (!prop.flowType && !isEnum && !value)
            || (prop.flowType && !prop.flowType.elements)
        ) {
            return name
        }

        const key = prop.type.name === 'union' ? 'name' : 'value'

        const title = join(', ', map(
            item => {

                if (item[key] === 'arrayOf') {
                    return `[${item.value.name}]`
                }

                return item[key]
            },
            prop.type.value
        ))

        return (
            <Tooltip placement="right" title={title}>
                <span className={this.props.classes.link}>{name}</span>
            </Tooltip>
        )
    }

    render() {

        const { props } = this

        if (isEmpty(props.of.props)) {

            return <div>Sorry no props have been defined</div>
        }

        return (
            <table className={`PropsTable ${props.classes.root}`}>
                <thead className={props.classes.head}>
                    <tr>
                        <th className={`PropsTable--property ${props.classes.headCell}`}>Property</th>
                        <th className={`PropsTable--type ${props.classes.headCell}`}>Type</th>
                        <th className={`PropsTable--required ${props.classes.headCell}`}>Required</th>
                        <th className={`PropsTable--default ${props.classes.headCell}`}>Default</th>
                        <th className={`PropsTable--description ${props.classes.headCell}`}>Description</th>
                    </tr>
                </thead>
                <tbody>
                    {Object.keys(props.of.props).map(name => {

                        const prop = props.of.props[name]

                        return (
                            <tr key={name} className={props.classes.row}>
                                <td className={props.classes.cell}>{name}</td>
                                <td className={props.classes.cell}>{this.getPropType(prop, Tooltip)}</td>
                                <td className={props.classes.cell}>{prop.required}</td>
                                <td className={props.classes.cell}>{prop.defaultValue && prop.defaultValue.value}</td>
                                <td className={props.classes.cell}>{prop.description}</td>
                            </tr>
                        )
                    })}
                </tbody>
            </table>
        )
    }
})
