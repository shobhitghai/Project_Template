/* eslint-disable */
module.exports = {
    "appbar": {
        "displayName": "AppBar",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "position": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'absolute'",
                            "computed": false
                        },
                        {
                            "value": "'fixed'",
                            "computed": false
                        },
                        {
                            "value": "'relative'",
                            "computed": false
                        },
                        {
                            "value": "'static'",
                            "computed": false
                        },
                        {
                            "value": "'sticky'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The positioning type. The behavior of the different options is described\r\n[in the MDN web docs](https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Positioning).\r\nNote: `sticky` is not universally supported and will fall back to `static` when unavailable."
            }
        }
    },
    "avatar": {
        "displayName": "Avatar",
        "description": "",
        "methods": [],
        "props": {
            "alt": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Used in combination with `src` or `srcSet` to\r\nprovide an alt attribute for the rendered `img` element."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Used to render icon or text elements inside the Avatar if `src` is not set.\r\nThis can be an element, or just a string."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "imgProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Attributes applied to the `img` element if the component is used to display an image.\r\nIt can be used to listen for the loading error event."
            },
            "sizes": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The `sizes` attribute for the `img` element."
            },
            "src": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The `src` attribute for the `img` element."
            },
            "srcSet": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The `srcSet` attribute for the `img` element.\r\nUse this attribute for responsive image display."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'circle'",
                            "computed": false
                        },
                        {
                            "value": "'rounded'",
                            "computed": false
                        },
                        {
                            "value": "'square'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The shape of the avatar."
            }
        }
    },
    "backdrop": {
        "displayName": "Backdrop",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "invisible": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the backdrop is invisible.\r\nIt can be used when rendering a popover or a custom select component."
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": true,
                "description": "If `true`, the backdrop is open."
            },
            "transitionDuration": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "shape",
                            "value": {
                                "appear": {
                                    "name": "number",
                                    "required": false
                                },
                                "enter": {
                                    "name": "number",
                                    "required": false
                                },
                                "exit": {
                                    "name": "number",
                                    "required": false
                                }
                            }
                        }
                    ]
                },
                "required": false,
                "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
            }
        }
    },
    "badge": {
        "displayName": "Badge",
        "description": "",
        "methods": [],
        "props": {
            "anchorOrigin": {
                "type": {
                    "name": "shape",
                    "value": {
                        "horizontal": {
                            "name": "enum",
                            "value": [
                                {
                                    "value": "'left'",
                                    "computed": false
                                },
                                {
                                    "value": "'right'",
                                    "computed": false
                                }
                            ],
                            "required": true
                        },
                        "vertical": {
                            "name": "enum",
                            "value": [
                                {
                                    "value": "'bottom'",
                                    "computed": false
                                },
                                {
                                    "value": "'top'",
                                    "computed": false
                                }
                            ],
                            "required": true
                        }
                    }
                },
                "required": false,
                "description": "The anchor of the badge."
            },
            "badgeContent": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content rendered within the badge."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The badge will be added relative to this node."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'error'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "invisible": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the badge will be invisible."
            },
            "max": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Max count to show."
            },
            "overlap": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'circle'",
                            "computed": false
                        },
                        {
                            "value": "'rectangle'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Wrapped shape the badge should overlap."
            },
            "showZero": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Controls whether the badge is hidden when `badgeContent` is zero."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'dot'",
                            "computed": false
                        },
                        {
                            "value": "'standard'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "bottomnavigation": {
        "displayName": "BottomNavigation",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the value changes.\r\n\n@param {object} event The event source of the callback.\r\n@param {any} value We default to the index of the child."
            },
            "showLabels": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, all `BottomNavigationAction`s will show their labels.\r\nBy default, only the selected `BottomNavigationAction` will show its label."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The value of the currently selected `BottomNavigationAction`."
            }
        }
    },
    "bottomnavigationaction": {
        "displayName": "BottomNavigationAction",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "custom",
                    "raw": "unsupportedProp"
                },
                "required": false,
                "description": "This prop isn't supported.\r\nUse the `component` prop if you need to change the children structure."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon element."
            },
            "label": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The label element."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onClick": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "selected": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "showLabel": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `BottomNavigationAction` will show its label.\r\nBy default, only the selected `BottomNavigationAction`\r\ninside `BottomNavigation` will show its label."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "You can provide your own value. Otherwise, we fallback to the child position index."
            }
        }
    },
    "breadcrumbs": {
        "displayName": "Breadcrumbs",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "The breadcrumb children."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component.\r\nBy default, it maps the variant to a good default headline component."
            },
            "itemsAfterCollapse": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "If max items is exceeded, the number of items to show after the ellipsis."
            },
            "itemsBeforeCollapse": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "If max items is exceeded, the number of items to show before the ellipsis."
            },
            "maxItems": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Specifies the maximum number of breadcrumbs to display. When there are more\r\nthan the maximum number, only the first `itemsBeforeCollapse` and last `itemsAfterCollapse`\r\nwill be shown, with an ellipsis in between."
            },
            "separator": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Custom separator node."
            }
        }
    },
    "button": {
        "displayName": "Button",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "The content of the button."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the button will be disabled."
            },
            "disableElevation": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, no elevation is used."
            },
            "disableFocusRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the  keyboard focus ripple will be disabled.\r\n`disableRipple` must also be true."
            },
            "disableRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the ripple effect will be disabled.\r\n\n⚠️ Without a ripple there is no styling for :focus-visible by default. Be sure\r\nto highlight the element by applying separate styles with the `focusVisibleClassName`."
            },
            "endIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Element placed after the children."
            },
            "focusVisibleClassName": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "fullWidth": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the button will take up the full width of its container."
            },
            "href": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The URL to link to when the button is clicked.\r\nIf defined, an `a` element will be used as the root node."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        },
                        {
                            "value": "'large'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The size of the button.\r\n`small` is equivalent to the dense button styling."
            },
            "startIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Element placed before the children."
            },
            "type": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'text'",
                            "computed": false
                        },
                        {
                            "value": "'outlined'",
                            "computed": false
                        },
                        {
                            "value": "'contained'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "buttonbase": {
        "displayName": "ButtonBase",
        "description": "`ButtonBase` contains as few styles as possible.\r\nIt aims to be a simple building block for creating a button.\r\nIt contains a load of style reset and some focus/ripple logic.",
        "methods": [],
        "props": {
            "action": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "A ref for imperative actions.\r\nIt currently only supports `focusVisible()` action."
            },
            "buttonRef": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "@ignore\r\n\nUse that prop to pass a ref to the native button component.\r\n@deprecated Use `ref` instead."
            },
            "centerRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the ripples will be centered.\r\nThey won't start at the cursor interaction position."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "custom",
                    "raw": "elementTypeAcceptingRef"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the base button will be disabled."
            },
            "disableRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the ripple effect will be disabled.\r\n\n⚠️ Without a ripple there is no styling for :focus-visible by default. Be sure\r\nto highlight the element by applying separate styles with the `focusVisibleClassName`."
            },
            "disableTouchRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the touch ripple effect will be disabled."
            },
            "focusRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the base button will have a keyboard focus ripple.\r\n`disableRipple` must also be `false`."
            },
            "focusVisibleClassName": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "This prop can help a person know which element has the keyboard focus.\r\nThe class name will be applied when the element gain the focus through a keyboard interaction.\r\nIt's a polyfill for the [CSS :focus-visible selector](https://drafts.csswg.org/selectors-4/#the-focus-visible-pseudo).\r\nThe rationale for using this feature [is explained here](https://github.com/WICG/focus-visible/blob/master/explainer.md).\r\nA [polyfill can be used](https://github.com/WICG/focus-visible) to apply a `focus-visible` class to other components\r\nif needed."
            },
            "onBlur": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onClick": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onDragLeave": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onFocus": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onFocusVisible": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component is focused with a keyboard.\r\nWe trigger a `onFocus` callback too."
            },
            "onKeyDown": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onKeyUp": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onMouseDown": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onMouseLeave": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onMouseUp": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onTouchEnd": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onTouchMove": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onTouchStart": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "role": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "tabIndex": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "string"
                        }
                    ]
                },
                "required": false,
                "description": "@ignore"
            },
            "TouchRippleProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the `TouchRipple` element."
            },
            "type": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'submit'",
                            "computed": false
                        },
                        {
                            "value": "'reset'",
                            "computed": false
                        },
                        {
                            "value": "'button'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Used to control the button's purpose.\r\nThis prop passes the value to the `type` attribute of the native button component."
            }
        }
    },
    "buttongroup": {
        "displayName": "ButtonGroup",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "The content of the button group."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the buttons will be disabled."
            },
            "disableFocusRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the button keyboard focus ripple will be disabled.\r\n`disableRipple` must also be true."
            },
            "disableRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the button ripple effect will be disabled."
            },
            "fullWidth": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the buttons will take up the full width of its container."
            },
            "orientation": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'vertical'",
                            "computed": false
                        },
                        {
                            "value": "'horizontal'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The group orientation."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        },
                        {
                            "value": "'large'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The size of the button.\r\n`small` is equivalent to the dense button styling."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'text'",
                            "computed": false
                        },
                        {
                            "value": "'outlined'",
                            "computed": false
                        },
                        {
                            "value": "'contained'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "card": {
        "displayName": "Card",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "raised": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the card will use raised styling."
            }
        }
    },
    "cardactionarea": {
        "displayName": "CardActionArea",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "focusVisibleClassName": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "cardactions": {
        "displayName": "CardActions",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "disableSpacing": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the actions do not have additional margin."
            }
        }
    },
    "cardcontent": {
        "displayName": "CardContent",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            }
        }
    },
    "cardheader": {
        "displayName": "CardHeader",
        "description": "",
        "methods": [],
        "props": {
            "action": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The action to display in the card header."
            },
            "avatar": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The Avatar for the Card Header."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "disableTypography": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, `subheader` and `title` won't be wrapped by a Typography component.\r\nThis can be useful to render an alternative Typography variant by wrapping\r\nthe `title` text, and optional `subheader` text\r\nwith the Typography component."
            },
            "subheader": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "subheaderTypographyProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "These props will be forwarded to the subheader\r\n(as long as disableTypography is not `true`)."
            },
            "title": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the Card Title."
            },
            "titleTypographyProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "These props will be forwarded to the title\r\n(as long as disableTypography is not `true`)."
            }
        }
    },
    "cardmedia": {
        "displayName": "CardMedia",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "custom",
                    "raw": "chainPropTypes(PropTypes.node, props => {\r\n  if (!props.children && !props.image && !props.src) {\r\n    return new Error('Material-UI: either `children`, `image` or `src` prop must be specified.');\r\n  }\r\n  return null;\r\n})"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "Component for rendering image.\r\nEither a string to use a DOM element or a component."
            },
            "image": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Image to be displayed as a background image.\r\nEither `image` or `src` prop must be specified.\r\nNote that caller must specify height otherwise the image will not be visible."
            },
            "src": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "An alias for `image` property.\r\nAvailable only with media components.\r\nMedia components: `video`, `audio`, `picture`, `iframe`, `img`."
            },
            "style": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "checkbox": {
        "displayName": "Checkbox",
        "description": "",
        "methods": [],
        "props": {
            "checked": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component is checked."
            },
            "checkedIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display when the component is checked."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        },
                        {
                            "value": "'default'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the switch will be disabled."
            },
            "disableRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the ripple effect will be disabled."
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display when the component is unchecked."
            },
            "id": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The id of the `input` element."
            },
            "indeterminate": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component appears indeterminate.\r\nThis does not set the native input element to indeterminate due\r\nto inconsistent behavior across browsers.\r\nHowever, we set a `data-indeterminate` attribute on the input."
            },
            "indeterminateIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display when the component is indeterminate."
            },
            "inputProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "[Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Attributes) applied to the `input` element."
            },
            "inputRef": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "Pass a ref to the `input` element."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the state is changed.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new checked state by accessing `event.target.checked` (boolean)."
            },
            "required": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be required."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The size of the checkbox.\r\n`small` is equivalent to the dense checkbox styling."
            },
            "type": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The input component prop `type`."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The value of the component. The DOM API casts this to a string."
            }
        }
    },
    "chip": {
        "displayName": "Chip",
        "description": "Chips represent complex entities in small blocks, such as a contact.",
        "methods": [],
        "props": {
            "avatar": {
                "type": {
                    "name": "element"
                },
                "required": false,
                "description": "Avatar element."
            },
            "children": {
                "type": {
                    "name": "custom",
                    "raw": "unsupportedProp"
                },
                "required": false,
                "description": "This prop isn't supported.\r\nUse the `component` prop if you need to change the children structure."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "clickable": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the chip will appear clickable, and will raise when pressed,\r\neven if the onClick prop is not defined.\r\nIf false, the chip will not be clickable, even if onClick prop is defined.\r\nThis can be used, for example,\r\nalong with the component prop to indicate an anchor Chip is clickable."
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "deleteIcon": {
                "type": {
                    "name": "element"
                },
                "required": false,
                "description": "Override the default delete icon element. Shown only if `onDelete` is set."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the chip should be displayed in a disabled state."
            },
            "icon": {
                "type": {
                    "name": "element"
                },
                "required": false,
                "description": "Icon element."
            },
            "label": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the label."
            },
            "onClick": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onDelete": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback function fired when the delete icon is clicked.\r\nIf set, the delete icon will be shown."
            },
            "onKeyDown": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onKeyUp": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The size of the chip."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'outlined'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "circularprogress": {
        "displayName": "CircularProgress",
        "description": "## ARIA\r\n\nIf the progress bar is describing the loading progress of a particular region of a page,\r\nyou should use `aria-describedby` to point to the progress bar, and set the `aria-busy`\r\nattribute to `true` on that region until it has finished loading.",
        "methods": [],
        "props": {
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "disableShrink": {
                "type": {
                    "name": "custom",
                    "raw": "chainPropTypes(PropTypes.bool, props => {\r\n  if (props.disableShrink && props.variant && props.variant !== 'indeterminate') {\r\n    return new Error(\r\n      'Material-UI: you have provided the `disableShrink` prop ' +\r\n        'with a variant other than `indeterminate`. This will have no effect.',\r\n    );\r\n  }\r\n\r\n  return null;\r\n})"
                },
                "required": false,
                "description": "If `true`, the shrink animation is disabled.\r\nThis only works if variant is `indeterminate`."
            },
            "size": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "string"
                        }
                    ]
                },
                "required": false,
                "description": "The size of the circle.\r\nIf using a number, the pixel unit is assumed.\r\nIf using a string, you need to provide the CSS unit, e.g '3rem'."
            },
            "style": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "@ignore"
            },
            "thickness": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The thickness of the circle."
            },
            "value": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The value of the progress indicator for the determinate and static variants.\r\nValue between 0 and 100."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'determinate'",
                            "computed": false
                        },
                        {
                            "value": "'indeterminate'",
                            "computed": false
                        },
                        {
                            "value": "'static'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use.\r\nUse indeterminate when there is no progress value."
            }
        }
    },
    "clickawaylistener": {
        "displayName": "ClickAwayListener",
        "description": "Listen for click events that occur somewhere in the document, outside of the element itself.\r\nFor instance, if you need to hide a menu when people click anywhere else on your page.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "custom",
                    "raw": "elementAcceptingRef.isRequired"
                },
                "required": false,
                "description": "The wrapped element."
            },
            "mouseEvent": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'onClick'",
                            "computed": false
                        },
                        {
                            "value": "'onMouseDown'",
                            "computed": false
                        },
                        {
                            "value": "'onMouseUp'",
                            "computed": false
                        },
                        {
                            "value": "false",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The mouse event to listen to. You can disable the listener by providing `false`."
            },
            "onClickAway": {
                "type": {
                    "name": "func"
                },
                "required": true,
                "description": "Callback fired when a \"click away\" event is detected."
            },
            "touchEvent": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'onTouchStart'",
                            "computed": false
                        },
                        {
                            "value": "'onTouchEnd'",
                            "computed": false
                        },
                        {
                            "value": "false",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The touch event to listen to. You can disable the listener by providing `false`."
            }
        }
    },
    "collapse": {
        "displayName": "Collapse",
        "description": "The Collapse transition is used by the\r\n[Vertical Stepper](/components/steppers/#vertical-stepper) StepContent component.\r\nIt uses [react-transition-group](https://github.com/reactjs/react-transition-group) internally.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content node to be collapsed."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "collapsedHeight": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "The height of the container when collapsed."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "in": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component will transition in."
            },
            "onEnter": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onEntered": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onEntering": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onExit": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onExiting": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "style": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "@ignore"
            },
            "timeout": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "shape",
                            "value": {
                                "enter": {
                                    "name": "number",
                                    "required": false
                                },
                                "exit": {
                                    "name": "number",
                                    "required": false
                                }
                            }
                        },
                        {
                            "name": "enum",
                            "value": [
                                {
                                    "value": "'auto'",
                                    "computed": false
                                }
                            ]
                        }
                    ]
                },
                "required": false,
                "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object.\r\n\nSet to 'auto' to automatically calculate transition time based on height."
            }
        }
    },
    "container": {
        "displayName": "Container",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": ""
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "disableGutters": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the left and right padding is removed."
            },
            "fixed": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Set the max-width to match the min-width of the current breakpoint.\r\nThis is useful if you'd prefer to design for a fixed set of sizes\r\ninstead of trying to accommodate a fully fluid viewport.\r\nIt's fluid by default."
            },
            "maxWidth": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'xs'",
                            "computed": false
                        },
                        {
                            "value": "'sm'",
                            "computed": false
                        },
                        {
                            "value": "'md'",
                            "computed": false
                        },
                        {
                            "value": "'lg'",
                            "computed": false
                        },
                        {
                            "value": "'xl'",
                            "computed": false
                        },
                        {
                            "value": "false",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Determine the max-width of the container.\r\nThe container width grows with the size of the screen.\r\nSet to `false` to disable `maxWidth`."
            }
        }
    },
    "cssbaseline": {
        "displayName": "CssBaseline",
        "description": "Kickstart an elegant, consistent, and simple baseline to build upon.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "You can wrap a node."
            }
        }
    },
    "dialog": {
        "displayName": "Dialog",
        "description": "Dialogs are overlaid modal paper based components with a backdrop.",
        "methods": [],
        "props": {
            "aria-describedby": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The id(s) of the element(s) that describe the dialog."
            },
            "aria-labelledby": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The id(s) of the element(s) that label the dialog."
            },
            "BackdropProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "@ignore"
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "Dialog children, usually the included sub-components."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "disableBackdropClick": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, clicking the backdrop will not fire the `onClose` callback."
            },
            "disableEscapeKeyDown": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, hitting escape will not fire the `onClose` callback."
            },
            "fullScreen": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the dialog will be full-screen"
            },
            "fullWidth": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the dialog stretches to `maxWidth`.\r\n\nNotice that the dialog width grow is limited by the default margin."
            },
            "maxWidth": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'xs'",
                            "computed": false
                        },
                        {
                            "value": "'sm'",
                            "computed": false
                        },
                        {
                            "value": "'md'",
                            "computed": false
                        },
                        {
                            "value": "'lg'",
                            "computed": false
                        },
                        {
                            "value": "'xl'",
                            "computed": false
                        },
                        {
                            "value": "false",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Determine the max-width of the dialog.\r\nThe dialog width grows with the size of the screen.\r\nSet to `false` to disable `maxWidth`."
            },
            "onBackdropClick": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the backdrop is clicked."
            },
            "onClose": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"escapeKeyDown\"`, `\"backdropClick\"`."
            },
            "onEnter": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired before the dialog enters."
            },
            "onEntered": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the dialog has entered."
            },
            "onEntering": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the dialog is entering."
            },
            "onEscapeKeyDown": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the escape key is pressed,\r\n`disableKeyboard` is false and the modal is in focus."
            },
            "onExit": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired before the dialog exits."
            },
            "onExited": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the dialog has exited."
            },
            "onExiting": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the dialog is exiting."
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": true,
                "description": "If `true`, the Dialog is open."
            },
            "PaperComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used to render the body of the dialog."
            },
            "PaperProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Paper`](/api/paper/) element."
            },
            "scroll": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'body'",
                            "computed": false
                        },
                        {
                            "value": "'paper'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Determine the container for scrolling the dialog."
            },
            "TransitionComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
            },
            "transitionDuration": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "shape",
                            "value": {
                                "enter": {
                                    "name": "number",
                                    "required": false
                                },
                                "exit": {
                                    "name": "number",
                                    "required": false
                                }
                            }
                        }
                    ]
                },
                "required": false,
                "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
            },
            "TransitionProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
            }
        }
    },
    "dialogactions": {
        "displayName": "DialogActions",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "disableSpacing": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the actions do not have additional margin."
            }
        }
    },
    "dialogcontent": {
        "displayName": "DialogContent",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "dividers": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Display the top and bottom dividers."
            }
        }
    },
    "dialogcontenttext": {
        "displayName": "DialogContentText",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            }
        }
    },
    "dialogtitle": {
        "displayName": "DialogTitle",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "disableTypography": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the children won't be wrapped by a typography component.\r\nFor instance, this can be useful to render an h4 instead of the default h2."
            }
        }
    },
    "divider": {
        "displayName": "Divider",
        "description": "",
        "methods": [],
        "props": {
            "absolute": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Absolutely position the element."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "light": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the divider will have a lighter color."
            },
            "orientation": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'horizontal'",
                            "computed": false
                        },
                        {
                            "value": "'vertical'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The divider orientation."
            },
            "role": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'fullWidth'",
                            "computed": false
                        },
                        {
                            "value": "'inset'",
                            "computed": false
                        },
                        {
                            "value": "'middle'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "drawer": {
        "displayName": "Drawer",
        "description": "The props of the [Modal](/api/modal/) component are available\r\nwhen `variant=\"temporary\"` is set.",
        "methods": [],
        "props": {
            "anchor": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'left'",
                            "computed": false
                        },
                        {
                            "value": "'top'",
                            "computed": false
                        },
                        {
                            "value": "'right'",
                            "computed": false
                        },
                        {
                            "value": "'bottom'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Side from which the drawer will appear."
            },
            "BackdropProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "@ignore"
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The contents of the drawer."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "elevation": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The elevation of the drawer."
            },
            "ModalProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Modal`](/api/modal/) element."
            },
            "onClose": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback."
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the drawer is open."
            },
            "PaperProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Paper`](/api/paper/) element."
            },
            "SlideProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Slide`](/api/slide/) element."
            },
            "transitionDuration": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "shape",
                            "value": {
                                "enter": {
                                    "name": "number",
                                    "required": false
                                },
                                "exit": {
                                    "name": "number",
                                    "required": false
                                }
                            }
                        }
                    ]
                },
                "required": false,
                "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'permanent'",
                            "computed": false
                        },
                        {
                            "value": "'persistent'",
                            "computed": false
                        },
                        {
                            "value": "'temporary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "expansionpanel": {
        "displayName": "ExpansionPanel",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "custom",
                    "raw": "chainPropTypes(PropTypes.node.isRequired, props => {\r\n  const summary = React.Children.toArray(props.children)[0];\r\n  if (isFragment(summary)) {\r\n    return new Error(\r\n      \"Material-UI: the ExpansionPanel doesn't accept a Fragment as a child. \" +\r\n        'Consider providing an array instead.',\r\n    );\r\n  }\r\n\r\n  if (!React.isValidElement(summary)) {\r\n    return new Error(\r\n      'Material-UI: expected the first child of ExpansionPanel to be a valid element.',\r\n    );\r\n  }\r\n\r\n  return null;\r\n})"
                },
                "required": false,
                "description": "The content of the expansion panel."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "defaultExpanded": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, expands the panel by default."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the panel will be displayed in a disabled state."
            },
            "expanded": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, expands the panel, otherwise collapse it.\r\nSetting this prop enables control over the panel."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the expand/collapse state is changed.\r\n\n@param {object} event The event source of the callback.\r\n@param {boolean} expanded The `expanded` state of the panel."
            },
            "square": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "TransitionComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the collapse effect.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
            },
            "TransitionProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
            }
        }
    },
    "expansionpanelactions": {
        "displayName": "ExpansionPanelActions",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "disableSpacing": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the actions do not have additional margin."
            }
        }
    },
    "expansionpaneldetails": {
        "displayName": "ExpansionPanelDetails",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "The content of the expansion panel details."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "expansionpanelsummary": {
        "displayName": "ExpansionPanelSummary",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the expansion panel summary."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "expandIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display as the expand indicator."
            },
            "IconButtonProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the `IconButton` element wrapping the expand icon."
            },
            "onBlur": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onClick": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onFocusVisible": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "fab": {
        "displayName": "Fab",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "The content of the button."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the button will be disabled."
            },
            "disableFocusRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the  keyboard focus ripple will be disabled.\r\n`disableRipple` must also be true."
            },
            "disableRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the ripple effect will be disabled."
            },
            "focusVisibleClassName": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "href": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The URL to link to when the button is clicked.\r\nIf defined, an `a` element will be used as the root node."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        },
                        {
                            "value": "'large'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The size of the button.\r\n`small` is equivalent to the dense button styling."
            },
            "type": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'round'",
                            "computed": false
                        },
                        {
                            "value": "'extended'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "fade": {
        "displayName": "Fade",
        "description": "The Fade transition is used by the [Modal](/components/modal/) component.\r\nIt uses [react-transition-group](https://github.com/reactjs/react-transition-group) internally.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "element"
                },
                "required": false,
                "description": "A single child content element."
            },
            "in": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component will transition in."
            },
            "onEnter": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onExit": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "style": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "@ignore"
            },
            "timeout": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "shape",
                            "value": {
                                "enter": {
                                    "name": "number",
                                    "required": false
                                },
                                "exit": {
                                    "name": "number",
                                    "required": false
                                }
                            }
                        }
                    ]
                },
                "required": false,
                "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
            }
        }
    },
    "filledinput": {
        "displayName": "FilledInput",
        "description": "",
        "methods": [],
        "props": {
            "autoComplete": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "This prop helps users to fill forms faster, especially on mobile devices.\r\nThe name can be confusing, as it's more like an autofill.\r\nYou can learn more about it [following the specification](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofill)."
            },
            "autoFocus": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be focused during the first mount."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The CSS class name of the wrapper element."
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "defaultValue": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The default `input` element value. Use when the component is not controlled."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be disabled."
            },
            "disableUnderline": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input will not have an underline."
            },
            "endAdornment": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "End `InputAdornment` for this component."
            },
            "error": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input will indicate an error. This is normally obtained via context from\r\nFormControl."
            },
            "fullWidth": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input will take up the full width of its container."
            },
            "id": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The id of the `input` element."
            },
            "inputComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the native input.\r\nEither a string to use a DOM element or a component."
            },
            "inputProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "[Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Attributes) applied to the `input` element."
            },
            "inputRef": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "Pass a ref to the `input` element."
            },
            "margin": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'dense'",
                            "computed": false
                        },
                        {
                            "value": "'none'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "If `dense`, will adjust vertical spacing. This is normally obtained via context from\r\nFormControl."
            },
            "multiline": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, a textarea element will be rendered."
            },
            "name": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Name attribute of the `input` element."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the value is changed.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new value by accessing `event.target.value` (string)."
            },
            "placeholder": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The short hint displayed in the input before the user enters a value."
            },
            "readOnly": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "It prevents the user from changing the value of the field\r\n(not from interacting with the field)."
            },
            "required": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be required."
            },
            "rows": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Number of rows to display when multiline option is set to true."
            },
            "rowsMax": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Maximum number of rows to display when multiline option is set to true."
            },
            "startAdornment": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Start `InputAdornment` for this component."
            },
            "type": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Type of the `input` element. It should be [a valid HTML5 input type](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Form_%3Cinput%3E_types)."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The value of the `input` element, required for a controlled component."
            }
        }
    },
    "formcontrol": {
        "displayName": "FormControl",
        "description": "Provides context such as filled/focused/error/required for form inputs.\r\nRelying on the context provides high flexibility and ensures that the state always stays\r\nconsistent across the children of the `FormControl`.\r\nThis context is used by the following components:\r\n\n - FormLabel\r\n - FormHelperText\r\n - Input\r\n - InputLabel\r\n\nYou can find one composition example below and more going to [the demos](/components/text-fields/#components).\r\n\n```jsx\r\n<FormControl>\r\n  <InputLabel htmlFor=\"my-input\">Email address</InputLabel>\r\n  <Input id=\"my-input\" aria-describedby=\"my-helper-text\" />\r\n  <FormHelperText id=\"my-helper-text\">We'll never share your email.</FormHelperText>\r\n</FormControl>\r\n```\r\n\n⚠️Only one input can be used within a FormControl.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The contents of the form control."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the label, input and helper text should be displayed in a disabled state."
            },
            "error": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the label should be displayed in an error state."
            },
            "fullWidth": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component will take up the full width of its container."
            },
            "hiddenLabel": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the label will be hidden.\r\nThis is used to increase density for a `FilledInput`.\r\nBe sure to add `aria-label` to the `input` element."
            },
            "margin": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'none'",
                            "computed": false
                        },
                        {
                            "value": "'dense'",
                            "computed": false
                        },
                        {
                            "value": "'normal'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "If `dense` or `normal`, will adjust vertical spacing of this and contained components."
            },
            "required": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the label will indicate that the input is required."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The size of the text field."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'standard'",
                            "computed": false
                        },
                        {
                            "value": "'outlined'",
                            "computed": false
                        },
                        {
                            "value": "'filled'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "formcontrollabel": {
        "displayName": "FormControlLabel",
        "description": "Drop in replacement of the `Radio`, `Switch` and `Checkbox` component.\r\nUse this component if you want to display an extra label.",
        "methods": [],
        "props": {
            "checked": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component appears selected."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "control": {
                "type": {
                    "name": "element"
                },
                "required": false,
                "description": "A control element. For instance, it can be be a `Radio`, a `Switch` or a `Checkbox`."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the control will be disabled."
            },
            "inputRef": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "Pass a ref to the `input` element."
            },
            "label": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The text to be used in an enclosing label element."
            },
            "labelPlacement": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'end'",
                            "computed": false
                        },
                        {
                            "value": "'start'",
                            "computed": false
                        },
                        {
                            "value": "'top'",
                            "computed": false
                        },
                        {
                            "value": "'bottom'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The position of the label."
            },
            "name": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": ""
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the state is changed.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new checked state by accessing `event.target.checked` (boolean)."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The value of the component."
            }
        }
    },
    "formgroup": {
        "displayName": "FormGroup",
        "description": "`FormGroup` wraps controls such as `Checkbox` and `Switch`.\r\nIt provides compact row layout.\r\nFor the `Radio`, you should be using the `RadioGroup` component instead of this one.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "row": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Display group of elements in a compact row."
            }
        }
    },
    "formhelpertext": {
        "displayName": "FormHelperText",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component.\r\n\nIf `' '` is provided, the component reserves one line height for displaying a future message."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the helper text should be displayed in a disabled state."
            },
            "error": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, helper text should be displayed in an error state."
            },
            "filled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the helper text should use filled classes key."
            },
            "focused": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the helper text should use focused classes key."
            },
            "margin": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'dense'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "If `dense`, will adjust vertical spacing. This is normally obtained via context from\r\nFormControl."
            },
            "required": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the helper text should use required classes key."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'standard'",
                            "computed": false
                        },
                        {
                            "value": "'outlined'",
                            "computed": false
                        },
                        {
                            "value": "'filled'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "formlabel": {
        "displayName": "FormLabel",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the label should be displayed in a disabled state."
            },
            "error": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the label should be displayed in an error state."
            },
            "filled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the label should use filled classes key."
            },
            "focused": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input of this label is focused (used by `FormGroup` components)."
            },
            "required": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the label will indicate that the input is required."
            }
        }
    },
    "grid": {
        "displayName": "Grid",
        "description": "",
        "methods": [],
        "props": {
            "alignContent": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'stretch'",
                            "computed": false
                        },
                        {
                            "value": "'center'",
                            "computed": false
                        },
                        {
                            "value": "'flex-start'",
                            "computed": false
                        },
                        {
                            "value": "'flex-end'",
                            "computed": false
                        },
                        {
                            "value": "'space-between'",
                            "computed": false
                        },
                        {
                            "value": "'space-around'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Defines the `align-content` style property.\r\nIt's applied for all screen sizes."
            },
            "alignItems": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'flex-start'",
                            "computed": false
                        },
                        {
                            "value": "'center'",
                            "computed": false
                        },
                        {
                            "value": "'flex-end'",
                            "computed": false
                        },
                        {
                            "value": "'stretch'",
                            "computed": false
                        },
                        {
                            "value": "'baseline'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Defines the `align-items` style property.\r\nIt's applied for all screen sizes."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "container": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component will have the flex *container* behavior.\r\nYou should be wrapping *items* with a *container*."
            },
            "direction": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'row'",
                            "computed": false
                        },
                        {
                            "value": "'row-reverse'",
                            "computed": false
                        },
                        {
                            "value": "'column'",
                            "computed": false
                        },
                        {
                            "value": "'column-reverse'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Defines the `flex-direction` style property.\r\nIt is applied for all screen sizes."
            },
            "item": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component will have the flex *item* behavior.\r\nYou should be wrapping *items* with a *container*."
            },
            "justify": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'flex-start'",
                            "computed": false
                        },
                        {
                            "value": "'center'",
                            "computed": false
                        },
                        {
                            "value": "'flex-end'",
                            "computed": false
                        },
                        {
                            "value": "'space-between'",
                            "computed": false
                        },
                        {
                            "value": "'space-around'",
                            "computed": false
                        },
                        {
                            "value": "'space-evenly'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Defines the `justify-content` style property.\r\nIt is applied for all screen sizes."
            },
            "lg": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "false",
                            "computed": false
                        },
                        {
                            "value": "'auto'",
                            "computed": false
                        },
                        {
                            "value": "true",
                            "computed": false
                        },
                        {
                            "value": "1",
                            "computed": false
                        },
                        {
                            "value": "2",
                            "computed": false
                        },
                        {
                            "value": "3",
                            "computed": false
                        },
                        {
                            "value": "4",
                            "computed": false
                        },
                        {
                            "value": "5",
                            "computed": false
                        },
                        {
                            "value": "6",
                            "computed": false
                        },
                        {
                            "value": "7",
                            "computed": false
                        },
                        {
                            "value": "8",
                            "computed": false
                        },
                        {
                            "value": "9",
                            "computed": false
                        },
                        {
                            "value": "10",
                            "computed": false
                        },
                        {
                            "value": "11",
                            "computed": false
                        },
                        {
                            "value": "12",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Defines the number of grids the component is going to use.\r\nIt's applied for the `lg` breakpoint and wider screens if not overridden."
            },
            "md": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "false",
                            "computed": false
                        },
                        {
                            "value": "'auto'",
                            "computed": false
                        },
                        {
                            "value": "true",
                            "computed": false
                        },
                        {
                            "value": "1",
                            "computed": false
                        },
                        {
                            "value": "2",
                            "computed": false
                        },
                        {
                            "value": "3",
                            "computed": false
                        },
                        {
                            "value": "4",
                            "computed": false
                        },
                        {
                            "value": "5",
                            "computed": false
                        },
                        {
                            "value": "6",
                            "computed": false
                        },
                        {
                            "value": "7",
                            "computed": false
                        },
                        {
                            "value": "8",
                            "computed": false
                        },
                        {
                            "value": "9",
                            "computed": false
                        },
                        {
                            "value": "10",
                            "computed": false
                        },
                        {
                            "value": "11",
                            "computed": false
                        },
                        {
                            "value": "12",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Defines the number of grids the component is going to use.\r\nIt's applied for the `md` breakpoint and wider screens if not overridden."
            },
            "sm": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "false",
                            "computed": false
                        },
                        {
                            "value": "'auto'",
                            "computed": false
                        },
                        {
                            "value": "true",
                            "computed": false
                        },
                        {
                            "value": "1",
                            "computed": false
                        },
                        {
                            "value": "2",
                            "computed": false
                        },
                        {
                            "value": "3",
                            "computed": false
                        },
                        {
                            "value": "4",
                            "computed": false
                        },
                        {
                            "value": "5",
                            "computed": false
                        },
                        {
                            "value": "6",
                            "computed": false
                        },
                        {
                            "value": "7",
                            "computed": false
                        },
                        {
                            "value": "8",
                            "computed": false
                        },
                        {
                            "value": "9",
                            "computed": false
                        },
                        {
                            "value": "10",
                            "computed": false
                        },
                        {
                            "value": "11",
                            "computed": false
                        },
                        {
                            "value": "12",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Defines the number of grids the component is going to use.\r\nIt's applied for the `sm` breakpoint and wider screens if not overridden."
            },
            "spacing": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "0",
                            "computed": false
                        },
                        {
                            "value": "1",
                            "computed": false
                        },
                        {
                            "value": "2",
                            "computed": false
                        },
                        {
                            "value": "3",
                            "computed": false
                        },
                        {
                            "value": "4",
                            "computed": false
                        },
                        {
                            "value": "5",
                            "computed": false
                        },
                        {
                            "value": "6",
                            "computed": false
                        },
                        {
                            "value": "7",
                            "computed": false
                        },
                        {
                            "value": "8",
                            "computed": false
                        },
                        {
                            "value": "9",
                            "computed": false
                        },
                        {
                            "value": "10",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Defines the space between the type `item` component.\r\nIt can only be used on a type `container` component."
            },
            "wrap": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'nowrap'",
                            "computed": false
                        },
                        {
                            "value": "'wrap'",
                            "computed": false
                        },
                        {
                            "value": "'wrap-reverse'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Defines the `flex-wrap` style property.\r\nIt's applied for all screen sizes."
            },
            "xl": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "false",
                            "computed": false
                        },
                        {
                            "value": "'auto'",
                            "computed": false
                        },
                        {
                            "value": "true",
                            "computed": false
                        },
                        {
                            "value": "1",
                            "computed": false
                        },
                        {
                            "value": "2",
                            "computed": false
                        },
                        {
                            "value": "3",
                            "computed": false
                        },
                        {
                            "value": "4",
                            "computed": false
                        },
                        {
                            "value": "5",
                            "computed": false
                        },
                        {
                            "value": "6",
                            "computed": false
                        },
                        {
                            "value": "7",
                            "computed": false
                        },
                        {
                            "value": "8",
                            "computed": false
                        },
                        {
                            "value": "9",
                            "computed": false
                        },
                        {
                            "value": "10",
                            "computed": false
                        },
                        {
                            "value": "11",
                            "computed": false
                        },
                        {
                            "value": "12",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Defines the number of grids the component is going to use.\r\nIt's applied for the `xl` breakpoint and wider screens."
            },
            "xs": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "false",
                            "computed": false
                        },
                        {
                            "value": "'auto'",
                            "computed": false
                        },
                        {
                            "value": "true",
                            "computed": false
                        },
                        {
                            "value": "1",
                            "computed": false
                        },
                        {
                            "value": "2",
                            "computed": false
                        },
                        {
                            "value": "3",
                            "computed": false
                        },
                        {
                            "value": "4",
                            "computed": false
                        },
                        {
                            "value": "5",
                            "computed": false
                        },
                        {
                            "value": "6",
                            "computed": false
                        },
                        {
                            "value": "7",
                            "computed": false
                        },
                        {
                            "value": "8",
                            "computed": false
                        },
                        {
                            "value": "9",
                            "computed": false
                        },
                        {
                            "value": "10",
                            "computed": false
                        },
                        {
                            "value": "11",
                            "computed": false
                        },
                        {
                            "value": "12",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Defines the number of grids the component is going to use.\r\nIt's applied for all the screen sizes with the lowest priority."
            },
            "zeroMinWidth": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, it sets `min-width: 0` on the item.\r\nRefer to the limitations section of the documentation to better understand the use case."
            }
        }
    },
    "gridlist": {
        "displayName": "GridList",
        "description": "",
        "methods": [],
        "props": {
            "cellHeight": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "enum",
                            "value": [
                                {
                                    "value": "'auto'",
                                    "computed": false
                                }
                            ]
                        }
                    ]
                },
                "required": false,
                "description": "Number of px for one cell height.\r\nYou can set `'auto'` if you want to let the children determine the height."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "Grid Tiles that will be in Grid List."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "cols": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Number of columns."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "spacing": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Number of px for the spacing between tiles."
            },
            "style": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "gridlisttile": {
        "displayName": "GridListTile",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Theoretically you can pass any node as children, but the main use case is to pass an img,\r\nin which case GridListTile takes care of making the image \"cover\" available space\r\n(similar to `background-size: cover` or to `object-fit: cover`)."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "cols": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Width of the tile in number of grid cells."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "rows": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Height of the tile in number of grid cells."
            }
        }
    },
    "gridlisttilebar": {
        "displayName": "GridListTileBar",
        "description": "",
        "methods": [],
        "props": {
            "actionIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "An IconButton element to be used as secondary action target\r\n(primary action target is the tile itself)."
            },
            "actionPosition": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'left'",
                            "computed": false
                        },
                        {
                            "value": "'right'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Position of secondary action IconButton."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "subtitle": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "String or element serving as subtitle (support text)."
            },
            "title": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Title to be displayed on tile."
            },
            "titlePosition": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'top'",
                            "computed": false
                        },
                        {
                            "value": "'bottom'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Position of the title bar."
            }
        }
    },
    "hidden": {
        "displayName": "Hidden",
        "description": "Responsively hides children based on the selected implementation.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "implementation": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'js'",
                            "computed": false
                        },
                        {
                            "value": "'css'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Specify which implementation to use.  'js' is the default, 'css' works better for\r\nserver-side rendering."
            },
            "initialWidth": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'xs'",
                            "computed": false
                        },
                        {
                            "value": "'sm'",
                            "computed": false
                        },
                        {
                            "value": "'md'",
                            "computed": false
                        },
                        {
                            "value": "'lg'",
                            "computed": false
                        },
                        {
                            "value": "'xl'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "You can use this prop when choosing the `js` implementation with server-side rendering.\r\n\nAs `window.innerWidth` is unavailable on the server,\r\nwe default to rendering an empty component during the first mount.\r\nYou might want to use an heuristic to approximate\r\nthe screen width of the client browser screen width.\r\n\nFor instance, you could be using the user-agent or the client-hints.\r\nhttps://caniuse.com/#search=client%20hint"
            },
            "lgDown": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, screens this size and down will be hidden."
            },
            "lgUp": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, screens this size and up will be hidden."
            },
            "mdDown": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, screens this size and down will be hidden."
            },
            "mdUp": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, screens this size and up will be hidden."
            },
            "only": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "enum",
                            "value": [
                                {
                                    "value": "'xs'",
                                    "computed": false
                                },
                                {
                                    "value": "'sm'",
                                    "computed": false
                                },
                                {
                                    "value": "'md'",
                                    "computed": false
                                },
                                {
                                    "value": "'lg'",
                                    "computed": false
                                },
                                {
                                    "value": "'xl'",
                                    "computed": false
                                }
                            ]
                        },
                        {
                            "name": "arrayOf",
                            "value": {
                                "name": "enum",
                                "value": [
                                    {
                                        "value": "'xs'",
                                        "computed": false
                                    },
                                    {
                                        "value": "'sm'",
                                        "computed": false
                                    },
                                    {
                                        "value": "'md'",
                                        "computed": false
                                    },
                                    {
                                        "value": "'lg'",
                                        "computed": false
                                    },
                                    {
                                        "value": "'xl'",
                                        "computed": false
                                    }
                                ]
                            }
                        }
                    ]
                },
                "required": false,
                "description": "Hide the given breakpoint(s)."
            },
            "smDown": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, screens this size and down will be hidden."
            },
            "smUp": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, screens this size and up will be hidden."
            },
            "xlDown": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, screens this size and down will be hidden."
            },
            "xlUp": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, screens this size and up will be hidden."
            },
            "xsDown": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, screens this size and down will be hidden."
            },
            "xsUp": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, screens this size and up will be hidden."
            }
        }
    },
    "icon": {
        "displayName": "Icon",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The name of the icon font ligature."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'inherit'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        },
                        {
                            "value": "'action'",
                            "computed": false
                        },
                        {
                            "value": "'error'",
                            "computed": false
                        },
                        {
                            "value": "'disabled'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "fontSize": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'inherit'",
                            "computed": false
                        },
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'large'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The fontSize applied to the icon. Defaults to 24px, but can be configure to inherit font size."
            }
        }
    },
    "iconbutton": {
        "displayName": "IconButton",
        "description": "Refer to the [Icons](/components/icons/) section of the documentation\r\nregarding the available icon options.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "custom",
                    "raw": "chainPropTypes(PropTypes.node, props => {\r\n  const found = React.Children.toArray(props.children).some(\r\n    child => React.isValidElement(child) && child.props.onClick,\r\n  );\r\n\r\n  if (found) {\r\n    return new Error(\r\n      [\r\n        'Material-UI: you are providing an onClick event listener ' +\r\n          'to a child of a button element.',\r\n        'Firefox will never trigger the event.',\r\n        'You should move the onClick listener to the parent button element.',\r\n        'https://github.com/mui-org/material-ui/issues/13957',\r\n      ].join('\\n'),\r\n    );\r\n  }\r\n\r\n  return null;\r\n})"
                },
                "required": false,
                "description": "The icon element."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the button will be disabled."
            },
            "disableFocusRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the  keyboard focus ripple will be disabled.\r\n`disableRipple` must also be true."
            },
            "disableRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the ripple effect will be disabled."
            },
            "edge": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'start'",
                            "computed": false
                        },
                        {
                            "value": "'end'",
                            "computed": false
                        },
                        {
                            "value": "false",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "If given, uses a negative margin to counteract the padding on one\r\nside (this is often helpful for aligning the left or right\r\nside of the icon with content above or below, without ruining the border\r\nsize and shape)."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The size of the button.\r\n`small` is equivalent to the dense button styling."
            }
        }
    },
    "input": {
        "displayName": "Input",
        "description": "",
        "methods": [],
        "props": {
            "autoComplete": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "This prop helps users to fill forms faster, especially on mobile devices.\r\nThe name can be confusing, as it's more like an autofill.\r\nYou can learn more about it [following the specification](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofill)."
            },
            "autoFocus": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be focused during the first mount."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The CSS class name of the wrapper element."
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "defaultValue": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The default `input` element value. Use when the component is not controlled."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be disabled."
            },
            "disableUnderline": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input will not have an underline."
            },
            "endAdornment": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "End `InputAdornment` for this component."
            },
            "error": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input will indicate an error. This is normally obtained via context from\r\nFormControl."
            },
            "fullWidth": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input will take up the full width of its container."
            },
            "id": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The id of the `input` element."
            },
            "inputComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the native input.\r\nEither a string to use a DOM element or a component."
            },
            "inputProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "[Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Attributes) applied to the `input` element."
            },
            "inputRef": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "Pass a ref to the `input` element."
            },
            "margin": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'dense'",
                            "computed": false
                        },
                        {
                            "value": "'none'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "If `dense`, will adjust vertical spacing. This is normally obtained via context from\r\nFormControl."
            },
            "multiline": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, a textarea element will be rendered."
            },
            "name": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Name attribute of the `input` element."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the value is changed.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new value by accessing `event.target.value` (string)."
            },
            "placeholder": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The short hint displayed in the input before the user enters a value."
            },
            "readOnly": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "It prevents the user from changing the value of the field\r\n(not from interacting with the field)."
            },
            "required": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be required."
            },
            "rows": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Number of rows to display when multiline option is set to true."
            },
            "rowsMax": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Maximum number of rows to display when multiline option is set to true."
            },
            "startAdornment": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Start `InputAdornment` for this component."
            },
            "type": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Type of the `input` element. It should be [a valid HTML5 input type](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Form_%3Cinput%3E_types)."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The value of the `input` element, required for a controlled component."
            }
        }
    },
    "inputadornment": {
        "displayName": "InputAdornment",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "The content of the component, normally an `IconButton` or string."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "disablePointerEvents": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Disable pointer events on the root.\r\nThis allows for the content of the adornment to focus the input on click."
            },
            "disableTypography": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If children is a string then disable wrapping in a Typography component."
            },
            "muiFormControl": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "@ignore"
            },
            "position": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'start'",
                            "computed": false
                        },
                        {
                            "value": "'end'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The position this adornment should appear relative to the `Input`."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'standard'",
                            "computed": false
                        },
                        {
                            "value": "'outlined'",
                            "computed": false
                        },
                        {
                            "value": "'filled'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use.\r\nNote: If you are using the `TextField` component or the `FormControl` component\r\nyou do not have to set this manually."
            }
        }
    },
    "inputbase": {
        "displayName": "InputBase",
        "description": "`InputBase` contains as few styles as possible.\r\nIt aims to be a simple building block for creating an input.\r\nIt contains a load of style reset and some state logic.",
        "methods": [],
        "props": {
            "aria-describedby": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "autoComplete": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "This prop helps users to fill forms faster, especially on mobile devices.\r\nThe name can be confusing, as it's more like an autofill.\r\nYou can learn more about it [following the specification](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofill)."
            },
            "autoFocus": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be focused during the first mount."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The CSS class name of the wrapper element."
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "defaultValue": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The default `input` element value. Use when the component is not controlled."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be disabled."
            },
            "endAdornment": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "End `InputAdornment` for this component."
            },
            "error": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input will indicate an error. This is normally obtained via context from\r\nFormControl."
            },
            "fullWidth": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input will take up the full width of its container."
            },
            "id": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The id of the `input` element."
            },
            "inputComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the `input` element.\r\nEither a string to use a DOM element or a component."
            },
            "inputProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "[Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Attributes) applied to the `input` element."
            },
            "inputRef": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "Pass a ref to the `input` element."
            },
            "margin": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'dense'",
                            "computed": false
                        },
                        {
                            "value": "'none'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "If `dense`, will adjust vertical spacing. This is normally obtained via context from\r\nFormControl."
            },
            "multiline": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, a textarea element will be rendered."
            },
            "name": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Name attribute of the `input` element."
            },
            "onBlur": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the input is blurred.\r\n\nNotice that the first argument (event) might be undefined."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the value is changed.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new value by accessing `event.target.value` (string)."
            },
            "onClick": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onFocus": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onKeyDown": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onKeyUp": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "placeholder": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The short hint displayed in the input before the user enters a value."
            },
            "readOnly": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "It prevents the user from changing the value of the field\r\n(not from interacting with the field)."
            },
            "renderSuffix": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "required": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be required."
            },
            "rows": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Number of rows to display when multiline option is set to true."
            },
            "rowsMax": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Maximum number of rows to display when multiline option is set to true."
            },
            "rowsMin": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Minimum number of rows to display when multiline option is set to true."
            },
            "startAdornment": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Start `InputAdornment` for this component."
            },
            "type": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Type of the `input` element. It should be [a valid HTML5 input type](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Form_%3Cinput%3E_types)."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The value of the `input` element, required for a controlled component."
            }
        }
    },
    "inputlabel": {
        "displayName": "InputLabel",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The contents of the `InputLabel`."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "disableAnimation": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the transition animation is disabled."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, apply disabled class."
            },
            "error": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the label will be displayed in an error state."
            },
            "focused": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input of this label is focused."
            },
            "margin": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'dense'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "If `dense`, will adjust vertical spacing. This is normally obtained via context from\r\nFormControl."
            },
            "required": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "if `true`, the label will indicate that the input is required."
            },
            "shrink": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the label is shrunk."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'standard'",
                            "computed": false
                        },
                        {
                            "value": "'outlined'",
                            "computed": false
                        },
                        {
                            "value": "'filled'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "linearprogress": {
        "displayName": "LinearProgress",
        "description": "## ARIA\r\n\nIf the progress bar is describing the loading progress of a particular region of a page,\r\nyou should use `aria-describedby` to point to the progress bar, and set the `aria-busy`\r\nattribute to `true` on that region until it has finished loading.",
        "methods": [],
        "props": {
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "value": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The value of the progress indicator for the determinate and buffer variants.\r\nValue between 0 and 100."
            },
            "valueBuffer": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The value for the buffer variant.\r\nValue between 0 and 100."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'determinate'",
                            "computed": false
                        },
                        {
                            "value": "'indeterminate'",
                            "computed": false
                        },
                        {
                            "value": "'buffer'",
                            "computed": false
                        },
                        {
                            "value": "'query'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use.\r\nUse indeterminate or query when there is no progress value."
            }
        }
    },
    "link": {
        "displayName": "Link",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "The content of the link."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'error'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        },
                        {
                            "value": "'textPrimary'",
                            "computed": false
                        },
                        {
                            "value": "'textSecondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the link."
            },
            "component": {
                "type": {
                    "name": "custom",
                    "raw": "elementTypeAcceptingRef"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "onBlur": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onFocus": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "TypographyClasses": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "`classes` prop applied to the [`Typography`](/api/typography/) element."
            },
            "underline": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'none'",
                            "computed": false
                        },
                        {
                            "value": "'hover'",
                            "computed": false
                        },
                        {
                            "value": "'always'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Controls when the link should have an underline."
            },
            "variant": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Applies the theme typography styles."
            }
        }
    },
    "list": {
        "displayName": "List",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "dense": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, compact vertical padding designed for keyboard and mouse input will be used for\r\nthe list and list items.\r\nThe prop is available to descendant components as the `dense` context."
            },
            "disablePadding": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, vertical padding will be removed from the list."
            },
            "subheader": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the subheader, normally `ListSubheader`."
            }
        }
    },
    "listitem": {
        "displayName": "ListItem",
        "description": "Uses an additional container component if `ListItemSecondaryAction` is the last child.",
        "methods": [],
        "props": {
            "alignItems": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'flex-start'",
                            "computed": false
                        },
                        {
                            "value": "'center'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Defines the `align-items` style property."
            },
            "autoFocus": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the list item will be focused during the first mount.\r\nFocus will also be triggered if the value changes from false to true."
            },
            "button": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the list item will be a button (using `ButtonBase`). Props intended\r\nfor `ButtonBase` can then be applied to `ListItem`."
            },
            "children": {
                "type": {
                    "name": "custom",
                    "raw": "chainPropTypes(PropTypes.node, props => {\r\n  const children = React.Children.toArray(props.children);\r\n\r\n  // React.Children.toArray(props.children).findLastIndex(isListItemSecondaryAction)\r\n  let secondaryActionIndex = -1;\r\n  for (let i = children.length - 1; i >= 0; i -= 1) {\r\n    const child = children[i];\r\n    if (isMuiElement(child, ['ListItemSecondaryAction'])) {\r\n      secondaryActionIndex = i;\r\n      break;\r\n    }\r\n  }\r\n\r\n  //  is ListItemSecondaryAction the last child of ListItem\r\n  if (secondaryActionIndex !== -1 && secondaryActionIndex !== children.length - 1) {\r\n    return new Error(\r\n      'Material-UI: you used an element after ListItemSecondaryAction. ' +\r\n        'For ListItem to detect that it has a secondary action ' +\r\n        'you must pass it as the last child to ListItem.',\r\n    );\r\n  }\r\n\r\n  return null;\r\n})"
                },
                "required": false,
                "description": "The content of the component. If a `ListItemSecondaryAction` is used it must\r\nbe the last child."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component.\r\nBy default, it's a `li` when `button` is `false` and a `div` when `button` is `true`."
            },
            "ContainerComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The container component used when a `ListItemSecondaryAction` is the last child."
            },
            "ContainerProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the container component if used."
            },
            "dense": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, compact vertical padding designed for keyboard and mouse input will be used."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the list item will be disabled."
            },
            "disableGutters": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the left and right padding is removed."
            },
            "divider": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, a 1px light border is added to the bottom of the list item."
            },
            "focusVisibleClassName": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "selected": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Use to apply selected styling."
            }
        }
    },
    "listitemavatar": {
        "displayName": "ListItemAvatar",
        "description": "A simple wrapper to apply `List` styles to an `Avatar`.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "element"
                },
                "required": true,
                "description": "The content of the component – normally `Avatar`."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "listitemicon": {
        "displayName": "ListItemIcon",
        "description": "A simple wrapper to apply `List` styles to an `Icon` or `SvgIcon`.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "element"
                },
                "required": true,
                "description": "The content of the component, normally `Icon`, `SvgIcon`,\r\nor a `@material-ui/icons` SVG icon element."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "listitemsecondaryaction": {
        "displayName": "ListItemSecondaryAction",
        "description": "Must be used as the last child of ListItem to function properly.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component, normally an `IconButton` or selection control."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "listitemtext": {
        "displayName": "ListItemText",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Alias for the `primary` property."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "disableTypography": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the children won't be wrapped by a Typography component.\r\nThis can be useful to render an alternative Typography variant by wrapping\r\nthe `children` (or `primary`) text, and optional `secondary` text\r\nwith the Typography component."
            },
            "inset": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the children will be indented.\r\nThis should be used if there is no left avatar or left icon."
            },
            "primary": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The main content element."
            },
            "primaryTypographyProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "These props will be forwarded to the primary typography component\r\n(as long as disableTypography is not `true`)."
            },
            "secondary": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The secondary content element."
            },
            "secondaryTypographyProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "These props will be forwarded to the secondary typography component\r\n(as long as disableTypography is not `true`)."
            }
        }
    },
    "listsubheader": {
        "displayName": "ListSubheader",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "disableGutters": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the List Subheader will not have gutters."
            },
            "disableSticky": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the List Subheader will not stick to the top during scroll."
            },
            "inset": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the List Subheader will be indented."
            }
        }
    },
    "menu": {
        "displayName": "Menu",
        "description": "",
        "methods": [],
        "props": {
            "anchorEl": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "object"
                        },
                        {
                            "name": "func"
                        }
                    ]
                },
                "required": false,
                "description": "The DOM element used to set the position of the menu."
            },
            "autoFocus": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true` (Default) will focus the `[role=\"menu\"]` if no focusable child is found. Disabled\r\nchildren are not focusable. If you set this prop to `false` focus will be placed\r\non the parent modal container. This has severe accessibility implications\r\nand should only be considered if you manage focus otherwise."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Menu contents, normally `MenuItem`s."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "disableAutoFocusItem": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "When opening the menu will not focus the active item but the `[role=\"menu\"]`\r\nunless `autoFocus` is also set to `false`. Not using the default means not\r\nfollowing WAI-ARIA authoring practices. Please be considerate about possible\r\naccessibility implications."
            },
            "MenuListProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`MenuList`](/api/menu-list/) element."
            },
            "onClose": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"escapeKeyDown\"`, `\"backdropClick\"`, `\"tabKeyDown\"`."
            },
            "onEnter": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired before the Menu enters."
            },
            "onEntered": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the Menu has entered."
            },
            "onEntering": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the Menu is entering."
            },
            "onExit": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired before the Menu exits."
            },
            "onExited": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the Menu has exited."
            },
            "onExiting": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the Menu is exiting."
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": true,
                "description": "If `true`, the menu is visible."
            },
            "PaperProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "@ignore"
            },
            "PopoverClasses": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "`classes` prop applied to the [`Popover`](/api/popover/) element."
            },
            "transitionDuration": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "shape",
                            "value": {
                                "enter": {
                                    "name": "number",
                                    "required": false
                                },
                                "exit": {
                                    "name": "number",
                                    "required": false
                                }
                            }
                        },
                        {
                            "name": "enum",
                            "value": [
                                {
                                    "value": "'auto'",
                                    "computed": false
                                }
                            ]
                        }
                    ]
                },
                "required": false,
                "description": "The length of the transition in `ms`, or 'auto'"
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'menu'",
                            "computed": false
                        },
                        {
                            "value": "'selectedMenu'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use. Use `menu` to prevent selected items from impacting the initial focus\r\nand the vertical alignment relative to the anchor element."
            }
        }
    },
    "menuitem": {
        "displayName": "MenuItem",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Menu item contents."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "dense": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, compact vertical padding designed for keyboard and mouse input will be used."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "disableGutters": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the left and right padding is removed."
            },
            "role": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "selected": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "tabIndex": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "menulist": {
        "displayName": "MenuList",
        "description": "A permanently displayed menu following https://www.w3.org/TR/wai-aria-practices/#menubutton\r\nIt's exposed to help customization of the [`Menu`](/api/menu/) component. If you\r\nuse it separately you need to move focus into the component manually. Once\r\nthe focus is placed inside the component it is fully keyboard accessible.",
        "methods": [],
        "props": {
            "actions": {
                "type": {
                    "name": "shape",
                    "value": {
                        "current": {
                            "name": "object",
                            "required": false
                        }
                    }
                },
                "required": false,
                "description": "@ignore"
            },
            "autoFocus": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, will focus the `[role=\"menu\"]` container and move into tab order"
            },
            "autoFocusItem": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, will focus the first menuitem if `variant=\"menu\"` or selected item\r\nif `variant=\"selectedMenu\"`"
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "MenuList contents, normally `MenuItem`s."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "disableListWrap": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the menu items will not wrap focus."
            },
            "onKeyDown": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'menu'",
                            "computed": false
                        },
                        {
                            "value": "'selectedMenu'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use. Use `menu` to prevent selected items from impacting the initial focus\r\nand the vertical alignment relative to the anchor element."
            }
        }
    },
    "mobilestepper": {
        "displayName": "MobileStepper",
        "description": "",
        "methods": [],
        "props": {
            "activeStep": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Set the active step (zero based index).\r\nDefines which dot is highlighted when the variant is 'dots'."
            },
            "backButton": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "A back button element. For instance, it can be a `Button` or an `IconButton`."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "LinearProgressProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the `LinearProgress` element."
            },
            "nextButton": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "A next button element. For instance, it can be a `Button` or an `IconButton`."
            },
            "position": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'bottom'",
                            "computed": false
                        },
                        {
                            "value": "'top'",
                            "computed": false
                        },
                        {
                            "value": "'static'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Set the positioning type."
            },
            "steps": {
                "type": {
                    "name": "number"
                },
                "required": true,
                "description": "The total steps."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'text'",
                            "computed": false
                        },
                        {
                            "value": "'dots'",
                            "computed": false
                        },
                        {
                            "value": "'progress'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "modal": {
        "displayName": "Modal",
        "description": "Modal is a lower-level construct that is leveraged by the following components:\r\n\n- [Dialog](/api/dialog/)\r\n- [Drawer](/api/drawer/)\r\n- [Menu](/api/menu/)\r\n- [Popover](/api/popover/)\r\n\nIf you are creating a modal dialog, you probably want to use the [Dialog](/api/dialog/) component\r\nrather than directly using Modal.\r\n\nThis component shares many concepts with [react-overlays](https://react-bootstrap.github.io/react-overlays/#modals).",
        "methods": [],
        "props": {
            "BackdropComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "A backdrop component. This prop enables custom backdrop rendering."
            },
            "BackdropProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Backdrop`](/api/backdrop/) element."
            },
            "children": {
                "type": {
                    "name": "custom",
                    "raw": "elementAcceptingRef.isRequired"
                },
                "required": false,
                "description": "A single child content element."
            },
            "closeAfterTransition": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "When set to true the Modal waits until a nested Transition is completed before closing."
            },
            "container": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "object"
                        },
                        {
                            "name": "func"
                        }
                    ]
                },
                "required": false,
                "description": "A node, component instance, or function that returns either.\r\nThe `container` will have the portal children appended to it."
            },
            "disableAutoFocus": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the modal will not automatically shift focus to itself when it opens, and\r\nreplace it to the last focused element when it closes.\r\nThis also works correctly with any modal children that have the `disableAutoFocus` prop.\r\n\nGenerally this should never be set to `true` as it makes the modal less\r\naccessible to assistive technologies, like screen readers."
            },
            "disableBackdropClick": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, clicking the backdrop will not fire any callback."
            },
            "disableEnforceFocus": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the modal will not prevent focus from leaving the modal while open.\r\n\nGenerally this should never be set to `true` as it makes the modal less\r\naccessible to assistive technologies, like screen readers."
            },
            "disableEscapeKeyDown": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, hitting escape will not fire any callback."
            },
            "disablePortal": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Disable the portal behavior.\r\nThe children stay within it's parent DOM hierarchy."
            },
            "disableRestoreFocus": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the modal will not restore focus to previously focused element once\r\nmodal is hidden."
            },
            "disableScrollLock": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Disable the scroll lock behavior."
            },
            "hideBackdrop": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the backdrop is not rendered."
            },
            "keepMounted": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Always keep the children in the DOM.\r\nThis prop can be useful in SEO situation or\r\nwhen you want to maximize the responsiveness of the Modal."
            },
            "manager": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "@ignore"
            },
            "onBackdropClick": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the backdrop is clicked."
            },
            "onClose": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component requests to be closed.\r\nThe `reason` parameter can optionally be used to control the response to `onClose`.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"escapeKeyDown\"`, `\"backdropClick\"`."
            },
            "onEscapeKeyDown": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the escape key is pressed,\r\n`disableEscapeKeyDown` is false and the modal is in focus."
            },
            "onRendered": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired once the children has been mounted into the `container`.\r\nIt signals that the `open={true}` prop took effect.\r\n\nThis prop will be deprecated and removed in v5, the ref can be used instead."
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": true,
                "description": "If `true`, the modal is open."
            }
        }
    },
    "nativeselect": {
        "displayName": "NativeSelect",
        "description": "An alternative to `<Select native />` with a much smaller bundle size footprint.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The option elements to populate the select with.\r\nCan be some `<option>` elements."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "IconComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The icon that displays the arrow."
            },
            "input": {
                "type": {
                    "name": "element"
                },
                "required": false,
                "description": "An `Input` element; does not have to be a material-ui specific `Input`."
            },
            "inputProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Attributes applied to the `select` element."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback function fired when a menu item is selected.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new value by accessing `event.target.value` (string)."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The input value. The DOM API casts this to a string."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'standard'",
                            "computed": false
                        },
                        {
                            "value": "'outlined'",
                            "computed": false
                        },
                        {
                            "value": "'filled'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "nossr": {
        "displayName": "NoSsr",
        "description": "NoSsr purposely removes components from the subject of Server Side Rendering (SSR).\r\n\nThis component can be useful in a variety of situations:\r\n- Escape hatch for broken dependencies not supporting SSR.\r\n- Improve the time-to-first paint on the client by only rendering above the fold.\r\n- Reduce the rendering time on the server.\r\n- Under too heavy server load, you can turn on service degradation.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "You can wrap a node."
            },
            "defer": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component will not only prevent server-side rendering.\r\nIt will also defer the rendering of the children into a different screen frame."
            },
            "fallback": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The fallback content to display."
            }
        }
    },
    "outlinedinput": {
        "displayName": "OutlinedInput",
        "description": "",
        "methods": [],
        "props": {
            "autoComplete": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "This prop helps users to fill forms faster, especially on mobile devices.\r\nThe name can be confusing, as it's more like an autofill.\r\nYou can learn more about it [following the specification](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofill)."
            },
            "autoFocus": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be focused during the first mount."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The CSS class name of the wrapper element."
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "defaultValue": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The default `input` element value. Use when the component is not controlled."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be disabled."
            },
            "endAdornment": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "End `InputAdornment` for this component."
            },
            "error": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input will indicate an error. This is normally obtained via context from\r\nFormControl."
            },
            "fullWidth": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input will take up the full width of its container."
            },
            "id": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The id of the `input` element."
            },
            "inputComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the native input.\r\nEither a string to use a DOM element or a component."
            },
            "inputProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "[Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Attributes) applied to the `input` element."
            },
            "inputRef": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "Pass a ref to the `input` element."
            },
            "label": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The label of the input. It is only used for layout. The actual labelling\r\nis handled by `InputLabel`. If specified `labelWidth` is ignored."
            },
            "labelWidth": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The width of the label. Is ignored if `label` is provided. Prefer `label`\r\nif the input label appears with a strike through."
            },
            "margin": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'dense'",
                            "computed": false
                        },
                        {
                            "value": "'none'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "If `dense`, will adjust vertical spacing. This is normally obtained via context from\r\nFormControl."
            },
            "multiline": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, a textarea element will be rendered."
            },
            "name": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Name attribute of the `input` element."
            },
            "notched": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the outline is notched to accommodate the label."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the value is changed.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new value by accessing `event.target.value` (string)."
            },
            "placeholder": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The short hint displayed in the input before the user enters a value."
            },
            "readOnly": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "It prevents the user from changing the value of the field\r\n(not from interacting with the field)."
            },
            "required": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be required."
            },
            "rows": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Number of rows to display when multiline option is set to true."
            },
            "rowsMax": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Maximum number of rows to display when multiline option is set to true."
            },
            "startAdornment": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Start `InputAdornment` for this component."
            },
            "type": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Type of the `input` element. It should be [a valid HTML5 input type](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Form_%3Cinput%3E_types)."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The value of the `input` element, required for a controlled component."
            }
        }
    },
    "paper": {
        "displayName": "Paper",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "elevation": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Shadow depth, corresponds to `dp` in the spec.\r\nIt accepts values between 0 and 24 inclusive."
            },
            "square": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, rounded corners are disabled."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'elevation'",
                            "computed": false
                        },
                        {
                            "value": "'outlined'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "popover": {
        "displayName": "Popover",
        "description": "",
        "methods": [],
        "props": {
            "action": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "A ref for imperative actions.\r\nIt currently only supports updatePosition() action."
            },
            "anchorEl": {
                "type": {
                    "name": "custom",
                    "raw": "chainPropTypes(PropTypes.oneOfType([PropTypes.object, PropTypes.func]), props => {\r\n  if (props.open && (!props.anchorReference || props.anchorReference === 'anchorEl')) {\r\n    const resolvedAnchorEl = getAnchorEl(props.anchorEl);\r\n    const containerWindow = ownerWindow(resolvedAnchorEl);\r\n\r\n    if (resolvedAnchorEl instanceof containerWindow.Element) {\r\n      const box = resolvedAnchorEl.getBoundingClientRect();\r\n\r\n      if (\r\n        process.env.NODE_ENV !== 'test' &&\r\n        box.top === 0 &&\r\n        box.left === 0 &&\r\n        box.right === 0 &&\r\n        box.bottom === 0\r\n      ) {\r\n        return new Error(\r\n          [\r\n            'Material-UI: the `anchorEl` prop provided to the component is invalid.',\r\n            'The anchor element should be part of the document layout.',\r\n            \"Make sure the element is present in the document or that it's not display none.\",\r\n          ].join('\\n'),\r\n        );\r\n      }\r\n    } else {\r\n      return new Error(\r\n        [\r\n          'Material-UI: the `anchorEl` prop provided to the component is invalid.',\r\n          `It should be an Element instance but it's \\`${resolvedAnchorEl}\\` instead.`,\r\n        ].join('\\n'),\r\n      );\r\n    }\r\n  }\r\n\r\n  return null;\r\n})"
                },
                "required": false,
                "description": "This is the DOM element, or a function that returns the DOM element,\r\nthat may be used to set the position of the popover."
            },
            "anchorOrigin": {
                "type": {
                    "name": "shape",
                    "value": {
                        "horizontal": {
                            "name": "union",
                            "value": [
                                {
                                    "name": "number"
                                },
                                {
                                    "name": "enum",
                                    "value": [
                                        {
                                            "value": "'left'",
                                            "computed": false
                                        },
                                        {
                                            "value": "'center'",
                                            "computed": false
                                        },
                                        {
                                            "value": "'right'",
                                            "computed": false
                                        }
                                    ]
                                }
                            ],
                            "required": true
                        },
                        "vertical": {
                            "name": "union",
                            "value": [
                                {
                                    "name": "number"
                                },
                                {
                                    "name": "enum",
                                    "value": [
                                        {
                                            "value": "'top'",
                                            "computed": false
                                        },
                                        {
                                            "value": "'center'",
                                            "computed": false
                                        },
                                        {
                                            "value": "'bottom'",
                                            "computed": false
                                        }
                                    ]
                                }
                            ],
                            "required": true
                        }
                    }
                },
                "required": false,
                "description": "This is the point on the anchor where the popover's\r\n`anchorEl` will attach to. This is not used when the\r\nanchorReference is 'anchorPosition'.\r\n\nOptions:\r\nvertical: [top, center, bottom];\r\nhorizontal: [left, center, right]."
            },
            "anchorPosition": {
                "type": {
                    "name": "shape",
                    "value": {
                        "left": {
                            "name": "number",
                            "required": true
                        },
                        "top": {
                            "name": "number",
                            "required": true
                        }
                    }
                },
                "required": false,
                "description": "This is the position that may be used\r\nto set the position of the popover.\r\nThe coordinates are relative to\r\nthe application's client area."
            },
            "anchorReference": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'anchorEl'",
                            "computed": false
                        },
                        {
                            "value": "'anchorPosition'",
                            "computed": false
                        },
                        {
                            "value": "'none'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": ""
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "container": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "object"
                        },
                        {
                            "name": "func"
                        }
                    ]
                },
                "required": false,
                "description": "A node, component instance, or function that returns either.\r\nThe `container` will passed to the Modal component.\r\nBy default, it uses the body of the anchorEl's top-level document object,\r\nso it's simply `document.body` most of the time."
            },
            "elevation": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The elevation of the popover."
            },
            "getContentAnchorEl": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "This function is called in order to retrieve the content anchor element.\r\nIt's the opposite of the `anchorEl` prop.\r\nThe content anchor element should be an element inside the popover.\r\nIt's used to correctly scroll and set the position of the popover.\r\nThe positioning strategy tries to make the content anchor element just above the\r\nanchor element."
            },
            "marginThreshold": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Specifies how close to the edge of the window the popover can appear."
            },
            "onClose": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"escapeKeyDown\"`, `\"backdropClick\"`."
            },
            "onEnter": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired before the component is entering."
            },
            "onEntered": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component has entered."
            },
            "onEntering": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component is entering."
            },
            "onExit": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired before the component is exiting."
            },
            "onExited": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component has exited."
            },
            "onExiting": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component is exiting."
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": true,
                "description": "If `true`, the popover is visible."
            },
            "PaperProps": {
                "type": {
                    "name": "shape",
                    "value": {
                        "component": {
                            "name": "custom",
                            "raw": "elementTypeAcceptingRef",
                            "required": false
                        }
                    }
                },
                "required": false,
                "description": "Props applied to the [`Paper`](/api/paper/) element."
            },
            "transformOrigin": {
                "type": {
                    "name": "shape",
                    "value": {
                        "horizontal": {
                            "name": "union",
                            "value": [
                                {
                                    "name": "number"
                                },
                                {
                                    "name": "enum",
                                    "value": [
                                        {
                                            "value": "'left'",
                                            "computed": false
                                        },
                                        {
                                            "value": "'center'",
                                            "computed": false
                                        },
                                        {
                                            "value": "'right'",
                                            "computed": false
                                        }
                                    ]
                                }
                            ],
                            "required": true
                        },
                        "vertical": {
                            "name": "union",
                            "value": [
                                {
                                    "name": "number"
                                },
                                {
                                    "name": "enum",
                                    "value": [
                                        {
                                            "value": "'top'",
                                            "computed": false
                                        },
                                        {
                                            "value": "'center'",
                                            "computed": false
                                        },
                                        {
                                            "value": "'bottom'",
                                            "computed": false
                                        }
                                    ]
                                }
                            ],
                            "required": true
                        }
                    }
                },
                "required": false,
                "description": "This is the point on the popover which\r\nwill attach to the anchor's origin.\r\n\nOptions:\r\nvertical: [top, center, bottom, x(px)];\r\nhorizontal: [left, center, right, x(px)]."
            },
            "TransitionComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
            },
            "transitionDuration": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "shape",
                            "value": {
                                "enter": {
                                    "name": "number",
                                    "required": false
                                },
                                "exit": {
                                    "name": "number",
                                    "required": false
                                }
                            }
                        },
                        {
                            "name": "enum",
                            "value": [
                                {
                                    "value": "'auto'",
                                    "computed": false
                                }
                            ]
                        }
                    ]
                },
                "required": false,
                "description": "Set to 'auto' to automatically calculate transition time based on height."
            },
            "TransitionProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
            }
        }
    },
    "popper": {
        "displayName": "Popper",
        "description": "Poppers rely on the 3rd party library [Popper.js](https://github.com/FezVrasta/popper.js) for positioning.",
        "methods": [],
        "props": {
            "anchorEl": {
                "type": {
                    "name": "custom",
                    "raw": "chainPropTypes(PropTypes.oneOfType([PropTypes.object, PropTypes.func]), props => {\r\n  if (props.open) {\r\n    const resolvedAnchorEl = getAnchorEl(props.anchorEl);\r\n    const containerWindow = ownerWindow(resolvedAnchorEl);\r\n\r\n    if (resolvedAnchorEl instanceof containerWindow.Element) {\r\n      const box = resolvedAnchorEl.getBoundingClientRect();\r\n\r\n      if (\r\n        process.env.NODE_ENV !== 'test' &&\r\n        box.top === 0 &&\r\n        box.left === 0 &&\r\n        box.right === 0 &&\r\n        box.bottom === 0\r\n      ) {\r\n        return new Error(\r\n          [\r\n            'Material-UI: the `anchorEl` prop provided to the component is invalid.',\r\n            'The anchor element should be part of the document layout.',\r\n            \"Make sure the element is present in the document or that it's not display none.\",\r\n          ].join('\\n'),\r\n        );\r\n      }\r\n    } else if (\r\n      !resolvedAnchorEl ||\r\n      typeof resolvedAnchorEl.clientWidth !== 'number' ||\r\n      typeof resolvedAnchorEl.clientHeight !== 'number' ||\r\n      typeof resolvedAnchorEl.getBoundingClientRect !== 'function'\r\n    ) {\r\n      return new Error(\r\n        [\r\n          'Material-UI: the `anchorEl` prop provided to the component is invalid.',\r\n          'It should be an HTML Element instance or a referenceObject:',\r\n          'https://popper.js.org/popper-documentation.html#referenceObject.',\r\n        ].join('\\n'),\r\n      );\r\n    }\r\n  }\r\n\r\n  return null;\r\n})"
                },
                "required": false,
                "description": "This is the reference element, or a function that returns the reference element,\r\nthat may be used to set the position of the popover.\r\nThe return value will passed as the reference object of the Popper\r\ninstance.\r\n\nThe reference element should be an HTML Element instance or a referenceObject:\r\nhttps://popper.js.org/popper-documentation.html#referenceObject."
            },
            "children": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "node"
                        },
                        {
                            "name": "func"
                        }
                    ]
                },
                "required": true,
                "description": "Popper render function or node."
            },
            "container": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "object"
                        },
                        {
                            "name": "func"
                        }
                    ]
                },
                "required": false,
                "description": "A node, component instance, or function that returns either.\r\nThe `container` will passed to the Modal component.\r\nBy default, it uses the body of the anchorEl's top-level document object,\r\nso it's simply `document.body` most of the time."
            },
            "disablePortal": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Disable the portal behavior.\r\nThe children stay within it's parent DOM hierarchy."
            },
            "keepMounted": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Always keep the children in the DOM.\r\nThis prop can be useful in SEO situation or\r\nwhen you want to maximize the responsiveness of the Popper."
            },
            "modifiers": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Popper.js is based on a \"plugin-like\" architecture,\r\nmost of its features are fully encapsulated \"modifiers\".\r\n\nA modifier is a function that is called each time Popper.js needs to\r\ncompute the position of the popper.\r\nFor this reason, modifiers should be very performant to avoid bottlenecks.\r\nTo learn how to create a modifier, [read the modifiers documentation](https://github.com/FezVrasta/popper.js/blob/master/docs/_includes/popper-documentation.md#modifiers--object)."
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": true,
                "description": "If `true`, the popper is visible."
            },
            "placement": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'bottom-end'",
                            "computed": false
                        },
                        {
                            "value": "'bottom-start'",
                            "computed": false
                        },
                        {
                            "value": "'bottom'",
                            "computed": false
                        },
                        {
                            "value": "'left-end'",
                            "computed": false
                        },
                        {
                            "value": "'left-start'",
                            "computed": false
                        },
                        {
                            "value": "'left'",
                            "computed": false
                        },
                        {
                            "value": "'right-end'",
                            "computed": false
                        },
                        {
                            "value": "'right-start'",
                            "computed": false
                        },
                        {
                            "value": "'right'",
                            "computed": false
                        },
                        {
                            "value": "'top-end'",
                            "computed": false
                        },
                        {
                            "value": "'top-start'",
                            "computed": false
                        },
                        {
                            "value": "'top'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Popper placement."
            },
            "popperOptions": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Options provided to the [`popper.js`](https://github.com/FezVrasta/popper.js) instance."
            },
            "popperRef": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "A ref that points to the used popper instance."
            },
            "transition": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Help supporting a react-transition-group/Transition component."
            }
        }
    },
    "portal": {
        "displayName": "Portal",
        "description": "Portals provide a first-class way to render children into a DOM node\r\nthat exists outside the DOM hierarchy of the parent component.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The children to render into the `container`."
            },
            "container": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "func"
                        },
                        {
                            "name": "instanceOf",
                            "value": "React.Component"
                        },
                        {
                            "name": "instanceOf",
                            "value": "typeof Element === 'undefined' ? Object : Element"
                        }
                    ]
                },
                "required": false,
                "description": "A node, component instance, or function that returns either.\r\nThe `container` will have the portal children appended to it.\r\nBy default, it uses the body of the top-level document object,\r\nso it's simply `document.body` most of the time."
            },
            "disablePortal": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Disable the portal behavior.\r\nThe children stay within it's parent DOM hierarchy."
            },
            "onRendered": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired once the children has been mounted into the `container`.\r\n\nThis prop will be deprecated and removed in v5, the ref can be used instead."
            }
        }
    },
    "radio": {
        "displayName": "Radio",
        "description": "",
        "methods": [],
        "props": {
            "checked": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component is checked."
            },
            "checkedIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display when the component is checked."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        },
                        {
                            "value": "'default'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the switch will be disabled."
            },
            "disableRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the ripple effect will be disabled."
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display when the component is unchecked."
            },
            "id": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The id of the `input` element."
            },
            "inputProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "[Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Attributes) applied to the `input` element."
            },
            "inputRef": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "Pass a ref to the `input` element."
            },
            "name": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Name attribute of the `input` element."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the state is changed.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new value by accessing `event.target.value` (string).\r\nYou can pull out the new checked state by accessing `event.target.checked` (boolean)."
            },
            "required": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be required."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The size of the radio.\r\n`small` is equivalent to the dense radio styling."
            },
            "type": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The input component prop `type`."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The value of the component. The DOM API casts this to a string."
            }
        }
    },
    "radiogroup": {
        "displayName": "RadioGroup",
        "description": "",
        "methods": [],
        "props": {
            "actions": {
                "type": {
                    "name": "shape",
                    "value": {
                        "current": {
                            "name": "object",
                            "required": false
                        }
                    }
                },
                "required": false,
                "description": "@ignore"
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "defaultValue": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The default `input` element value. Use when the component is not controlled."
            },
            "name": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The name used to reference the value of the control."
            },
            "onBlur": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when a radio button is selected.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new value by accessing `event.target.value` (string)."
            },
            "onKeyDown": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "Value of the selected radio button. The DOM API casts this to a string."
            }
        }
    },
    "rootref": {
        "displayName": "RootRef",
        "description": "⚠️⚠️⚠️\r\nIf you want the DOM element of a Material-UI component check out\r\n[FAQ: How can I access the DOM element?](/getting-started/faq/#how-can-i-access-the-dom-element)\r\nfirst.\r\n\nThis component uses `findDOMNode` which is deprecated in React.StrictMode.\r\n\nHelper component to allow attaching a ref to a\r\nwrapped element to access the underlying DOM element.\r\n\nIt's highly inspired by https://github.com/facebook/react/issues/11401#issuecomment-340543801.\r\nFor example:\r\n```jsx\r\nimport React from 'react';\r\nimport RootRef from '@material-ui/core/RootRef';\r\n\nfunction MyComponent() {\r\n  const domRef = React.useRef();\r\n\n  React.useEffect(() => {\r\n    console.log(domRef.current); // DOM node\r\n  }, []);\r\n\n  return (\r\n    <RootRef rootRef={domRef}>\r\n      <SomeChildComponent />\r\n    </RootRef>\r\n  );\r\n}\r\n```",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "element"
                },
                "required": true,
                "description": "The wrapped element."
            },
            "rootRef": {
                "type": {
                    "name": "custom",
                    "raw": "refType.isRequired"
                },
                "required": false,
                "description": "A ref that points to the first DOM node of the wrapped element."
            }
        }
    },
    "select": {
        "displayName": "Select",
        "description": "",
        "methods": [],
        "props": {
            "autoWidth": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the width of the popover will automatically be set according to the items inside the\r\nmenu, otherwise it will be at least the width of the select input."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The option elements to populate the select with.\r\nCan be some `MenuItem` when `native` is false and `option` when `native` is true.\r\n\n⚠️The `MenuItem` elements **must** be direct descendants when `native` is false."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "defaultValue": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The default element value. Use when the component is not controlled."
            },
            "displayEmpty": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, a value is displayed even if no items are selected.\r\n\nIn order to display a meaningful value, a function should be passed to the `renderValue` prop which returns the value to be displayed when no items are selected.\r\nYou can only use it when the `native` prop is `false` (default)."
            },
            "IconComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The icon that displays the arrow."
            },
            "id": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "input": {
                "type": {
                    "name": "element"
                },
                "required": false,
                "description": "An `Input` element; does not have to be a material-ui specific `Input`."
            },
            "inputProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "[Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Attributes) applied to the `input` element.\r\nWhen `native` is `true`, the attributes are applied on the `select` element."
            },
            "label": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "See [OutlinedLabel#label](/api/outlined-input/#props)"
            },
            "labelId": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The idea of an element that acts as an additional label. The Select will\r\nbe labelled by the additional label and the selected value."
            },
            "labelWidth": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "See OutlinedLabel#label"
            },
            "MenuProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Menu`](/api/menu/) element."
            },
            "multiple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, `value` must be an array and the menu will support multiple selections."
            },
            "native": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component will be using a native `select` element."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback function fired when a menu item is selected.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new value by accessing `event.target.value` (any).\r\n@param {object} [child] The react element that was selected when `native` is `false` (default)."
            },
            "onClose": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component requests to be closed.\r\nUse in controlled mode (see open).\r\n\n@param {object} event The event source of the callback."
            },
            "onOpen": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component requests to be opened.\r\nUse in controlled mode (see open).\r\n\n@param {object} event The event source of the callback."
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Control `select` open state.\r\nYou can only use it when the `native` prop is `false` (default)."
            },
            "renderValue": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Render the selected value.\r\nYou can only use it when the `native` prop is `false` (default).\r\n\n@param {any} value The `value` provided to the component.\r\n@returns {ReactNode}"
            },
            "SelectDisplayProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the clickable div element."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The input value. Providing an empty string will select no options.\r\nThis prop is required when the `native` prop is `false` (default).\r\nSet to an empty string `''` if you don't want any of the available options to be selected.\r\n\nIf the value is an object it must have reference equality with the option in order to be selected.\r\nIf the value is not an object, the string representation must match with the string representation of the option in order to be selected."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'standard'",
                            "computed": false
                        },
                        {
                            "value": "'outlined'",
                            "computed": false
                        },
                        {
                            "value": "'filled'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "slide": {
        "displayName": "Slide",
        "description": "The Slide transition is used by the [Drawer](/components/drawers/) component.\r\nIt uses [react-transition-group](https://github.com/reactjs/react-transition-group) internally.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "custom",
                    "raw": "elementAcceptingRef"
                },
                "required": false,
                "description": "A single child content element."
            },
            "direction": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'left'",
                            "computed": false
                        },
                        {
                            "value": "'right'",
                            "computed": false
                        },
                        {
                            "value": "'up'",
                            "computed": false
                        },
                        {
                            "value": "'down'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Direction the child node will enter from."
            },
            "in": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, show the component; triggers the enter or exit animation."
            },
            "onEnter": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onEntering": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onExit": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onExited": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "style": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "@ignore"
            },
            "timeout": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "shape",
                            "value": {
                                "enter": {
                                    "name": "number",
                                    "required": false
                                },
                                "exit": {
                                    "name": "number",
                                    "required": false
                                }
                            }
                        }
                    ]
                },
                "required": false,
                "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
            }
        }
    },
    "slider": {
        "displayName": "Slider",
        "description": "",
        "methods": [],
        "props": {
            "aria-label": {
                "type": {
                    "name": "custom",
                    "raw": "chainPropTypes(PropTypes.string, props => {\r\n  const range = Array.isArray(props.value || props.defaultValue);\r\n\r\n  if (range && props['aria-label'] != null) {\r\n    return new Error(\r\n      'Material-UI: you need to use the `getAriaLabel` prop instead of `aria-label` when using a range slider.',\r\n    );\r\n  }\r\n\r\n  return null;\r\n})"
                },
                "required": false,
                "description": "The label of the slider."
            },
            "aria-labelledby": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The id of the element containing a label for the slider."
            },
            "aria-valuetext": {
                "type": {
                    "name": "custom",
                    "raw": "chainPropTypes(PropTypes.string, props => {\r\n  const range = Array.isArray(props.value || props.defaultValue);\r\n\r\n  if (range && props['aria-valuetext'] != null) {\r\n    return new Error(\r\n      'Material-UI: you need to use the `getAriaValueText` prop instead of `aria-valuetext` when using a range slider.',\r\n    );\r\n  }\r\n\r\n  return null;\r\n})"
                },
                "required": false,
                "description": "A string value that provides a user-friendly name for the current value of the slider."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "defaultValue": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "arrayOf",
                            "value": {
                                "name": "number"
                            }
                        }
                    ]
                },
                "required": false,
                "description": "The default element value. Use when the component is not controlled."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the slider will be disabled."
            },
            "getAriaLabel": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Accepts a function which returns a string value that provides a user-friendly name for the thumb labels of the slider.\r\n\n@param {number} index The thumb label's index to format.\r\n@returns {string}"
            },
            "getAriaValueText": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Accepts a function which returns a string value that provides a user-friendly name for the current value of the slider.\r\n\n@param {number} value The thumb label's value to format.\r\n@param {number} index The thumb label's index to format.\r\n@returns {string}"
            },
            "marks": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "bool"
                        },
                        {
                            "name": "array"
                        }
                    ]
                },
                "required": false,
                "description": "Marks indicate predetermined values to which the user can move the slider.\r\nIf `true` the marks will be spaced according the value of the `step` prop.\r\nIf an array, it should contain objects with `value` and an optional `label` keys."
            },
            "max": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The maximum allowed value of the slider.\r\nShould not be equal to min."
            },
            "min": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The minimum allowed value of the slider.\r\nShould not be equal to max."
            },
            "name": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Name attribute of the hidden `input` element."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback function that is fired when the slider's value changed.\r\n\n@param {object} event The event source of the callback.\r\n@param {any} value The new value."
            },
            "onChangeCommitted": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback function that is fired when the `mouseup` is triggered.\r\n\n@param {object} event The event source of the callback.\r\n@param {any} value The new value."
            },
            "onMouseDown": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "orientation": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'horizontal'",
                            "computed": false
                        },
                        {
                            "value": "'vertical'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The slider orientation."
            },
            "scale": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "A transformation function, to change the scale of the slider."
            },
            "step": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The granularity with which the slider can step through values. (A \"discrete\" slider.)\r\nThe `min` prop serves as the origin for the valid values.\r\nWe recommend (max - min) to be evenly divisible by the step.\r\n\nWhen step is `null`, the thumb can only be slid onto marks provided with the `marks` prop."
            },
            "ThumbComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used to display the value label."
            },
            "track": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'normal'",
                            "computed": false
                        },
                        {
                            "value": "false",
                            "computed": false
                        },
                        {
                            "value": "'inverted'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The track presentation:\r\n\n- `normal` the track will render a bar representing the slider value.\r\n- `inverted` the track will render a bar representing the remaining slider value.\r\n- `false` the track will render without a bar."
            },
            "value": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "arrayOf",
                            "value": {
                                "name": "number"
                            }
                        }
                    ]
                },
                "required": false,
                "description": "The value of the slider.\r\nFor ranged sliders, provide an array with two values."
            },
            "ValueLabelComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The value label component."
            },
            "valueLabelDisplay": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'on'",
                            "computed": false
                        },
                        {
                            "value": "'auto'",
                            "computed": false
                        },
                        {
                            "value": "'off'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Controls when the value label is displayed:\r\n\n- `auto` the value label will display when the thumb is hovered or focused.\r\n- `on` will display persistently.\r\n- `off` will never display."
            },
            "valueLabelFormat": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "func"
                        }
                    ]
                },
                "required": false,
                "description": "The format function the value label's value.\r\n\nWhen a function is provided, it should have the following signature:\r\n\n- {number} value The value label's value to format\r\n- {number} index The value label's index to format"
            }
        }
    },
    "snackbar": {
        "displayName": "Snackbar",
        "description": "",
        "methods": [],
        "props": {
            "action": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The action to display. It renders after the message, at the end of the snackbar."
            },
            "anchorOrigin": {
                "type": {
                    "name": "shape",
                    "value": {
                        "horizontal": {
                            "name": "enum",
                            "value": [
                                {
                                    "value": "'left'",
                                    "computed": false
                                },
                                {
                                    "value": "'center'",
                                    "computed": false
                                },
                                {
                                    "value": "'right'",
                                    "computed": false
                                }
                            ],
                            "required": true
                        },
                        "vertical": {
                            "name": "enum",
                            "value": [
                                {
                                    "value": "'top'",
                                    "computed": false
                                },
                                {
                                    "value": "'bottom'",
                                    "computed": false
                                }
                            ],
                            "required": true
                        }
                    }
                },
                "required": false,
                "description": "The anchor of the `Snackbar`."
            },
            "autoHideDuration": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The number of milliseconds to wait before automatically calling the\r\n`onClose` function. `onClose` should then set the state of the `open`\r\nprop to hide the Snackbar. This behavior is disabled by default with\r\nthe `null` value."
            },
            "children": {
                "type": {
                    "name": "element"
                },
                "required": false,
                "description": "Replace the `SnackbarContent` component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "ClickAwayListenerProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the `ClickAwayListener` element."
            },
            "ContentProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`SnackbarContent`](/api/snackbar-content/) element."
            },
            "disableWindowBlurListener": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `autoHideDuration` timer will expire even if the window is not focused."
            },
            "key": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "When displaying multiple consecutive Snackbars from a parent rendering a single\r\n<Snackbar/>, add the key prop to ensure independent treatment of each message.\r\ne.g. <Snackbar key={message} />, otherwise, the message may update-in-place and\r\nfeatures such as autoHideDuration may be canceled."
            },
            "message": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The message to display."
            },
            "onClose": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component requests to be closed.\r\nTypically `onClose` is used to set state in the parent component,\r\nwhich is used to control the `Snackbar` `open` prop.\r\nThe `reason` parameter can optionally be used to control the response to `onClose`,\r\nfor example ignoring `clickaway`.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"timeout\"` (`autoHideDuration` expired), `\"clickaway\"`."
            },
            "onEnter": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired before the transition is entering."
            },
            "onEntered": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the transition has entered."
            },
            "onEntering": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the transition is entering."
            },
            "onExit": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired before the transition is exiting."
            },
            "onExited": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the transition has exited."
            },
            "onExiting": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the transition is exiting."
            },
            "onMouseEnter": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onMouseLeave": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, `Snackbar` is open."
            },
            "resumeHideDuration": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The number of milliseconds to wait before dismissing after user interaction.\r\nIf `autoHideDuration` prop isn't specified, it does nothing.\r\nIf `autoHideDuration` prop is specified but `resumeHideDuration` isn't,\r\nwe default to `autoHideDuration / 2` ms."
            },
            "TransitionComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
            },
            "transitionDuration": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "shape",
                            "value": {
                                "enter": {
                                    "name": "number",
                                    "required": false
                                },
                                "exit": {
                                    "name": "number",
                                    "required": false
                                }
                            }
                        }
                    ]
                },
                "required": false,
                "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
            },
            "TransitionProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
            }
        }
    },
    "snackbarcontent": {
        "displayName": "SnackbarContent",
        "description": "",
        "methods": [],
        "props": {
            "action": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The action to display. It renders after the message, at the end of the snackbar."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "message": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The message to display."
            },
            "role": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The ARIA role attribute of the element."
            }
        }
    },
    "step": {
        "displayName": "Step",
        "description": "",
        "methods": [],
        "props": {
            "active": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Sets the step as active. Is passed to child components."
            },
            "alternativeLabel": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore\r\nSet internally by Stepper when it's supplied with the alternativeLabel property."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Should be `Step` sub-components such as `StepLabel`, `StepContent`."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "completed": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Mark the step as completed. Is passed to child components."
            },
            "connector": {
                "type": {
                    "name": "element"
                },
                "required": false,
                "description": "@ignore\r\nPassed down from Stepper if alternativeLabel is also set."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Mark the step as disabled, will also disable the button if\r\n`StepButton` is a child of `Step`. Is passed to child components."
            },
            "expanded": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Expand the step."
            },
            "index": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "@ignore\r\nUsed internally for numbering."
            },
            "last": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "orientation": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'horizontal'",
                            "computed": false
                        },
                        {
                            "value": "'vertical'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "stepbutton": {
        "displayName": "StepButton",
        "description": "",
        "methods": [],
        "props": {
            "active": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore\r\nPassed in via `Step` - passed through to `StepLabel`."
            },
            "alternativeLabel": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore\r\nSet internally by Stepper when it's supplied with the alternativeLabel property."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Can be a `StepLabel` or a node to place inside `StepLabel` as children."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "completed": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore\r\nSets completed styling. Is passed to StepLabel."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore\r\nDisables the button and sets disabled styling. Is passed to StepLabel."
            },
            "expanded": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore\r\npotentially passed from parent `Step`"
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon displayed by the step label."
            },
            "last": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "optional": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The optional node to display."
            },
            "orientation": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'horizontal'",
                            "computed": false
                        },
                        {
                            "value": "'vertical'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "stepconnector": {
        "displayName": "StepConnector",
        "description": "",
        "methods": [],
        "props": {
            "active": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "alternativeLabel": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore\r\nSet internally by Step when it's supplied with the alternativeLabel property."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "completed": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "index": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "@ignore"
            },
            "orientation": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'horizontal'",
                            "computed": false
                        },
                        {
                            "value": "'vertical'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "stepcontent": {
        "displayName": "StepContent",
        "description": "",
        "methods": [],
        "props": {
            "active": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore\r\nExpands the content."
            },
            "alternativeLabel": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore\r\nSet internally by Step when it's supplied with the alternativeLabel prop."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Step content."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "completed": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "expanded": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "last": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "optional": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore\r\nSet internally by Step when it's supplied with the optional prop."
            },
            "orientation": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'horizontal'",
                            "computed": false
                        },
                        {
                            "value": "'vertical'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "@ignore"
            },
            "TransitionComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
            },
            "transitionDuration": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "shape",
                            "value": {
                                "enter": {
                                    "name": "number",
                                    "required": false
                                },
                                "exit": {
                                    "name": "number",
                                    "required": false
                                }
                            }
                        },
                        {
                            "name": "enum",
                            "value": [
                                {
                                    "value": "'auto'",
                                    "computed": false
                                }
                            ]
                        }
                    ]
                },
                "required": false,
                "description": "Adjust the duration of the content expand transition.\r\nPassed as a prop to the transition component.\r\n\nSet to 'auto' to automatically calculate transition time based on height."
            },
            "TransitionProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
            }
        }
    },
    "stepicon": {
        "displayName": "StepIcon",
        "description": "",
        "methods": [],
        "props": {
            "active": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Whether this step is active."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "completed": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Mark the step as completed. Is passed to child components."
            },
            "error": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Mark the step as failed."
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "The label displayed in the step icon."
            }
        }
    },
    "steplabel": {
        "displayName": "StepLabel",
        "description": "",
        "methods": [],
        "props": {
            "active": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "alternativeLabel": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "In most cases will simply be a string containing a title for the label."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "completed": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Mark the step as disabled, will also disable the button if\r\n`StepLabelButton` is a child of `StepLabel`. Is passed to child components."
            },
            "error": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Mark the step as failed."
            },
            "expanded": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Override the default label of the step icon."
            },
            "last": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "optional": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The optional node to display."
            },
            "orientation": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'horizontal'",
                            "computed": false
                        },
                        {
                            "value": "'vertical'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "@ignore"
            },
            "StepIconComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component to render in place of the [`StepIcon`](/api/step-icon/)."
            },
            "StepIconProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`StepIcon`](/api/step-icon/) element."
            }
        }
    },
    "stepper": {
        "displayName": "Stepper",
        "description": "",
        "methods": [],
        "props": {
            "activeStep": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Set the active step (zero based index).\r\nSet to -1 to disable all the steps."
            },
            "alternativeLabel": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If set to 'true' and orientation is horizontal,\r\nthen the step label will be positioned under the icon."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "Two or more `<Step />` components."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "connector": {
                "type": {
                    "name": "element"
                },
                "required": false,
                "description": "An element to be placed between each step."
            },
            "nonLinear": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If set the `Stepper` will not assist in controlling steps for linear flow."
            },
            "orientation": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'horizontal'",
                            "computed": false
                        },
                        {
                            "value": "'vertical'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The stepper orientation (layout flow direction)."
            }
        }
    },
    "svgicon": {
        "displayName": "SvgIcon",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Node passed into the SVG element."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'action'",
                            "computed": false
                        },
                        {
                            "value": "'disabled'",
                            "computed": false
                        },
                        {
                            "value": "'error'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component.\r\nYou can use the `htmlColor` prop to apply a color attribute to the SVG element."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "fontSize": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        },
                        {
                            "value": "'large'",
                            "computed": false
                        },
                        {
                            "value": "'small'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The fontSize applied to the icon. Defaults to 24px, but can be configure to inherit font size."
            },
            "htmlColor": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Applies a color attribute to the SVG element."
            },
            "shapeRendering": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The shape-rendering attribute. The behavior of the different options is described on the\r\n[MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/shape-rendering).\r\nIf you are having issues with blurry icons you should investigate this property."
            },
            "titleAccess": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Provides a human-readable title for the element that contains it.\r\nhttps://www.w3.org/TR/SVG-access/#Equivalent"
            },
            "viewBox": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Allows you to redefine what the coordinates without units mean inside an SVG element.\r\nFor example, if the SVG element is 500 (width) by 200 (height),\r\nand you pass viewBox=\"0 0 50 20\",\r\nthis means that the coordinates inside the SVG will go from the top left corner (0,0)\r\nto bottom right (50,20) and each unit will be worth 10px."
            }
        }
    },
    "swipeabledrawer": {
        "displayName": "SwipeableDrawer",
        "description": "",
        "methods": [],
        "props": {
            "anchor": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'left'",
                            "computed": false
                        },
                        {
                            "value": "'top'",
                            "computed": false
                        },
                        {
                            "value": "'right'",
                            "computed": false
                        },
                        {
                            "value": "'bottom'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "@ignore"
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "disableBackdropTransition": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Disable the backdrop transition.\r\nThis can improve the FPS on low-end devices."
            },
            "disableDiscovery": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, touching the screen near the edge of the drawer will not slide in the drawer a bit\r\nto promote accidental discovery of the swipe gesture."
            },
            "disableSwipeToOpen": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, swipe to open is disabled. This is useful in browsers where swiping triggers\r\nnavigation actions. Swipe to open is disabled on iOS browsers by default."
            },
            "hideBackdrop": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "hysteresis": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Affects how far the drawer must be opened/closed to change his state.\r\nSpecified as percent (0-1) of the width of the drawer"
            },
            "minFlingVelocity": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Defines, from which (average) velocity on, the swipe is\r\ndefined as complete although hysteresis isn't reached.\r\nGood threshold is between 250 - 1000 px/s"
            },
            "ModalProps": {
                "type": {
                    "name": "shape",
                    "value": {
                        "BackdropProps": {
                            "name": "shape",
                            "value": {
                                "component": {
                                    "name": "custom",
                                    "raw": "elementTypeAcceptingRef",
                                    "required": false
                                }
                            },
                            "required": false
                        }
                    }
                },
                "required": false,
                "description": "@ignore"
            },
            "onClose": {
                "type": {
                    "name": "func"
                },
                "required": true,
                "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback."
            },
            "onOpen": {
                "type": {
                    "name": "func"
                },
                "required": true,
                "description": "Callback fired when the component requests to be opened.\r\n\n@param {object} event The event source of the callback."
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": true,
                "description": "If `true`, the drawer is open."
            },
            "PaperProps": {
                "type": {
                    "name": "shape",
                    "value": {
                        "component": {
                            "name": "custom",
                            "raw": "elementTypeAcceptingRef",
                            "required": false
                        },
                        "style": {
                            "name": "object",
                            "required": false
                        }
                    }
                },
                "required": false,
                "description": "@ignore"
            },
            "SwipeAreaProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the swipe area element."
            },
            "swipeAreaWidth": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The width of the left most (or right most) area in pixels where the\r\ndrawer can be swiped open from."
            },
            "transitionDuration": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "shape",
                            "value": {
                                "enter": {
                                    "name": "number",
                                    "required": false
                                },
                                "exit": {
                                    "name": "number",
                                    "required": false
                                }
                            }
                        }
                    ]
                },
                "required": false,
                "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'permanent'",
                            "computed": false
                        },
                        {
                            "value": "'persistent'",
                            "computed": false
                        },
                        {
                            "value": "'temporary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "switch": {
        "displayName": "Switch",
        "description": "",
        "methods": [],
        "props": {
            "checked": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component is checked."
            },
            "checkedIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display when the component is checked."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        },
                        {
                            "value": "'default'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "defaultChecked": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the switch will be disabled."
            },
            "disableRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the ripple effect will be disabled."
            },
            "edge": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'start'",
                            "computed": false
                        },
                        {
                            "value": "'end'",
                            "computed": false
                        },
                        {
                            "value": "false",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "If given, uses a negative margin to counteract the padding on one\r\nside (this is often helpful for aligning the left or right\r\nside of the icon with content above or below, without ruining the border\r\nsize and shape)."
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display when the component is unchecked."
            },
            "id": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The id of the `input` element."
            },
            "inputProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "[Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Attributes) applied to the `input` element."
            },
            "inputRef": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "Pass a ref to the `input` element."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the state is changed.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new checked state by accessing `event.target.checked` (boolean)."
            },
            "required": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be required."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The size of the switch.\r\n`small` is equivalent to the dense switch styling."
            },
            "type": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The input component prop `type`."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The value of the component. The DOM API casts this to a string."
            }
        }
    },
    "tab": {
        "displayName": "Tab",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "custom",
                    "raw": "unsupportedProp"
                },
                "required": false,
                "description": "This prop isn't supported.\r\nUse the `component` prop if you need to change the children structure."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the tab will be disabled."
            },
            "disableFocusRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the  keyboard focus ripple will be disabled.\r\n`disableRipple` must also be true."
            },
            "disableRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the ripple effect will be disabled."
            },
            "fullWidth": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon element."
            },
            "indicator": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "@ignore\r\nFor server-side rendering consideration, we let the selected tab\r\nrender the indicator."
            },
            "label": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The label element."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onClick": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "selected": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "textColor": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'secondary'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "@ignore"
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "You can provide your own value. Otherwise, we fallback to the child position index."
            },
            "wrapped": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Tab labels appear in a single row.\r\nThey can use a second line if needed."
            }
        }
    },
    "table": {
        "displayName": "Table",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "The content of the table, normally `TableHead` and `TableBody`."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "padding": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'checkbox'",
                            "computed": false
                        },
                        {
                            "value": "'none'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Allows TableCells to inherit padding of the Table."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Allows TableCells to inherit size of the Table."
            },
            "stickyHeader": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Set the header sticky.\r\n\n⚠️ It doesn't work with IE 11."
            }
        }
    },
    "tablebody": {
        "displayName": "TableBody",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component, normally `TableRow`."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            }
        }
    },
    "tablecell": {
        "displayName": "TableCell",
        "description": "The component renders a `<th>` element when the parent context is a header\r\nor otherwise a `<td>` element.",
        "methods": [],
        "props": {
            "align": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'inherit'",
                            "computed": false
                        },
                        {
                            "value": "'left'",
                            "computed": false
                        },
                        {
                            "value": "'center'",
                            "computed": false
                        },
                        {
                            "value": "'right'",
                            "computed": false
                        },
                        {
                            "value": "'justify'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Set the text-align on the table cell content.\r\n\nMonetary or generally number fields **should be right aligned** as that allows\r\nyou to add them up quickly in your head without having to worry about decimals."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The table cell contents."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "padding": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'default'",
                            "computed": false
                        },
                        {
                            "value": "'checkbox'",
                            "computed": false
                        },
                        {
                            "value": "'none'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Sets the padding applied to the cell.\r\nBy default, the Table parent component set the value (`default`)."
            },
            "scope": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Set scope attribute."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Specify the size of the cell.\r\nBy default, the Table parent component set the value (`medium`)."
            },
            "sortDirection": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'asc'",
                            "computed": false
                        },
                        {
                            "value": "'desc'",
                            "computed": false
                        },
                        {
                            "value": "false",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Set aria-sort direction."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'head'",
                            "computed": false
                        },
                        {
                            "value": "'body'",
                            "computed": false
                        },
                        {
                            "value": "'footer'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Specify the cell type.\r\nBy default, the TableHead, TableBody or TableFooter parent component set the value."
            }
        }
    },
    "tablecontainer": {
        "displayName": "TableContainer",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The table itself, normally `<Table />`"
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            }
        }
    },
    "tablefooter": {
        "displayName": "TableFooter",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component, normally `TableRow`."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            }
        }
    },
    "tablehead": {
        "displayName": "TableHead",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component, normally `TableRow`."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            }
        }
    },
    "tablepagination": {
        "displayName": "TablePagination",
        "description": "A `TableCell` based component for placing inside `TableFooter` for pagination.",
        "methods": [],
        "props": {
            "ActionsComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for displaying the actions.\r\nEither a string to use a DOM element or a component."
            },
            "backIconButtonProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the back arrow [`IconButton`](/api/icon-button/) component."
            },
            "backIconButtonText": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Text label for the back arrow icon button.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "colSpan": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "count": {
                "type": {
                    "name": "number"
                },
                "required": true,
                "description": "The total number of rows."
            },
            "labelDisplayedRows": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Customize the displayed rows label.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
            },
            "labelRowsPerPage": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Customize the rows per page label. Invoked with a `{ from, to, count, page }`\r\nobject.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
            },
            "nextIconButtonProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the next arrow [`IconButton`](/api/icon-button/) element."
            },
            "nextIconButtonText": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Text label for the next arrow icon button.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
            },
            "onChangePage": {
                "type": {
                    "name": "func"
                },
                "required": true,
                "description": "Callback fired when the page is changed.\r\n\n@param {object} event The event source of the callback.\r\n@param {number} page The page selected."
            },
            "onChangeRowsPerPage": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the number of rows per page is changed.\r\n\n@param {object} event The event source of the callback."
            },
            "page": {
                "type": {
                    "name": "custom",
                    "raw": "chainPropTypes(PropTypes.number.isRequired, props => {\r\n  const { count, page, rowsPerPage } = props;\r\n  const newLastPage = Math.max(0, Math.ceil(count / rowsPerPage) - 1);\r\n  if (page < 0 || page > newLastPage) {\r\n    return new Error(\r\n      'Material-UI: the page prop of a TablePagination is out of range ' +\r\n        `(0 to ${newLastPage}, but page is ${page}).`,\r\n    );\r\n  }\r\n  return null;\r\n})"
                },
                "required": false,
                "description": "The zero-based index of the current page."
            },
            "rowsPerPage": {
                "type": {
                    "name": "number"
                },
                "required": true,
                "description": "The number of rows per page."
            },
            "rowsPerPageOptions": {
                "type": {
                    "name": "array"
                },
                "required": false,
                "description": "Customizes the options of the rows per page select field. If less than two options are\r\navailable, no select field will be displayed."
            },
            "SelectProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the rows per page [`Select`](/api/select/) element."
            }
        }
    },
    "tablerow": {
        "displayName": "TableRow",
        "description": "Will automatically set dynamic row height\r\nbased on the material table element parent (head, body, etc).",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Should be valid <tr> children such as `TableCell`."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "hover": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the table row will shade on hover."
            },
            "selected": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the table row will have the selected shading."
            }
        }
    },
    "tablesortlabel": {
        "displayName": "TableSortLabel",
        "description": "A button based label for placing inside `TableCell` for column sorting.",
        "methods": [],
        "props": {
            "active": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the label will have the active styling (should be true for the sorted column)."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Label contents, the arrow will be appended automatically."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "direction": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'asc'",
                            "computed": false
                        },
                        {
                            "value": "'desc'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The current sort direction."
            },
            "hideSortIcon": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Hide sort icon when active is false."
            },
            "IconComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "Sort icon to use."
            }
        }
    },
    "tabs": {
        "displayName": "Tabs",
        "description": "",
        "methods": [],
        "props": {
            "action": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "Callback fired when the component mounts.\r\nThis is useful when you want to trigger an action programmatically.\r\nIt supports two actions: `updateIndicator()` and `updateScrollButtons()`\r\n\n@param {object} actions This object contains all possible actions\r\nthat can be triggered programmatically."
            },
            "centered": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the tabs will be centered.\r\nThis property is intended for large views."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "indicatorColor": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'secondary'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Determines the color of the indicator."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the value changes.\r\n\n@param {object} event The event source of the callback\r\n@param {any} value We default to the index of the child (number)"
            },
            "orientation": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'horizontal'",
                            "computed": false
                        },
                        {
                            "value": "'vertical'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The tabs orientation (layout flow direction)."
            },
            "ScrollButtonComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used to render the scroll buttons."
            },
            "scrollButtons": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'auto'",
                            "computed": false
                        },
                        {
                            "value": "'desktop'",
                            "computed": false
                        },
                        {
                            "value": "'on'",
                            "computed": false
                        },
                        {
                            "value": "'off'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Determine behavior of scroll buttons when tabs are set to scroll:\r\n\n- `auto` will only present them when not all the items are visible.\r\n- `desktop` will only present them on medium and larger viewports.\r\n- `on` will always present them.\r\n- `off` will never present them."
            },
            "TabIndicatorProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the tab indicator element."
            },
            "textColor": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'secondary'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Determines the color of the `Tab`."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The value of the currently selected `Tab`.\r\nIf you don't want any selected `Tab`, you can set this property to `false`."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'standard'",
                            "computed": false
                        },
                        {
                            "value": "'scrollable'",
                            "computed": false
                        },
                        {
                            "value": "'fullWidth'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Determines additional display behavior of the tabs:\r\n\n - `scrollable` will invoke scrolling properties and allow for horizontally\r\n scrolling (or swiping) of the tab bar.\r\n -`fullWidth` will make the tabs grow to use all the available space,\r\n which should be used for small views, like on mobile.\r\n - `standard` will render the default state."
            }
        }
    },
    "textareaautosize": {
        "displayName": "TextareaAutosize",
        "description": "",
        "methods": [],
        "props": {
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "placeholder": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "rows": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Use `rowsMin` instead. The prop will be removed in v5.\r\n\n@deprecated"
            },
            "rowsMax": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Maximum number of rows to display."
            },
            "rowsMin": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Minimum number of rows to display."
            },
            "style": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "@ignore"
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "textfield": {
        "displayName": "TextField",
        "description": "The `TextField` is a convenience wrapper for the most common cases (80%).\r\nIt cannot be all things to all people, otherwise the API would grow out of control.\r\n\n## Advanced Configuration\r\n\nIt's important to understand that the text field is a simple abstraction\r\non top of the following components:\r\n\n- [FormControl](/api/form-control/)\r\n- [InputLabel](/api/input-label/)\r\n- [FilledInput](/api/filled-input/)\r\n- [OutlinedInput](/api/outlined-input/)\r\n- [Input](/api/input/)\r\n- [FormHelperText](/api/form-helper-text/)\r\n\nIf you wish to alter the props applied to the `input` element, you can do so as follows:\r\n\n```jsx\r\nconst inputProps = {\r\n  step: 300,\r\n};\r\n\nreturn <TextField id=\"time\" type=\"time\" inputProps={inputProps} />;\r\n```\r\n\nFor advanced cases, please look at the source of TextField by clicking on the\r\n\"Edit this page\" button above. Consider either:\r\n\n- using the upper case props for passing values directly to the components\r\n- using the underlying components directly as shown in the demos",
        "methods": [],
        "props": {
            "autoComplete": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "This prop helps users to fill forms faster, especially on mobile devices.\r\nThe name can be confusing, as it's more like an autofill.\r\nYou can learn more about it [following the specification](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofill)."
            },
            "autoFocus": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be focused during the first mount."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "@ignore"
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "defaultValue": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The default value of the `input` element."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the `input` element will be disabled."
            },
            "error": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the label will be displayed in an error state."
            },
            "FormHelperTextProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`FormHelperText`](/api/form-helper-text/) element."
            },
            "fullWidth": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input will take up the full width of its container."
            },
            "helperText": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The helper text content."
            },
            "hiddenLabel": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "id": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The id of the `input` element.\r\nUse this prop to make `label` and `helperText` accessible for screen readers."
            },
            "InputLabelProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`InputLabel`](/api/input-label/) element."
            },
            "InputProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the Input element.\r\nIt will be a [`FilledInput`](/api/filled-input/),\r\n[`OutlinedInput`](/api/outlined-input/) or [`Input`](/api/input/)\r\ncomponent depending on the `variant` prop value."
            },
            "inputProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "[Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Attributes) applied to the `input` element."
            },
            "inputRef": {
                "type": {
                    "name": "custom",
                    "raw": "refType"
                },
                "required": false,
                "description": "Pass a ref to the `input` element."
            },
            "label": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The label content."
            },
            "margin": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'none'",
                            "computed": false
                        },
                        {
                            "value": "'dense'",
                            "computed": false
                        },
                        {
                            "value": "'normal'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "If `dense` or `normal`, will adjust vertical spacing of this and contained components."
            },
            "multiline": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, a textarea element will be rendered instead of an input."
            },
            "name": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Name attribute of the `input` element."
            },
            "onBlur": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the value is changed.\r\n\n@param {object} event The event source of the callback.\r\nYou can pull out the new value by accessing `event.target.value` (string)."
            },
            "onFocus": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "placeholder": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The short hint displayed in the input before the user enters a value."
            },
            "required": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the label is displayed as required and the `input` element` will be required."
            },
            "rows": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Number of rows to display when multiline option is set to true."
            },
            "rowsMax": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "string"
                        },
                        {
                            "name": "number"
                        }
                    ]
                },
                "required": false,
                "description": "Maximum number of rows to display when multiline option is set to true."
            },
            "select": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Render a [`Select`](/api/select/) element while passing the Input element to `Select` as `input` parameter.\r\nIf this option is set you must pass the options of the select as children."
            },
            "SelectProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Select`](/api/select/) element."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The size of the text field."
            },
            "type": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Type of the `input` element. It should be [a valid HTML5 input type](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Form_%3Cinput%3E_types)."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The value of the `input` element, required for a controlled component."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'standard'",
                            "computed": false
                        },
                        {
                            "value": "'outlined'",
                            "computed": false
                        },
                        {
                            "value": "'filled'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "toolbar": {
        "displayName": "Toolbar",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Toolbar children, usually a mixture of `IconButton`, `Button` and `Typography`."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "disableGutters": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, disables gutter padding."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'regular'",
                            "computed": false
                        },
                        {
                            "value": "'dense'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "tooltip": {
        "displayName": "Tooltip",
        "description": "",
        "methods": [],
        "props": {
            "arrow": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, adds an arrow to the tooltip."
            },
            "children": {
                "type": {
                    "name": "custom",
                    "raw": "elementAcceptingRef.isRequired"
                },
                "required": false,
                "description": "Tooltip reference element."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "disableFocusListener": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Do not respond to focus events."
            },
            "disableHoverListener": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Do not respond to hover events."
            },
            "disableTouchListener": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Do not respond to long press touch events."
            },
            "enterDelay": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The number of milliseconds to wait before showing the tooltip.\r\nThis prop won't impact the enter touch delay (`enterTouchDelay`)."
            },
            "enterTouchDelay": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The number of milliseconds a user must touch the element before showing the tooltip."
            },
            "id": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "This prop is used to help implement the accessibility logic.\r\nIf you don't provide this prop. It falls back to a randomly generated id."
            },
            "interactive": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Makes a tooltip interactive, i.e. will not close when the user\r\nhovers over the tooltip before the `leaveDelay` is expired."
            },
            "leaveDelay": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The number of milliseconds to wait before hiding the tooltip.\r\nThis prop won't impact the leave touch delay (`leaveTouchDelay`)."
            },
            "leaveTouchDelay": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The number of milliseconds after the user stops touching an element before hiding the tooltip."
            },
            "onClose": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback."
            },
            "onOpen": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component requests to be open.\r\n\n@param {object} event The event source of the callback."
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the tooltip is shown."
            },
            "placement": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'bottom-end'",
                            "computed": false
                        },
                        {
                            "value": "'bottom-start'",
                            "computed": false
                        },
                        {
                            "value": "'bottom'",
                            "computed": false
                        },
                        {
                            "value": "'left-end'",
                            "computed": false
                        },
                        {
                            "value": "'left-start'",
                            "computed": false
                        },
                        {
                            "value": "'left'",
                            "computed": false
                        },
                        {
                            "value": "'right-end'",
                            "computed": false
                        },
                        {
                            "value": "'right-start'",
                            "computed": false
                        },
                        {
                            "value": "'right'",
                            "computed": false
                        },
                        {
                            "value": "'top-end'",
                            "computed": false
                        },
                        {
                            "value": "'top-start'",
                            "computed": false
                        },
                        {
                            "value": "'top'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Tooltip placement."
            },
            "PopperProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Popper`](/api/popper/) element."
            },
            "title": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "Tooltip title. Zero-length titles string are never displayed."
            },
            "TransitionComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
            },
            "TransitionProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
            }
        }
    },
    "typography": {
        "displayName": "Typography",
        "description": "",
        "methods": [],
        "props": {
            "align": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'inherit'",
                            "computed": false
                        },
                        {
                            "value": "'left'",
                            "computed": false
                        },
                        {
                            "value": "'center'",
                            "computed": false
                        },
                        {
                            "value": "'right'",
                            "computed": false
                        },
                        {
                            "value": "'justify'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Set the text-align on the component."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'initial'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        },
                        {
                            "value": "'primary'",
                            "computed": false
                        },
                        {
                            "value": "'secondary'",
                            "computed": false
                        },
                        {
                            "value": "'textPrimary'",
                            "computed": false
                        },
                        {
                            "value": "'textSecondary'",
                            "computed": false
                        },
                        {
                            "value": "'error'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The color of the component. It supports those theme colors that make sense for this component."
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component.\r\nOverrides the behavior of the `variantMapping` prop."
            },
            "display": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'initial'",
                            "computed": false
                        },
                        {
                            "value": "'block'",
                            "computed": false
                        },
                        {
                            "value": "'inline'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Controls the display type"
            },
            "gutterBottom": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the text will have a bottom margin."
            },
            "noWrap": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the text will not wrap, but instead will truncate with a text overflow ellipsis.\r\n\nNote that text overflow can only happen with block or inline-block level elements\r\n(the element needs to have a width in order to overflow)."
            },
            "paragraph": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the text will have a bottom margin."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'h1'",
                            "computed": false
                        },
                        {
                            "value": "'h2'",
                            "computed": false
                        },
                        {
                            "value": "'h3'",
                            "computed": false
                        },
                        {
                            "value": "'h4'",
                            "computed": false
                        },
                        {
                            "value": "'h5'",
                            "computed": false
                        },
                        {
                            "value": "'h6'",
                            "computed": false
                        },
                        {
                            "value": "'subtitle1'",
                            "computed": false
                        },
                        {
                            "value": "'subtitle2'",
                            "computed": false
                        },
                        {
                            "value": "'body1'",
                            "computed": false
                        },
                        {
                            "value": "'body2'",
                            "computed": false
                        },
                        {
                            "value": "'caption'",
                            "computed": false
                        },
                        {
                            "value": "'button'",
                            "computed": false
                        },
                        {
                            "value": "'overline'",
                            "computed": false
                        },
                        {
                            "value": "'srOnly'",
                            "computed": false
                        },
                        {
                            "value": "'inherit'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Applies the theme typography styles."
            },
            "variantMapping": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "The component maps the variant prop to a range of different DOM element types.\r\nFor instance, subtitle1 to `<h6>`.\r\nIf you wish to change that mapping, you can provide your own.\r\nAlternatively, you can use the `component` prop."
            }
        }
    },
    "zoom": {
        "displayName": "Zoom",
        "description": "The Zoom transition can be used for the floating variant of the\r\n[Button](/components/buttons/#floating-action-buttons) component.\r\nIt uses [react-transition-group](https://github.com/reactjs/react-transition-group) internally.",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "element"
                },
                "required": false,
                "description": "A single child content element."
            },
            "in": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component will transition in."
            },
            "onEnter": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onExit": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "style": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "@ignore"
            },
            "timeout": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "shape",
                            "value": {
                                "enter": {
                                    "name": "number",
                                    "required": false
                                },
                                "exit": {
                                    "name": "number",
                                    "required": false
                                }
                            }
                        }
                    ]
                },
                "required": false,
                "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
            }
        }
    },
    "alert": {
        "displayName": "Alert",
        "description": "",
        "methods": [],
        "props": {
            "action": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The action to display. It renders after the message, at the end of the alert."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "closeText": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Override the default label for the *close popup* icon button.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
            },
            "color": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'error'",
                            "computed": false
                        },
                        {
                            "value": "'info'",
                            "computed": false
                        },
                        {
                            "value": "'success'",
                            "computed": false
                        },
                        {
                            "value": "'warning'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The main color for the alert. Unless provided, the value is taken from the `severity` prop."
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Override the icon displayed before the children.\r\nUnless provided, the icon is mapped to the value of the `severity` prop."
            },
            "iconMapping": {
                "type": {
                    "name": "shape",
                    "value": {
                        "error": {
                            "name": "node",
                            "required": false
                        },
                        "info": {
                            "name": "node",
                            "required": false
                        },
                        "success": {
                            "name": "node",
                            "required": false
                        },
                        "warning": {
                            "name": "node",
                            "required": false
                        }
                    }
                },
                "required": false,
                "description": "The component maps the `severity` prop to a range of different icons,\r\nfor instance success to `<SuccessOutlined>`.\r\nIf you wish to change this mapping, you can provide your own.\r\nAlternatively, you can use the `icon` prop to override the icon displayed."
            },
            "onClose": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component requests to be closed.\r\nWhen provided and no `action` prop is set, a close icon button is displayed that triggers the callback when clicked.\r\n\n@param {object} event The event source of the callback."
            },
            "role": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The ARIA role attribute of the element."
            },
            "severity": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'error'",
                            "computed": false
                        },
                        {
                            "value": "'info'",
                            "computed": false
                        },
                        {
                            "value": "'success'",
                            "computed": false
                        },
                        {
                            "value": "'warning'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The severity of the alert. This defines the color and icon used."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'filled'",
                            "computed": false
                        },
                        {
                            "value": "'outlined'",
                            "computed": false
                        },
                        {
                            "value": "'standard'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The variant to use."
            }
        }
    },
    "alerttitle": {
        "displayName": "AlertTitle",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "autocomplete": {
        "displayName": "Autocomplete",
        "description": "",
        "methods": [],
        "props": {
            "autoComplete": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the portion of the selected suggestion that has not been typed by the user,\r\nknown as the completion string, appears inline after the input cursor in the textbox.\r\nThe inline completion string is visually highlighted and has a selected state."
            },
            "autoHighlight": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the first option is automatically highlighted."
            },
            "autoSelect": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the selected option becomes the value of the input\r\nwhen the Autocomplete loses focus unless the user chooses\r\na different option or changes the character string in the input."
            },
            "blurOnSelect": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "enum",
                            "value": [
                                {
                                    "value": "'mouse'",
                                    "computed": false
                                },
                                {
                                    "value": "'touch'",
                                    "computed": false
                                }
                            ]
                        },
                        {
                            "name": "bool"
                        }
                    ]
                },
                "required": false,
                "description": "Control if the input should be blurred when an option is selected:\r\n\n- `false` the input is not blurred.\r\n- `true` the input is always blurred.\r\n- `touch` the input is blurred after a touch event.\r\n- `mouse` the input is blurred after a mouse event."
            },
            "ChipProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Chip`](/api/chip/) element."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "clearOnEscape": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, clear all values when the user presses escape and the popup is closed."
            },
            "clearText": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Override the default text for the *clear* icon button.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
            },
            "closeIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display in place of the default close icon."
            },
            "closeText": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Override the default text for the *close popup* icon button.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
            },
            "debug": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the popup will ignore the blur event if the input if filled.\r\nYou can inspect the popup markup with your browser tools.\r\nConsider this option when you need to customize the component."
            },
            "defaultValue": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "any"
                        },
                        {
                            "name": "array"
                        }
                    ]
                },
                "required": false,
                "description": "The default input value. Use when the component is not controlled."
            },
            "disableClearable": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input can't be cleared."
            },
            "disableCloseOnSelect": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the popup won't close when a value is selected."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input will be disabled."
            },
            "disableListWrap": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the list box in the popup will not wrap focus."
            },
            "disableOpenOnFocus": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the popup won't open on input focus."
            },
            "disablePortal": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Disable the portal behavior.\r\nThe children stay within it's parent DOM hierarchy."
            },
            "filterOptions": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "A filter function that determines the options that are eligible.\r\n\n@param {T[]} options The options to render.\r\n@param {object} state The state of the component.\r\n@returns {T[]}"
            },
            "filterSelectedOptions": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, hide the selected options from the list box."
            },
            "forcePopupIcon": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "enum",
                            "value": [
                                {
                                    "value": "'auto'",
                                    "computed": false
                                }
                            ]
                        },
                        {
                            "name": "bool"
                        }
                    ]
                },
                "required": false,
                "description": "Force the visibility display of the popup icon."
            },
            "freeSolo": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the Autocomplete is free solo, meaning that the user input is not bound to provided options."
            },
            "getOptionDisabled": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Used to determine the disabled state for a given option."
            },
            "getOptionLabel": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Used to determine the string value for a given option.\r\nIt's used to fill the input (and the list box options if `renderOption` is not provided)."
            },
            "getOptionSelected": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Used to determine if an option is selected.\r\nUses strict equality by default."
            },
            "groupBy": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "If provided, the options will be grouped under the returned string.\r\nThe groupBy value is also used as the text for group headings when `renderGroup` is not provided.\r\n\n@param {T} options The option to group.\r\n@returns {string}"
            },
            "id": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "This prop is used to help implement the accessibility logic.\r\nIf you don't provide this prop. It falls back to a randomly generated id."
            },
            "includeInputInList": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the highlight can move to the input."
            },
            "inputValue": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "The input value."
            },
            "ListboxComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used to render the listbox."
            },
            "ListboxProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the Listbox element."
            },
            "loading": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the component is in a loading state."
            },
            "loadingText": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Text to display when in a loading state.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
            },
            "multiple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, `value` must be an array and the menu will support multiple selections."
            },
            "noOptionsText": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Text to display when there are no options.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the value changes.\r\n\n@param {object} event The event source of the callback.\r\n@param {T} value"
            },
            "onClose": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the popup requests to be closed.\r\nUse in controlled mode (see open).\r\n\n@param {object} event The event source of the callback."
            },
            "onInputChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the input value changes.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} value The new value of the text input.\r\n@param {string} reason Can be: \"input\" (user input), \"reset\" (programmatic change), `\"clear\"`."
            },
            "onOpen": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the popup requests to be opened.\r\nUse in controlled mode (see open).\r\n\n@param {object} event The event source of the callback."
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Control the popup` open state."
            },
            "openText": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "Override the default text for the *open popup* icon button.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/)."
            },
            "options": {
                "type": {
                    "name": "array"
                },
                "required": false,
                "description": "Array of options."
            },
            "PaperComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used to render the body of the popup."
            },
            "PopperComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used to position the popup."
            },
            "popupIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display in place of the default popup icon."
            },
            "renderGroup": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Render the group.\r\n\n@param {any} option The group to render.\r\n@returns {ReactNode}"
            },
            "renderInput": {
                "type": {
                    "name": "func"
                },
                "required": true,
                "description": "Render the input.\r\n\n@param {object} params\r\n@returns {ReactNode}"
            },
            "renderOption": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Render the option, use `getOptionLabel` by default.\r\n\n@param {T} option The option to render.\r\n@param {object} state The state of the component.\r\n@returns {ReactNode}"
            },
            "renderTags": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Render the selected value.\r\n\n@param {T[]} value The `value` provided to the component.\r\n@param {function} getTagProps A tag props getter.\r\n@returns {ReactNode}"
            },
            "selectOnFocus": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the input's text will be selected on focus."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'medium'",
                            "computed": false
                        },
                        {
                            "value": "'small'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The size of the autocomplete."
            },
            "value": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "any"
                        },
                        {
                            "name": "array"
                        }
                    ]
                },
                "required": false,
                "description": "The value of the autocomplete.\r\n\nThe value must have reference equality with the option in order to be selected.\r\nYou can customize the equality behavior with the `getOptionSelected` prop."
            }
        }
    },
    "avatargroup": {
        "displayName": "AvatarGroup",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The avatars to stack."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            }
        }
    },
    "rating": {
        "displayName": "Rating",
        "description": "",
        "methods": [],
        "props": {
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "defaultValue": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The default value. Use when the component is not controlled."
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the rating will be disabled."
            },
            "emptyIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display when empty."
            },
            "emptyLabelText": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The label read when the rating input is empty."
            },
            "getLabelText": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Accepts a function which returns a string value that provides a user-friendly name for the current value of the rating.\r\n\nFor localization purposes, you can use the provided [translations](/guides/localization/).\r\n\n@param {number} value The rating label's value to format.\r\n@returns {string}"
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display."
            },
            "IconContainerComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component containing the icon."
            },
            "max": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Maximum rating."
            },
            "name": {
                "type": {
                    "name": "custom",
                    "raw": "chainPropTypes(PropTypes.string, props => {\r\n  if (!props.readOnly && !props.name) {\r\n    return new Error(\r\n      [\r\n        'Material-UI: the prop `name` is required (when `readOnly` is false).',\r\n        'Additionally, the input name should be unique within the parent form.',\r\n      ].join('\\n'),\r\n    );\r\n  }\r\n  return null;\r\n})"
                },
                "required": false,
                "description": "The name attribute of the radio `input` elements.\r\nIf `readOnly` is false, the prop is required,\r\nthis input name`should be unique within the parent form."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the value changes.\r\n\n@param {object} event The event source of the callback.\r\n@param {number} value The new value."
            },
            "onChangeActive": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback function that is fired when the hover state changes.\r\n\n@param {object} event The event source of the callback.\r\n@param {number} value The new value."
            },
            "onMouseLeave": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onMouseMove": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "precision": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The minimum increment value change allowed."
            },
            "readOnly": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Removes all hover effects and pointer events."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        },
                        {
                            "value": "'large'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The size of the rating."
            },
            "value": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "The rating value."
            }
        }
    },
    "skeleton": {
        "displayName": "Skeleton",
        "description": "",
        "methods": [],
        "props": {
            "animation": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'pulse'",
                            "computed": false
                        },
                        {
                            "value": "'wave'",
                            "computed": false
                        },
                        {
                            "value": "false",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The animation.\r\nIf `false` the animation effect is disabled."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "component": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the root node.\r\nEither a string to use a DOM element or a component."
            },
            "height": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "string"
                        }
                    ]
                },
                "required": false,
                "description": "Height of the skeleton.\r\nUseful when you don't want to adapt the skeleton to a text element but for instance a card."
            },
            "variant": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'text'",
                            "computed": false
                        },
                        {
                            "value": "'rect'",
                            "computed": false
                        },
                        {
                            "value": "'circle'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The type of content that will be rendered."
            },
            "width": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "string"
                        }
                    ]
                },
                "required": false,
                "description": "Width of the skeleton.\r\nUseful when the skeleton is inside an inline element with no width of its own."
            }
        }
    },
    "speeddial": {
        "displayName": "SpeedDial",
        "description": "",
        "methods": [],
        "props": {
            "ariaLabel": {
                "type": {
                    "name": "string"
                },
                "required": true,
                "description": "The aria-label of the button element.\r\nAlso used to provide the `id` for the `SpeedDial` element and its children."
            },
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "SpeedDialActions to display when the SpeedDial is `open`."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "direction": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'down'",
                            "computed": false
                        },
                        {
                            "value": "'left'",
                            "computed": false
                        },
                        {
                            "value": "'right'",
                            "computed": false
                        },
                        {
                            "value": "'up'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The direction the actions open relative to the floating action button."
            },
            "FabProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Fab`](/api/fab/) element."
            },
            "hidden": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the SpeedDial will be hidden."
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display in the SpeedDial Fab. The `SpeedDialIcon` component\r\nprovides a default Icon with animation."
            },
            "onBlur": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onClose": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component requests to be closed.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"toggle\"`, `\"blur\"`, `\"mouseLeave\"`, `\"escapeKeyDown\"`."
            },
            "onFocus": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onKeyDown": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onMouseEnter": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onMouseLeave": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onOpen": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the component requests to be open.\r\n\n@param {object} event The event source of the callback.\r\n@param {string} reason Can be: `\"toggle\"`, `\"focus\"`, `\"mouseEnter\"`."
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": true,
                "description": "If `true`, the SpeedDial is open."
            },
            "openIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display in the SpeedDial Fab when the SpeedDial is open."
            },
            "TransitionComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
            },
            "transitionDuration": {
                "type": {
                    "name": "union",
                    "value": [
                        {
                            "name": "number"
                        },
                        {
                            "name": "shape",
                            "value": {
                                "appear": {
                                    "name": "number",
                                    "required": false
                                },
                                "enter": {
                                    "name": "number",
                                    "required": false
                                },
                                "exit": {
                                    "name": "number",
                                    "required": false
                                }
                            }
                        }
                    ]
                },
                "required": false,
                "description": "The duration for the transition, in milliseconds.\r\nYou may specify a single timeout for all transitions, or individually with an object."
            },
            "TransitionProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
            }
        }
    },
    "speeddialaction": {
        "displayName": "SpeedDialAction",
        "description": "",
        "methods": [],
        "props": {
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "delay": {
                "type": {
                    "name": "number"
                },
                "required": false,
                "description": "Adds a transition delay, to allow a series of SpeedDialActions to be animated."
            },
            "FabProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Fab`](/api/fab/) component."
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The Icon to display in the SpeedDial Fab."
            },
            "id": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore"
            },
            "TooltipClasses": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Classes applied to the [`Tooltip`](/api/tooltip/) element."
            },
            "tooltipOpen": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "Make the tooltip always visible when the SpeedDial is open."
            },
            "tooltipPlacement": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'bottom-end'",
                            "computed": false
                        },
                        {
                            "value": "'bottom-start'",
                            "computed": false
                        },
                        {
                            "value": "'bottom'",
                            "computed": false
                        },
                        {
                            "value": "'left-end'",
                            "computed": false
                        },
                        {
                            "value": "'left-start'",
                            "computed": false
                        },
                        {
                            "value": "'left'",
                            "computed": false
                        },
                        {
                            "value": "'right-end'",
                            "computed": false
                        },
                        {
                            "value": "'right-start'",
                            "computed": false
                        },
                        {
                            "value": "'right'",
                            "computed": false
                        },
                        {
                            "value": "'top-end'",
                            "computed": false
                        },
                        {
                            "value": "'top-start'",
                            "computed": false
                        },
                        {
                            "value": "'top'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "Placement of the tooltip."
            },
            "tooltipTitle": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "Label to display in the tooltip."
            }
        }
    },
    "speeddialicon": {
        "displayName": "SpeedDialIcon",
        "description": "",
        "methods": [],
        "props": {
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display in the SpeedDial Floating Action Button."
            },
            "open": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "@ignore\r\nIf `true`, the SpeedDial is open."
            },
            "openIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display in the SpeedDial Floating Action Button when the SpeedDial is open."
            }
        }
    },
    "togglebutton": {
        "displayName": "ToggleButton",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": true,
                "description": "The content of the button."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": true,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "disabled": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the button will be disabled."
            },
            "disableFocusRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the  keyboard focus ripple will be disabled.\r\n`disableRipple` must also be true."
            },
            "disableRipple": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the ripple effect will be disabled."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onClick": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "selected": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, the button will be rendered in an active state."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'small'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        },
                        {
                            "value": "'large'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "@ignore"
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": true,
                "description": "The value to associate with the button when selected in a\r\nToggleButtonGroup."
            }
        }
    },
    "togglebuttongroup": {
        "displayName": "ToggleButtonGroup",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the button."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "exclusive": {
                "type": {
                    "name": "bool"
                },
                "required": false,
                "description": "If `true`, only allow one of the child ToggleButton values to be selected."
            },
            "onChange": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when the value changes.\r\n\n@param {object} event The event source of the callback.\r\n@param {any} value of the selected buttons. When `exclusive` is true\r\nthis is a single value; when false an array of selected values. If no value\r\nis selected and `exclusive` is true the value is null; when false an empty array."
            },
            "size": {
                "type": {
                    "name": "enum",
                    "value": [
                        {
                            "value": "'large'",
                            "computed": false
                        },
                        {
                            "value": "'medium'",
                            "computed": false
                        },
                        {
                            "value": "'small'",
                            "computed": false
                        }
                    ]
                },
                "required": false,
                "description": "The size of the buttons."
            },
            "value": {
                "type": {
                    "name": "any"
                },
                "required": false,
                "description": "The currently selected value within the group or an array of selected\r\nvalues when `exclusive` is false."
            }
        }
    },
    "treeitem": {
        "displayName": "TreeItem",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "collapseIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon used to collapse the node."
            },
            "endIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon displayed next to a end node."
            },
            "expandIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon used to expand the node."
            },
            "icon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The icon to display next to the tree node's label."
            },
            "label": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The tree node label."
            },
            "nodeId": {
                "type": {
                    "name": "string"
                },
                "required": true,
                "description": "The id of the node."
            },
            "onClick": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onFocus": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "onKeyDown": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "@ignore"
            },
            "TransitionComponent": {
                "type": {
                    "name": "elementType"
                },
                "required": false,
                "description": "The component used for the transition.\r\n[Follow this guide](/components/transitions/#transitioncomponent-prop) to learn more about the requirements for this component."
            },
            "TransitionProps": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Props applied to the [`Transition`](http://reactcommunity.org/react-transition-group/transition#Transition-props) element."
            }
        }
    },
    "treeview": {
        "displayName": "TreeView",
        "description": "",
        "methods": [],
        "props": {
            "children": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The content of the component."
            },
            "classes": {
                "type": {
                    "name": "object"
                },
                "required": false,
                "description": "Override or extend the styles applied to the component.\r\nSee [CSS API](#css) below for more details."
            },
            "className": {
                "type": {
                    "name": "string"
                },
                "required": false,
                "description": "@ignore"
            },
            "defaultCollapseIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The default icon used to collapse the node."
            },
            "defaultEndIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The default icon displayed next to a end node. This is applied to all\r\ntree nodes and can be overridden by the TreeItem `icon` prop."
            },
            "defaultExpanded": {
                "type": {
                    "name": "arrayOf",
                    "value": {
                        "name": "string"
                    }
                },
                "required": false,
                "description": "Expanded node ids. (Uncontrolled)"
            },
            "defaultExpandIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The default icon used to expand the node."
            },
            "defaultParentIcon": {
                "type": {
                    "name": "node"
                },
                "required": false,
                "description": "The default icon displayed next to a parent node. This is applied to all\r\nparent nodes and can be overridden by the TreeItem `icon` prop."
            },
            "expanded": {
                "type": {
                    "name": "arrayOf",
                    "value": {
                        "name": "string"
                    }
                },
                "required": false,
                "description": "Expanded node ids. (Controlled)"
            },
            "onNodeToggle": {
                "type": {
                    "name": "func"
                },
                "required": false,
                "description": "Callback fired when tree items are expanded/collapsed.\r\n\n@param {object} event The event source of the callback.\r\n@param {array} nodeIds The ids of the expanded nodes."
            }
        }
    }
}