import PropTypes from 'prop-types'
import React from 'react'
import Button from '../../button'


const ModalWrapper = class extends React.Component {

    static displayName = 'ModalWrapper'

    static defaultProps = {
        openOnMount: false
    }

    static propTypes = {
        openOnMount: PropTypes.bool,
        render: PropTypes.func.isRequired
    }

    state = {
        open: false
    }

    componentDidMount() {

        this.setState(() => ({ open: this.props.openOnMount }))
    }

    onToggle = () => {

        this.setState(({ open }) => ({ open: !open }))
    }

    render() {

        const buttonLabel = !this.state.open ? 'Open' : 'Close'

        return (
            <div id="modal-wrapper-root">

                <Button onClick={this.onToggle}>{buttonLabel}</Button>

                {this.state.open && this.props.render(this.onToggle)}

            </div>
        )
    }
}

export default ModalWrapper
