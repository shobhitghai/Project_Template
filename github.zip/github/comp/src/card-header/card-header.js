import { CardHeader } from '@material-ui/core'
import classnames from 'classnames'
import React from 'react'


const AUCardHeader = class extends React.Component {

    static displayName = 'AUCardHeader'

    static propTypes = CardHeader.propTypes

    render() {

        const { props } = this

        return (
            <CardHeader {...{
                ...props,
                className: classnames('au-card-header', props.className)
            }} />
        )
    }
}

export default AUCardHeader
