import { Popover } from '@material-ui/core/'
import { makeStyles } from '@material-ui/core/styles'
import classnames from 'classnames'
import merge from 'lodash/fp/merge'
import React from 'react'
import { withTelemetry } from '../telemetry'
import { popoverStyles } from './styles'


const useStyles = makeStyles(popoverStyles)

const AUPopover = withTelemetry(React.forwardRef(({ classes, ...other }, ref) => {

    const defaultStyles = useStyles()

    return (
        <Popover {...{
            ...other,
            classes: merge(defaultStyles, classes),
            className: classnames('au-popover', other.className),
            ref
        }} />
    )
}))

AUPopover.displayName = 'AUPopover'
AUPopover.propTypes = Popover.propTypes

export default AUPopover
