/* eslint-disable */
export const popoverStyles = theme => {
    return {
        paper: {
            // NOTE Default MUI Popover styles with AURA unit sizing added
            // So we see the popover when it's empty.
            // It's most likely on issue on userland.
            maxHeight: `calc(100% - ${theme.spacing(4)}px)`,
            maxWidth: `calc(100% - ${theme.spacing(4)}px)`,
            minHeight: theme.spacing(2),
            minWidth: theme.spacing(2),
            overflowX: 'hidden',
            overflowY: 'auto',
            position: 'absolute',
            // We disable the focus ring for mouse, touch and keyboard users.
            outline: 'none'
        }
    }
}
