/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import jss from 'jss'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import Popover from './popover'
import rootWrapper from '../../stories/root-wrapper'


const styles = {
    root: {
        backgroundColor: 'gray'
    }
}

const { classes } = jss.createStyleSheet(styles).attach()

class Component extends React.Component {
            
    constructor(props) {
        super(props)
        this.state = {
            anchorEl: null,
            open: false
        }
    }

    onClick = event => {
        this.setState({
            anchorEl: event.currrentTarget,
            open: true
        })
    }

    onClose = () => {
        this.setState({ open: false })
    }

    render() {
        
        return (
            <div>
                <button onClick={this.onClick}>
                    Show/Hide
                </button>
                <Popover
                    classes={{ root: classes.root }}
                    open={this.state.open}
                    anchorEl={this.state.anchorEl}
                    onClose={this.onClose}
                    anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'left',
                    }}
                >
                    The content of the Popover
                </Popover>
            </div>
        )
    }
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Popover'
}

export const Basic = () => <Component/>
