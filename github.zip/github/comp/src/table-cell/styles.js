/* eslint-disable */
export const tableCellStyles = theme => {
    return {
        root: {
            ...theme.typography.body2,
            padding: `${theme.spacing(6 / 8)}px ${theme.spacing(1)}px ${theme.spacing(6 / 8) - 1}px`,

            '&:last-child': {
                paddingRight: theme.spacing(1)
            }
        },

        head: {
            ...theme.typography.body2
        }
    }
}
