export { default } from './table-cell'
