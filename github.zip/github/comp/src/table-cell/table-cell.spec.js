import { configure, mount } from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import React from 'react'
import AUTableCell from './table-cell'


configure({ adapter: new Adapter() })

const table = Cell => (
    <table>
        <tbody>
            <tr>
                {Cell}
            </tr>
        </tbody>
    </table>
)

describe('Table Cell', () => {

    it('should return a ref to td', () => {

        const ref = React.createRef()

        mount(table(<AUTableCell ref={ref} />))

        expect(ref.current).toBeInstanceOf(HTMLTableCellElement)
    })
})
