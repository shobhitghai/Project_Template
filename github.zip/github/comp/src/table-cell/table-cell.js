import { TableCell } from '@material-ui/core'
import classnames from 'classnames'
import React, { forwardRef } from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { tableCellStyles } from './styles'


const AUTableCell = withTelemetry(withStyles(tableCellStyles)(forwardRef(({ className, ...rest }, ref) => (
    <TableCell {...{
        ...rest,
        className: classnames('au-table-cell', className),
        ref
    }} />
))))

AUTableCell.displayName = 'AUTableCell'

AUTableCell.propTypes = TableCell.propTypes

export default AUTableCell
