import { DialogTitle } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { dialogTitleStyles } from './styles'


const AUDialogTitle = withTelemetry(withStyles(dialogTitleStyles)(class extends React.Component {

    static displayName = 'AUDialogTitle'

    static propTypes = DialogTitle.propTypes

    render() {

        const { props } = this

        return (
            <DialogTitle {... {
                ...props,
                className: classnames('au-dialog-title', props.className),
                disableTypography: true
            }} />
        )
    }
}))

export default AUDialogTitle
