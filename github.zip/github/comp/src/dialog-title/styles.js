/* eslint-disable */
export const dialogTitleStyles = theme => {
    return {
        root: {
            ...theme.typography.h3,
            padding: theme.spacing(2),

            '&~ .au-dialog-content': {
                paddingTop: 0
            }
        }
    }
}
