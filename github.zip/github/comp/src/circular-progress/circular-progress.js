import { CircularProgress } from '@material-ui/core'
import classnames from 'classnames'
import React from 'react'


const AUCircularProgress = class extends React.Component {

    static displayName = 'AUCircularProgress'

    static propTypes = CircularProgress.propTypes

    static defaultProps = {
        ...CircularProgress.defaultProps,
        size: 32,
        thickness: 6
    }

    render() {

        const { props } = this

        return (
            <CircularProgress {...{
                ...props,
                className: classnames('au-circular-progress', props.className)
            }} />
        )
    }
}

export default AUCircularProgress
