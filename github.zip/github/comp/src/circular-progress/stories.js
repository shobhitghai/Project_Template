/* eslint-disable */
import CheckIcon from '@material-ui/icons/Check'
import SaveIcon from '@material-ui/icons/Save'
import { number, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import jss from 'jss'
import preset from 'jss-preset-default'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import rootWrapper from '../../stories/root-wrapper'
import Button from '../button'
import CircularProgress from './circular-progress'
import Fab from '../fab'


jss.setup(preset())

const styles = {
    root: {
        alignItems: 'center',
        display: 'flex',
        padding: 16
    },
    wrapper: {
        margin: 8,
        position: 'relative'
    },
    fabProgress: {
        position: 'absolute',
        top: -8,
        left: -8,
        zIndex: 1,
    },
    buttonProgress: {
        position: 'absolute',
        top: '50%',
        left: '50%',
        marginTop: -12,
        marginLeft: -12,
    },
}

class CircularProgressInterativeIntegration extends React.Component {
    timer = null

    state = {
        loading: false,
        success: false
    }

    componentWillUnmount() {
        clearTimeout(this.timer)
    }

    handleButtonClick = () => {
        if (!this.state.loading) {
            this.setState(
                {
                    loading: true,
                    success: false
                },
                () => {
                    this.timer = setTimeout(() => {
                        this.setState({
                        loading: false,
                        success: true
                        })
                    }, 2000)
                }
            )
        }
    }

    render() {
        const { loading, success } = this.state
        const {classes} = jss.createStyleSheet(styles).attach()

        return (
            <div {...{
                className: classes.root
            }}>
                <div {...{
                    className: classes.wrapper
                }}>
                    <Fab {...{
                        color: 'primary',
                        onClick: this.handleButtonClick
                    }}>
                        {success ? <CheckIcon /> : <SaveIcon />}
                    </Fab>
                    {loading &&
                        <CircularProgress {...{
                            className: classes.fabProgress,
                            size: 56
                        }} />
                    }
                </div>
                <div {...{
                    className: classes.wrapper
                }}>
                    <Button {...{
                        color: 'primary',
                        disabled: loading,
                        onClick: this.handleButtonClick,
                        variant: 'contained'
                    }}>
                        Accept terms
                    </Button>
                    {loading &&
                        <CircularProgress {...{
                            className: classes.buttonProgress,
                            size: 24
                        }} />
                    }
                </div>
            </div>
        )
    }
}

class CircularProgressDeterminate extends React.Component {
    
    timer = null

    state = {
        completed: 0,
    }

    componentDidMount() {
        this.timer = setInterval(this.progress, 20)
    }

    componentWillUnmount() {
        clearInterval(this.timer)
    }

    progress = () => {
        const { completed } = this.state
        this.setState({ completed: completed >= 100 ? 0 : completed + 1 })
    }

    render() {
        return (
            <CircularProgress {...{
                value: this.state.completed,
                variant: 'determinate'
            }} />
        )
    }
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Circular Progress'
}

export const Basic = () => (
    <CircularProgress {...{
        size: number('Size', 32),
        thickness: number('Thickness', 6)
    }} />
)

export const InterativeIntegration = () => (<CircularProgressInterativeIntegration />)

export const Determinate = () => (<CircularProgressDeterminate />)
