export const MuiNativeColors = [
    'primary',
    'secondary',
    'error',
    'warning',
    'info',
    'success'
]

export const isCustomColor = color => !MuiNativeColors.includes(color)

export const getCustomColors = theme =>
    Object.entries(theme.palette).filter(([ key, value ]) => !MuiNativeColors.includes(key) && value.main).reduce((acc, [ key, value ]) => ({
        ...acc,
        [`color${key}`]: {
            color: value.main
        }
    }), {})
