import merge from 'lodash/fp/merge'
import React, { forwardRef } from 'react'
import { makeStyles } from '@material-ui/core/styles'


export default (styles, WrappedComponent) => {

    const useStyles = makeStyles(styles)

    const Wrapper = forwardRef(({ classes, ...rest }, ref) => {

        const defaultClasses = useStyles()

        return (
            <WrappedComponent {...{
                ...rest,
                classes: merge(defaultClasses, classes),
                ref
            }} />
        )
    })

    Wrapper.displayName = `withCssClasses(${WrappedComponent.displayName})`

    return Wrapper
}
