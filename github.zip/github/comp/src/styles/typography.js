/* eslint-disable */
export const typography = () => {

    const common = {
        fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
        fontWeight: 400,
        letterSpacing: 0,
        marginLeft: 0
    }

    return {
        useNextVariants: true,
        fontFamily: common.fontFamily,
        h1: {
            ...common,
            fontSize: 40,
            lineHeight: '48px'
        },
        h2: {
            ...common,
            fontSize: 24,
            lineHeight: '32px'
        },
        h3: {
            ...common,
            fontSize: 20,
            lineHeight: '24px'
        },
        h4: {
            ...common,
            fontSize: 16,
            lineHeight: '24px'
        },
        fontSize: 14,
        fontWeightLight: 300,
        fontWeightRegular: 400,
        fontWeightMedium: 500,
        h5: {
            ...common,
            fontSize: 14,
            lineHeight: '20px'
        },
        h6: {
            ...common,
            fontSize: 12,
            lineHeight: '16px'
        },
        subtitle1: {
            ...common,
            fontSize: 20,
            lineHeight: '24px'
        },
        body1: {
            ...common,
            fontSize: 12,
            lineHeight: '16px'
        },
        body2: {
            ...common,
            fontSize: 14,
            lineHeight: '20px'
        },
        caption: {
            ...common,
            fontSize: 12,
            lineHeight: '16px'
        },
        button: {
            ...common,
            color: '#ff0000',
            fontSize: 12,
            textTransform: 'uppercase'
        }
    }
}
