import jss from 'jss'
import xmlserializer from 'xmlserializer'


const renderButton = (button, theme) => {
    const stroke = theme.palette.primary.main

    const ns = 'http://www.w3.org/2000/svg'
    const svg = document.createElementNS(ns, 'svg')

    svg.setAttributeNS(null, 'width', `${theme.spacing(1)}px`)
    svg.setAttributeNS(null, 'height', `${theme.spacing(1)}px`)
    svg.setAttributeNS(null, 'viewbox', `0 0 ${theme.spacing(1)}px ${theme.spacing(1)}px`)
    svg.innerHTML = `<polyline fill='none' stroke='${stroke}' stroke-width='1' points='${getPoints(button)}' />`

    const encodedButton = `data:image/svg+xml;base64,${window.btoa(xmlserializer.serializeToString(svg))}`

    return encodedButton
}

const getPoints = button => {
    if (button === 'expand-less') {
        return '2,5 4,3 6,5'
    }

    if (button === 'expand-more') {
        return '2,3 4,5 6,3'
    }

    if (button === 'expand-left') {
        return '5,2 3,4 5,6'
    }

    if (button === 'expand-right') {
        return '3,2 5,4 3,6'
    }
}


export default theme => {

    const expandLess = renderButton('expand-less', theme)
    const expandMore = renderButton('expand-more', theme)
    const expandLeft = renderButton('expand-left', theme)
    const expandRight = renderButton('expand-right', theme)

    const styles = {
        '@global': {
            '*': {
                '&::-webkit-scrollbar': {
                    background: theme.palette.background.paper,
                    width: theme.spacing(2)
                },

                '&::-webkit-scrollbar-button': {
                    backgroundPosition: 'center',
                    backgroundRepeat: 'no-repeat',
                    backgroundSize: `${theme.spacing(2)}px ${theme.spacing(2)}px`,
                    height: theme.spacing(2),
                    width: theme.spacing(2)
                },

                '&::-webkit-scrollbar-button:end': {
                    display: 'block'
                },

                '&::-webkit-scrollbar-button:horizontal:decrement:end': {
                    display: 'none'
                },

                '&::-webkit-scrollbar-button:horizontal:decrement:start': {
                    backgroundImage: `url(${expandLeft})`
                },

                '&::-webkit-scrollbar-button:horizontal:increment:end': {
                    backgroundImage: `url(${expandRight})`
                },

                '&::-webkit-scrollbar-button:horizontal:increment:start': {
                    display: 'none'
                },

                '&::-webkit-scrollbar-button:start': {
                    display: 'block'
                },

                '&::-webkit-scrollbar-button:vertical:decrement:end': {
                    display: 'none'
                },

                '&::-webkit-scrollbar-button:vertical:decrement:start': {
                    backgroundImage: `url(${expandLess})`
                },

                '&::-webkit-scrollbar-button:vertical:increment:end': {
                    backgroundImage: `url(${expandMore})`
                },

                '&::-webkit-scrollbar-button:vertical:increment:start': {
                    display: 'none'
                },

                '&::-webkit-scrollbar-corner': {
                    backgroundColor: theme.palette.background.paper
                },

                '&::-webkit-scrollbar-thumb': {
                    '&:horizontal': {
                        '&:hover': {
                            backgroundColor: theme.palette.primary.main
                        },

                        borderBottom: `${theme.spacing(0.5)}px solid ${theme.palette.background.paper}`,
                        borderTop: `${theme.spacing(0.5)}px solid ${theme.palette.background.paper}`
                    },

                    '&:vertical': {
                        '&:hover': {
                            backgroundColor: theme.palette.primary.main
                        },

                        borderLeft: `${theme.spacing(0.5)}px solid transparent`,
                        borderRight: `${theme.spacing(0.5)}px solid transparent`
                    },

                    backgroundClip: 'content-box',
                    backgroundColor: theme.palette.action.focus,
                    width: theme.spacing(2)
                },

                '&::-webkit-scrollbar-track': {
                    '&:horizontal': {
                        borderBottom: `${theme.spacing(0.5)}px solid transparent`,
                        borderTop: `${theme.spacing(0.5)}px solid transparent`
                    },

                    '&:vertical': {
                        borderLeft: `${theme.spacing(0.5)}px solid transparent`,
                        borderRight: `${theme.spacing(0.5)}px solid transparent`
                    },

                    backgroundClip: 'content-box',
                    backgroundColor: 'transparent'
                }
            }
        }
    }

    jss.createStyleSheet(styles).attach()
}
