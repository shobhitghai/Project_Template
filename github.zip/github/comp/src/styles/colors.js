export default {
    arcticBlue: '#1e99fa',
    arcticBlueDark: '#1a91f9',
    arcticBlueLight: '#40a8fb',
    constants: {
        appBarBlue: '#0b2a50'
    },
    error: {
        contrastText: '#fff',
        dark: '#c5002f',
        light: 'rgba(255, 108, 132, 0.1)',
        main: '#ff2e58'
    },
    steelBlue: '#001738',
    steelBlueDisabled: 'rgba(0, 23, 56, 0.35)',
    steelBlueSecondary: '#8d97a5',
    success: {
        contrastText: '#fff',
        light: 'rgba(0, 204, 122, 0.1)',
        main: '#00cc7a'
    },
    warn: {
        contrastText: '#fff',
        light: 'rgba(253, 188, 46, 0.1)',
        main: '#fdbc2e'
    },
    white: '#fff'
}
