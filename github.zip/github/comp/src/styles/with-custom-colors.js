import classnames from 'classnames'
import PropTypes from 'prop-types'
import React, { forwardRef } from 'react'
import { makeStyles, useTheme } from '@material-ui/core/styles'
import { getCustomColors, isCustomColor } from './custom-colors'


export default WrappedComponent => {

    const Wrapper = forwardRef((props, ref) => {

        const { className, color, ...rest } = props

        const useStyles = makeStyles(getCustomColors(useTheme()))

        const classes = useStyles()

        const customColorClass = isCustomColor(color) ? classes[`color${color}`] : undefined

        return (
            <WrappedComponent {...rest} {...!customColorClass ? { color } : {}} className={classnames(className, customColorClass)} ref={ref} />
        )
    })

    Wrapper.propTypes = {
        className: PropTypes.string,
        color: PropTypes.string
    }

    Wrapper.displayName = `withCustomColors(${WrappedComponent.displayName})`

    return Wrapper
}
