import { createMuiTheme } from '@material-ui/core/styles'


export const overrideWith = getClasses => theme => {

    const classes = getClasses(theme)

    const { overrides: current, ...rest } = theme

    return createMuiTheme({
        overrides: {
            ...current,
            ...classes
        },
        ...rest
    })

}
