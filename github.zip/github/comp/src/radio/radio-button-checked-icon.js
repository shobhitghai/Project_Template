import RadioButtonCheckedIcon from '@material-ui/icons/RadioButtonChecked'
import classnames from 'classnames'
import PropTypes from 'prop-types'
import React from 'react'
import { withStyles } from '../styles/'
import { radioButtonIconStyles } from './styles'


const AURadioButtonCheckedIcon = props => {
    return (
        <RadioButtonCheckedIcon {... {
            ...props,
            className: classnames('au-radio-button-checked-icon', props.className)
        }} />
    )
}

AURadioButtonCheckedIcon.propTypes = {
    className: PropTypes.string
}

export default withStyles(radioButtonIconStyles)(AURadioButtonCheckedIcon)
