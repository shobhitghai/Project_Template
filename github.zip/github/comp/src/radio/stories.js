/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { checked, disabled } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import Radio from './radio'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Radio'
}

export const Basic = () => (
    <Radio {...{
        checked: checked(),
        disabled: disabled()
    }} />
)
