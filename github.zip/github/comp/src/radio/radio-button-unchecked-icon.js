import RadioButtonUncheckedIcon from '@material-ui/icons/RadioButtonUnchecked'
import classnames from 'classnames'
import PropTypes from 'prop-types'
import React from 'react'
import { withStyles } from '../styles/'
import { radioButtonIconStyles } from './styles'


const AURadioButtonUncheckedIcon = props => {
    return (
        <RadioButtonUncheckedIcon {... {
            ...props,
            className: classnames('au-radio-button-unchecked-icon', props.className)
        }} />
    )
}

AURadioButtonUncheckedIcon.propTypes = {
    className: PropTypes.string
}

export default withStyles(radioButtonIconStyles)(AURadioButtonUncheckedIcon)
