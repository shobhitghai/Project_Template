/* eslint-disable */
export const radioStyles = theme => {
    return {
        root: {
            height: theme.spacing(2),
            width: theme.spacing(2),

            '&:hover': {
                background: 'none'
            }
        }
    }
}

export const radioButtonIconStyles = theme => {
    return {
        root: {
            fontSize: theme.spacing(2)
        }
    }
}
