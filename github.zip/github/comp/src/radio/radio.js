import { Radio } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import RadioButtonCheckedIcon from './radio-button-checked-icon'
import RadioButtonUncheckedIcon from './radio-button-unchecked-icon'
import { radioStyles } from './styles'


const icon = <RadioButtonUncheckedIcon />
const checkedIcon = <RadioButtonCheckedIcon />

const AURadio = withTelemetry(withStyles(radioStyles)(class extends React.Component {

    static displayName = 'AURadio'

    static defaultProps = {
        color: 'primary'
    }

    static propTypes = Radio.propTypes

    render() {

        const { props } = this

        return (
            <Radio {...{
                ...props,
                checkedIcon,
                className: classnames('au-radio', props.className),
                disableRipple: true,
                icon
            }} />
        )
    }
}))

export default AURadio
