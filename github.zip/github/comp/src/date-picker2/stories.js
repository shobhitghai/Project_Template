/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React, { useState } from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import DatePicker from './date-picker'
import Typography from '../typography'
import rootWrapper from '../../stories/root-wrapper'


const Component = _ => {

    const [ value, setValue ] = useState(null)
            
    const onChange = date => console.log('Change: ', date)

    const onClick = date => _ => setValue(date)

    return (
        <React.Fragment>
            <Typography variant='subtitle1'>DATE PICKER EXAMPLE</Typography>
            <div>
                <button onClick={onClick(new Date('03/03/2020'))}>March</button>
                <button onClick={onClick(new Date('04/04/2020'))}>April</button>
                <button onClick={onClick(new Date('05/05/2020'))}>May</button>
            </div>
            <DatePicker {...{
                onChange,
                value,
            }}/>
        </React.Fragment>
    )
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Date Picker 2'
}

export const Basic = () => <Component/>
