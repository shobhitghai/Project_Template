/* eslint-disable */
export default () => {

    return {
        root: {
            width: 'auto'
        }
    }
}
