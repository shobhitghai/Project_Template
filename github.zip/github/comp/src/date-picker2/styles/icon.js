/* eslint-disable */
export default () => {

    return {
        root: {
            '&:hover': {
                background: 'none'
            }
        }
    }
}
