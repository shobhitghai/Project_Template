/* eslint-disable */
import { inputStyles } from '../../input/styles'
import { inputLabelStyles } from '../../input-label/styles'


const transparentBackground = {
    backgroundColor: 'transparent'
}

export default theme => (
    {
        MuiInput: {
            ...inputStyles(theme),
            root: {
                fontSize: theme.typography.body2.fontSize
            },
            underline: {
                '&:before': {
                    borderBottom: [[ 1, 'solid', theme.palette.divider ]]
                },
                '&:hover:not(.Mui-disabled):before': {
                    borderBottom: [[ 2, 'solid', theme.palette.action.active ]]
                }
            }
        },
        MuiInputLabel: {
            ...inputLabelStyles(theme)
        },
        MuiPickersArrowSwitcher: {
            iconButton: {
                padding: 0,

                '&:hover': {
                    ...transparentBackground
                }
            }
        },
        MuiPickersBasePicker: {
            pickerView: {
                width: theme.spacing(20) + 55
            }
        },
        MuiPickersCalendarHeader: {
            
            monthText: {
                ...theme.typography.body2
            },
            monthTitleContainer: {
                alignItems: 'center'
            },
            previousMonthButton: {
                marginRight: 0
            },
            switchHeader: {
                alignItems: 'baseline',
                marginBottom: 0,
                paddingLeft: theme.spacing(2),
                paddingRight: theme.spacing(1),
            },
            yearSelectionSwitcher: {
                '&:focus': {
                    ...transparentBackground
                },
                '&:hover': {
                    ...transparentBackground
                }
            }
        },
        MuiPickersCalendarView: {
            viewTransitionContainer: {
                height: theme.spacing(20) + 40,
                paddingLeft: theme.spacing(1),
                paddingRight: theme.spacing(1)
            }
        },
        MuiPickersDay: {
            day: {
                height: theme.spacing(3),
                width: theme.spacing(3),

                '&:focus': {
                    ...transparentBackground
                },
                '&:hover': {
                    ...transparentBackground
                }
            }
        },
        MuiPickersSlideTransition: {
            transitionContainer: {
                height: theme.spacing(20),
                minHeight: [ [ theme.spacing(20) ], '!important' ]
            }
        },
        MuiPickersYear: {
            yearButton: {
                fontSize: theme.typography.body2.fontSize,
                height: theme.spacing(3),
                width: theme.spacing(7),

                '&:focus': {
                    ...transparentBackground
                },
                '&:hover': {
                    ...transparentBackground
                }
            }
        },
        MuiTypography: {
            subtitle1: {
                ...theme.typography.body2
            }
        }
    }
)