import { makeStyles, createMuiTheme, ThemeProvider } from '@material-ui/core/styles'
import { DatePicker, DesktopDatePicker, MobileDatePicker, LocalizationProvider } from '@material-ui/pickers'
import DateFnsAdapter from '@material-ui/pickers/adapter/date-fns'
import classnames from 'classnames'
import isEqual from 'date-fns/isEqual'
import PropTypes from 'prop-types'
import React, { useCallback, useEffect, useState } from 'react'
import merge from 'lodash/fp/merge'
import { withTelemetry } from '../telemetry'
import datePickerStyles from './styles/date-picker'
import iconStyles from './styles/icon'
import overrides from './styles/overrides'


const devices = {
    DESKTOP: 'desktop',
    MOBILE: 'mobile'
}
const datePickers = new Map([
    [ devices.DESKTOP, DesktopDatePicker ],
    [ devices.MOBILE, MobileDatePicker ]
])

const useDatePickerStyles = makeStyles(datePickerStyles)
const useIconStyles = makeStyles(iconStyles)

const getDatePickerTheme = theme => {

    const datePickerOverrides = overrides(theme)

    const { overrides: currentOverrides, ...rest } = theme

    const updatedOverrides = {
        overrides: {
            ...currentOverrides,
            ...datePickerOverrides
        }
    }

    return createMuiTheme({ ...updatedOverrides, ...rest })

}

const AUDatePicker2 = withTelemetry(props => {

    const { className, classes, device, onChange: propsOnChange, value, ...other } = props

    const [ selectedDate, setSelectedDate ] = useState(value)

    const onChange = useCallback(date => {
        setSelectedDate(date)
        propsOnChange && propsOnChange(date)
    })

    const defaultDatePickerStyles = useDatePickerStyles()
    const defaultIconStyles = useIconStyles()

    useEffect(_ => {
        !isEqual(value, selectedDate) && setSelectedDate(value)
    }, [ value ])

    const DP = datePickers.get(device) || DatePicker

    return (
        <ThemeProvider theme={getDatePickerTheme}>
            <LocalizationProvider dateAdapter={DateFnsAdapter}>
                <DP {...{
                    autoOk: true,
                    classes: merge(defaultDatePickerStyles, classes),
                    className: classnames('au-date-picker-2', className),
                    KeyboardButtonProps: {
                        classes: {
                            root: defaultIconStyles.root
                        }
                    },
                    label: 'Date',
                    onChange,
                    value: selectedDate,
                    ...other
                }} />
            </LocalizationProvider>
        </ThemeProvider>
    )
})

AUDatePicker2.displayName = 'AUDatePicker2'
AUDatePicker2.propTypes = {
    ...DatePicker.propTypes,
    device: PropTypes.oneOf([ devices.DESKTOP, devices.MOBILE ])
}

export default AUDatePicker2
