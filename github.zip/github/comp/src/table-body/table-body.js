import { TableBody } from '@material-ui/core'
import classnames from 'classnames'
import React from 'react'
import { withTelemetry } from '../telemetry'


export default withTelemetry(class extends React.Component {

    static displayName = 'AUTableBody'

    static propTypes = TableBody.propTypes

    render() {

        const { props } = this

        return (
            <TableBody {...{
                ...props,
                className: classnames('au-table-body', props.className)
            }} />
        )
    }
})
