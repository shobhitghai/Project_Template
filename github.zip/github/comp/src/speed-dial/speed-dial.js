import SpeedDial from '@material-ui/lab/SpeedDial'
import SpeedDialIcon from '@material-ui/lab/SpeedDialIcon'
import classnames from 'classnames'
import React, { forwardRef, useCallback, useState } from 'react'
import withCssClasses from '../styles/with-css-classes'
import { withTelemetry } from '../telemetry'
import styles from './styles'


const AUSpeedDial = withTelemetry(withCssClasses(styles, forwardRef(({ children, className, ...other }, ref) => {

    const [ open, setOpen ] = useState(false)

    const onToggle = useCallback(state => () => setOpen(state), [])

    return (
        <SpeedDial
            className={classnames('au-speed-dial', className)}
            onClose={onToggle(false)}
            onOpen={onToggle(true)}
            open={open}
            ref={ref}
            {...other}
        >
            {children}
        </SpeedDial>
    )

})))

AUSpeedDial.displayName = 'AUSpeedDial'

AUSpeedDial.defaultProps = {
    ariaLabel: 'SpeedDial',
    direction: 'down',
    icon: <SpeedDialIcon />
}

AUSpeedDial.propTypes = SpeedDial.propTypes

export default AUSpeedDial
