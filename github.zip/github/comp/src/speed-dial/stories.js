/* eslint-disable */
import DeleteIcon from '@material-ui/icons/Delete'
import FileCopyIcon from '@material-ui/icons/FileCopyOutlined'
import PrintIcon from '@material-ui/icons/Print'
import SaveIcon from '@material-ui/icons/Save'
import ShareIcon from '@material-ui/icons/Share'
import { action } from '@storybook/addon-actions'
import { withKnobs } from '@storybook/addon-knobs'
import jss from 'jss'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import { direction, tooltipPlacement } from '../../stories/knobs'
import rootWrapper from '../../stories/root-wrapper'
import SpeedDialAction from '../speed-dial-action'
import SpeedDial from './speed-dial'


const onClick = e => action('click')(e)

const actions = [
    { icon: <FileCopyIcon />, name: 'Copy' },
    { icon: <SaveIcon />, name: 'Save' },
    { icon: <PrintIcon />, name: 'Print' },
    { icon: <ShareIcon />, name: 'Share' },
    { icon: <DeleteIcon />, name: 'Delete' }
]

const styles = {
    fab: {
        color: 'red'
    }
}

const { classes } = jss.createStyleSheet(styles).attach()

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Speed Dial'
}

export const Basic = () => (
    <SpeedDial
        direction={direction()}
        classes={{ fab: classes.fab }}
    >
        {actions.map(action => (
            <SpeedDialAction
                key={action.name}
                icon={action.icon}
                onClick={onClick}
                tooltipPlacement={tooltipPlacement()}
                tooltipTitle={action.name}
                tooltipOpen
            />
        ))}
    </SpeedDial>
)
