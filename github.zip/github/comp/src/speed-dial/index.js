export { default } from './speed-dial'
