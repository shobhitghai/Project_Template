import { StepConnector } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { stepConnectorStyles } from './styles'


const AUStepConnector = withStyles(stepConnectorStyles)(class extends React.Component {

    static displayName = 'AUStepConnector'

    render() {

        const { props } = this

        return (
            <StepConnector {...{
                ...props,
                className: classnames('au-step-connector', props.className)
            }} />
        )
    }
})

export default AUStepConnector
