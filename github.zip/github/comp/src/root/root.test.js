import { configure, shallow } from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import toJson from 'enzyme-to-json'
import React from 'react'
import Root from './root'


configure({ adapter: new Adapter() })

describe('<Root />', () => {

    it('should render correctly', () => {
        const tree = shallow(
            <Root>
                <p>Test paragraph</p>
            </Root>
        )

        expect(toJson(tree)).toMatchSnapshot()
    })

    it('should expose themes', () => {

        expect(Root.themes).toEqual({
            DARK: 'dark',
            LIGHT: 'light',
            PUBLIC_DARK: 'public-dark',
            PUBLIC_LIGHT: 'public-light'
        })
    })
})
