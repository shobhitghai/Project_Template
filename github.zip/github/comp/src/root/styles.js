export default theme => ({
    root: {
        zoom: theme.zoom
    }
})
