import { CssBaseline } from '@material-ui/core'
import { MuiThemeProvider, withStyles } from '@material-ui/core/styles'
import busFactory from '@TB80/aura-bus/bus'
import { getContext } from '@TB80/aura-environment'
import { Theme as ThemeTopics } from '@TB80/aura-topics'
import classnames from 'classnames'
import jss from 'jss'
import preset from 'jss-preset-default'
import PropTypes from 'prop-types'
import forEach from 'lodash/fp/forEach'
import isEmpty from 'lodash/fp/isEmpty'
import isEqual from 'lodash/fp/isEqual'
import negate from 'lodash/fp/negate'
import noop from 'lodash/fp/noop'
import values from 'lodash/fp/values'
import React from 'react'
import 'typeface-roboto'
import { distinctUntilChanged, filter, pluck } from 'rxjs/operators'
import { scrollbars } from '../styles'
import ThemeFactory, { Sizes, Themes, Zoom } from '../themes'
import DateFnsUtils from '../date-picker/utils/date-fns-utils'
import MuiPickersUtilsProvider from '../date-picker/utils/mui-pickers-utils-provider'
import TelemetryProvider from '../telemetry/provider'
import styles from './styles'


jss.setup(preset())

const defaultTheme = {
    grid: Sizes.LARGE,
    palette: Themes.LIGHT,
    zoom: Zoom.DEFAULT
}

const getTheme = prefs => {
    return ThemeFactory(prefs)
}

const Root = class extends React.Component {

    static defaultProps = {
        changeTheme: true,
        telemetry: noop,
        theme: defaultTheme
    }

    static displayName = 'Root'

    static propTypes = {

        /**
         * Flag to allow change of theme
         */
        changeTheme: PropTypes.bool,

        /**
         * The telemetry servive
         */
        telemetry: PropTypes.func,

        /**
         * The styling theme
         */
        theme: PropTypes.shape({
            grid: PropTypes.oneOf(values(Sizes)),
            palette: PropTypes.oneOf(values(Themes)),
            zoom: PropTypes.oneOf(values(Zoom))
        })
    }

    static themes = Themes

    constructor(props) {

        super(props)

        const theme = getTheme(props.theme)

        scrollbars(theme)

        this.state = {
            theme,
            themeConfig: props.theme
        }

        this.themeSubscription = getContext()
            .pipe(
                filter(() => props.changeTheme),
                pluck('theme'),
                filter(negate(isEmpty)),
                distinctUntilChanged(isEqual),
            )
            .subscribe(theme => {

                this.updateTheme(theme)
            })

        this.bus = busFactory()

        this.listeners = [ {
            listener: theme => {

                this.updateTheme(theme)
            },
            topic: ThemeTopics.CHANGE
        } ]

        forEach(this.bus.subscribe, this.listeners)
    }

    componentDidUpdate(prevProps) {

        if (this.props.changeTheme && !isEqual(prevProps.theme, this.props.theme)) {
            this.updateTheme(this.props.theme)
        }
    }

    componentWillUnmount() {

        this.themeSubscription.unsubscribe()

        if (this.bus) {
            forEach(this.bus.unsubscribe, this.listeners)
        }
    }

    updateTheme = update => {

        const themeConfig = {
            ...this.state.themeConfig,
            ...update
        }

        const theme = getTheme(themeConfig)

        scrollbars(theme)
        this.setState({ theme, themeConfig })
    }

    render() {

        const { props, state } = this
        const { className, theme } = props

        return (
            <TelemetryProvider service={props.telemetry}>
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <MuiThemeProvider theme={state.theme}>
                        <CssBaseline />
                        <Inner {...{ className, theme }}>
                            {props.children}
                        </Inner>
                    </MuiThemeProvider>
                </MuiPickersUtilsProvider>
            </TelemetryProvider>
        )
    }
}

const Inner = withStyles(styles)(({ children, className, classes, theme }) => (
    <div className={classnames('root', className, classes.root, theme.palette)}>
        {children}
    </div>
))

export default Root
