/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import Root from './root'
import Paper from '../paper'
import { theme } from '../../stories/knobs'


export default {
    decorators: [
        withKnobs,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Root'
}

export const ThemeChangeAllowed = () => (
    <Root theme={theme()} changeTheme={true}>
        <Paper />
    </Root>
)

export const ThemeChangeNotAllowed = () => (
    <Root theme={theme()} changeTheme={false}>
        <Paper />
    </Root>
)

export const DefaultWithoutThemeChangeFlag = () => (
    <Root theme={theme()}>
        <Paper />
    </Root>
)
