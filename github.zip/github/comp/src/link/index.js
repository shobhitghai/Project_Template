export { default } from './link'
