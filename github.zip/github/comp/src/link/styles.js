/* eslint-disable */
export const linkStyles = theme => {

    return {
        root: {
            fontSize: theme.typography.body2.fontSize
        }
    }
}
