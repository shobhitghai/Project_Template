/* eslint-disable */
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import Link from './link'
import rootWrapper from '../../stories/root-wrapper'


class Component extends React.Component {
            
    constructor(props) {
        super(props);
        this.ref = React.createRef()
        this.onClick = this.onClick.bind(this)
    }

    onClick(event) {
        event.preventDefault()
        console.log('Ref: ', this.ref.current)
    }

    render() {
        
        return (
            <Link href="#" underline="none" ref={this.ref} onClick={this.onClick}>
                Link
            </Link>
        )
    }
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Link'
}

export const Basic = () => <Component/>
