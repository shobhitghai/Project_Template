import Link from '@material-ui/core/Link'
import { makeStyles } from '@material-ui/core/styles'
import classnames from 'classnames'
import merge from 'lodash/fp/merge'
import React from 'react'
import { withTelemetry } from '../telemetry'
import { linkStyles } from './styles'


const useStyles = makeStyles(linkStyles)

const AULink = withTelemetry(React.forwardRef(({ classes, ...other }, ref) => {

    const defaultStyles = useStyles()

    return (
        <Link {...{
            ...other,
            classes: merge(defaultStyles, classes),
            className: classnames('au-link', other.className),
            ref
        }} />
    )
}))

AULink.displayName = 'AULink'
AULink.propTypes = Link.propTypes

export default AULink
