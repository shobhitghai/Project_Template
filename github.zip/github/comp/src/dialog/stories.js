/* eslint-disable */
import { boolean, select, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import jss from 'jss'
import preset from 'jss-preset-default'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import rootWrapper from '../../stories/root-wrapper'
import Button from '../button'
import DialogActions from '../dialog-actions'
import DialogContent from '../dialog-content'
import DialogContentText from '../dialog-content-text'
import DialogTitle from '../dialog-title'
import Dialog from './dialog'


jss.setup(preset())

const styles = {
    dialogActionsButton: {
        '& ~ .au-button': {
            marginLeft: 8
        }
    }
}

const { classes } = jss.createStyleSheet(styles).attach()

class SimpleDialog extends React.Component {
    state = {
        open: false
    }

    toggleDialog = () => {
        this.setState({ open: !this.state.open })
    }

    render() {
        return (
            <div>
                <Button {...{
                    children: 'Open Dialog',
                    onClick: this.toggleDialog
                }} />

                <Dialog {...{
                    disableBackdropClick: boolean(
                        'Disable Backdrop Click',
                        false
                    ),
                    disableEscapeKeyDown: boolean(
                        'Disable Escape Key Down',
                        false
                    ),
                    fullScreen: boolean(
                        'Full Screen',
                        false
                    ),
                    maxWidth: select(
                        'Max Width',
                        {
                            false: 'False',
                            md: 'md',
                            sm: 'sm',
                            xs: 'xs'
                        },
                        'xs'
                    ),
                    onClose: this.toggleDialog,
                    open: this.state.open
                }}>
                    <DialogTitle>Dialog Title</DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            Lorem ipsum dolor sit amet, vim inimicus mediocritatem eu. Graeci euismod eu pri. Nihil epicurei forensibus ne mel, ei modo ancillae sit. Discere efficiendi no nam, dolore aperiam vituperatoribus ea ius. Pro cu labitur temporibus, sea ubique laoreet pericula ei. Tacimates partiendo quo ex.
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button {...{
                            className: classes.dialogActionsButton
                        }}>Button</Button>
                        <Button {...{
                            className: classes.dialogActionsButton,
                            color: 'primary',
                            onClick: this.toggleDialog
                        }}>Close Dialog</Button>
                    </DialogActions>
                </Dialog>
            </div>
        )
    }
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Dialog'
}

export const Basic = () => <SimpleDialog />
