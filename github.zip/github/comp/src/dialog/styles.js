/* eslint-disable */
export const dialogStyles = theme => {
    return {
        root: {
            ...theme.typography.body2
        }
    }
}
