import { Dialog } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import PaperProps from '../paper/paper-props'
import { withTelemetry } from '../telemetry'
import { dialogStyles } from './styles'


const AUDialog = withTelemetry(withStyles(dialogStyles)(class extends React.Component {

    static displayName = 'AUDialog'

    static propTypes = Dialog.propTypes

    render() {

        const { props } = this

        return (
            <Dialog {... {
                ...props,
                className: classnames('au-dialog', props.className),
                PaperProps
            }} />
        )
    }
}))

export default AUDialog
