import { DialogActions } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { dialogActionsStyles } from './styles'


const AUDialogActions = withTelemetry(withStyles(dialogActionsStyles)(class extends React.Component {

    static displayName = 'AUDialogActions'

    static propTypes = DialogActions.propTypes

    render() {

        const { props } = this

        return (
            <DialogActions {... {
                ...props,
                className: classnames('au-dialog-actions', props.className)
            }} />
        )
    }
}))

export default AUDialogActions
