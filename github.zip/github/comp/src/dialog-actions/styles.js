/* eslint-disable */
export const dialogActionsStyles = theme => {
    return {
        root: {
            padding: `${theme.spacing(1)}px ${theme.spacing(1.5)}px`
        }
    }
}
