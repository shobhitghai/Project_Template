/* eslint-disable */
import MenuIcon from '@material-ui/icons/Menu'
import { select, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import jss from 'jss'
import preset from 'jss-preset-default'
import React, { Fragment } from 'react'
import { color } from '../../stories/knobs'
import mdx from '../../stories/components/component-doc.mdx'
import rootWrapper from '../../stories/root-wrapper'
import IconButton from '../icon-button'
import Paper from '../paper'
import Toolbar from '../toolbar'
import Typography from '../typography'
import AppBar from './app-bar'


export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|AppBar'
}


jss.setup(preset())

const styles = {
    button: {
        marginRight: 16
    },
    paper: {
        padding: 16
    },
    wrapper: {
        marginTop: 56,
        padding: 32
    }
}

const { classes } = jss.createStyleSheet(styles).attach()

export const Basic = () => ( 
    <AppBar {...{
        color: color(),
        position: select(
            'Position',
            {
                absolute: 'Absolute',
                fixed: 'Fixed',
                static: 'Static',
                sticky: 'Sticky'
            },
            'fixed',
            'POSITION'
        )
    }}>
        <Toolbar />
    </AppBar>
)
export const AppBarPositioningInContext = () => (
    <Fragment>
        <div {...{
            className: classes.wrapper
        }}>
            <Paper {...{
                className: classes.paper
            }}>
                <Typography {...{
                    gutterBottom: true
                }}>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris a placerat neque. In consectetur, massa lacinia fringilla laoreet, urna tellus semper nibh, eu ornare nisi sapien tempor eros. Aenean in justo velit. Etiam id lacus leo. Nam vel velit eu odio rutrum vestibulum. Cras convallis, sem quis pellentesque faucibus, tortor velit semper augue, vel ullamcorper massa lectus id nibh. Suspendisse id odio non erat ultricies aliquet.
                </Typography>
                <Typography {...{
                    gutterBottom: true
                }}>
                    Nam sit amet dignissim nulla, et iaculis arcu. Sed ac tortor eleifend odio placerat auctor sit amet nec nulla. Praesent vehicula vestibulum nisi. Proin nec placerat sapien. Pellentesque auctor, diam vel maximus dapibus, elit massa fermentum arcu, sed volutpat sapien turpis at ex. Nullam ac massa at risus consectetur pretium. Vivamus sit amet mollis dolor. Cras metus mi, lobortis vel orci in, ultrices laoreet orci. Sed finibus molestie vestibulum. Maecenas tempus mi vitae quam imperdiet laoreet. Phasellus molestie auctor mauris, eu condimentum nibh vehicula sit amet. Mauris a viverra tortor. Integer non pretium sapien. Fusce consequat ultrices sem sit amet gravida.
                </Typography>
            </Paper>
        </div>

        <AppBar {...{
            color: color(),
            position: select(
                'Position',
                {
                    absolute: 'Absolute',
                    fixed: 'Fixed',
                    static: 'Static',
                    sticky: 'Sticky'
                },
                'fixed',
                'POSITION'
            )
        }}>
            <Toolbar>
                <IconButton {...{
                    classes: {
                        root: classes.button
                    },
                    color: 'primary'
                }}>
                    <MenuIcon />
                </IconButton>
                <Typography {...{
                    color: 'primary',
                    variant: 'h2'
                }}>
                    Aura
                </Typography>
            </Toolbar>
        </AppBar>

        <div {...{
            className: classes.wrapper
        }}>
            <Paper {...{
                className: classes.paper
            }}>
                <Typography {...{
                    gutterBottom: true
                }}>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris a placerat neque. In consectetur, massa lacinia fringilla laoreet, urna tellus semper nibh, eu ornare nisi sapien tempor eros. Aenean in justo velit. Etiam id lacus leo. Nam vel velit eu odio rutrum vestibulum. Cras convallis, sem quis pellentesque faucibus, tortor velit semper augue, vel ullamcorper massa lectus id nibh. Suspendisse id odio non erat ultricies aliquet.
                </Typography>
                <Typography {...{
                    gutterBottom: true
                }}>
                    Nam sit amet dignissim nulla, et iaculis arcu. Sed ac tortor eleifend odio placerat auctor sit amet nec nulla. Praesent vehicula vestibulum nisi. Proin nec placerat sapien. Pellentesque auctor, diam vel maximus dapibus, elit massa fermentum arcu, sed volutpat sapien turpis at ex. Nullam ac massa at risus consectetur pretium. Vivamus sit amet mollis dolor. Cras metus mi, lobortis vel orci in, ultrices laoreet orci. Sed finibus molestie vestibulum. Maecenas tempus mi vitae quam imperdiet laoreet. Phasellus molestie auctor mauris, eu condimentum nibh vehicula sit amet. Mauris a viverra tortor. Integer non pretium sapien. Fusce consequat ultrices sem sit amet gravida.
                </Typography>
                <Typography {...{
                    gutterBottom: true
                }}>
                    Proin maximus erat augue, in maximus tortor lacinia sollicitudin. Curabitur placerat, nisi sit amet egestas ultricies, dui sem volutpat tortor, in egestas urna dui a mauris. Nunc erat metus, iaculis eu dolor eu, sagittis faucibus orci. Praesent eu tincidunt nisl. Aliquam lobortis lorem sit amet placerat aliquam. Nulla sollicitudin ut est eu facilisis. Fusce molestie nisi et porttitor tincidunt. Quisque sagittis accumsan enim, sed venenatis quam feugiat vel. Aliquam tincidunt eu mi sit amet faucibus. Nam rutrum venenatis nulla at euismod. Proin sit amet commodo lectus. Quisque ac nibh ante. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.
                </Typography>
                <Typography {...{
                    gutterBottom: true
                }}>
                    Cras pulvinar gravida massa. Nullam a commodo nulla, quis placerat velit. Vivamus interdum dictum mi eu scelerisque. Sed molestie interdum quam, at volutpat justo feugiat ac. Suspendisse gravida suscipit risus, sed vulputate dolor rutrum id. Aliquam enim lectus, auctor a imperdiet a, luctus quis nunc. Suspendisse in placerat tellus, ut bibendum lacus. Etiam non lacinia velit, id pharetra nulla. Morbi dapibus nisl a ipsum fermentum facilisis vel eu enim. Fusce venenatis gravida pretium. Mauris et massa sed dolor malesuada scelerisque. Maecenas bibendum sagittis ante, in vulputate nunc laoreet eget.
                </Typography>
                <Typography {...{
                    gutterBottom: true
                }}>
                    Suspendisse a nunc risus. Phasellus ullamcorper aliquet massa, non pharetra nisl pulvinar vitae. Sed sed leo a sem aliquam efficitur sit amet eget neque. Phasellus quis maximus erat, eu feugiat velit. Sed ut leo nec risus tincidunt faucibus quis sed eros. Pellentesque malesuada vel neque eget molestie. Ut efficitur orci tellus, vel varius libero facilisis eget. Aenean dignissim mi libero, a fringilla neque blandit eu. Quisque nec ex in purus laoreet vestibulum. Ut laoreet ultrices semper. Morbi tincidunt suscipit arcu, in consectetur nisi malesuada at. Donec auctor molestie velit, sit amet commodo sapien volutpat eget. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nulla consequat, sem id pretium volutpat, nunc nibh bibendum risus, quis eleifend eros libero eget dui. Vivamus a tristique felis, quis efficitur nunc.
                </Typography>
                <Typography {...{
                    gutterBottom: true
                }}>
                    Quisque sagittis orci mi, non ullamcorper dui malesuada nec. Mauris in dui risus. Nullam nulla nisi, tincidunt eget nunc et, accumsan egestas dui. Fusce aliquet sagittis lorem. Nulla vitae magna ligula. Maecenas sagittis sapien sed imperdiet accumsan. Vivamus laoreet cursus malesuada. Aenean at diam a nibh convallis aliquet sit amet eget justo. Curabitur bibendum quam non elit tristique scelerisque. Vivamus eget rutrum ante. Integer eget lacus sem.
                </Typography>
                <Typography {...{
                    gutterBottom: true
                }}>
                    Suspendisse non felis massa. Donec sit amet quam arcu. Nam sapien justo, dictum sed nisi in, pretium mattis nisi. Cras posuere elementum posuere. Etiam quis rutrum felis, pellentesque iaculis massa. Nullam fermentum hendrerit justo in pulvinar. Morbi rutrum mauris in augue semper, id ullamcorper enim maximus. Morbi quis pharetra purus, nec iaculis libero.
                </Typography>
                <Typography {...{
                    gutterBottom: true
                }}>
                    Donec laoreet ut odio a venenatis. Fusce pellentesque ullamcorper mauris, tincidunt ornare nisi blandit nec. Duis ut nisi eget est feugiat efficitur sed vitae sapien. Proin egestas enim lacus, sit amet aliquam mi semper nec. Nam quis eleifend erat. Sed maximus, nulla sed sagittis aliquet, orci nisl bibendum turpis, nec pharetra nibh turpis a ligula. Nullam non dignissim risus, fringilla aliquet enim. Integer feugiat, augue eu lacinia volutpat, nisl diam auctor orci, in ornare risus sem in diam. Mauris porta auctor justo non consectetur. Nunc feugiat velit at enim dictum condimentum. Duis eget rhoncus eros, et suscipit leo. Nam at consectetur sem, sit amet tincidunt ex. Phasellus quis metus ac enim venenatis malesuada. Vestibulum dolor felis, malesuada sodales ligula ut, fermentum efficitur massa. Vivamus eleifend, diam vel egestas elementum, tellus velit sollicitudin dui, non sagittis ante nunc nec odio. Vestibulum tempus placerat est sed egestas.
                </Typography>
                <Typography {...{
                    gutterBottom: true
                }}>
                    Integer vel accumsan eros. Phasellus at blandit massa. Nullam id scelerisque ex. Cras ipsum ipsum, tempus non maximus eget, venenatis sed urna. Donec vitae interdum mi, vel placerat ipsum. Curabitur semper mi sit amet neque tincidunt, a porttitor metus scelerisque. Fusce nec scelerisque magna, in ornare est.
                </Typography>
                <Typography {...{
                    gutterBottom: true
                }}>
                    Etiam dolor augue, venenatis ut tellus sit amet, ornare fringilla lorem. Etiam auctor libero tempus luctus dictum. Nullam rhoncus risus nec blandit tempor. Integer id cursus lorem, a rhoncus nisi. Quisque blandit semper sodales. Proin semper quis ante ac pellentesque. Etiam a nibh ac odio tincidunt feugiat ut sit amet ex. Vivamus ultrices ut metus nec sodales. Duis ornare nibh malesuada, bibendum mi egestas, dictum elit. Nunc mauris massa, pulvinar eget pulvinar in, facilisis vitae orci.
                </Typography>
            </Paper>
        </div>
    </Fragment>
)
