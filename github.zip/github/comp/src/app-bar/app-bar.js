import { AppBar } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { appBarStyles } from './styles'


const AUAppBar = withTelemetry(withStyles(appBarStyles)(class extends React.Component {

    static displayName = 'AUAppBar'

    static propTypes = AppBar.propTypes

    static defaultProps = {
        ...AppBar.defaultProps,
        color: 'default'
    }

    render() {

        const { props } = this

        return (
            <AppBar {... {
                ...props,
                className: classnames('au-app-bar', props.className)
            }}>
                {props.children}
            </AppBar>
        )
    }
}))

export default AUAppBar
