/* eslint-disable */
import { colors } from '../styles/'


export const appBarStyles = theme => {

    return {
        root: {
            boxShadow: theme.shadows[0]
        },
        positionStatic: {
            position: 'relative'
        },
        colorDefault: {
            backgroundColor: theme.palette.background.paper
        }
    }
}
