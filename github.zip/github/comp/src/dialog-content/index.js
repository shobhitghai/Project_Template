export { default } from './dialog-content'
