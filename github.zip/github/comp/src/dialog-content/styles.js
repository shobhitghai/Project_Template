/* eslint-disable */
export const dialogContentStyles = theme => {

    const DIALOG_CONTENT_PADDING = theme.spacing(2)

    return {
        root: {
            padding: DIALOG_CONTENT_PADDING,

            '&:first-child': {
                paddingTop: DIALOG_CONTENT_PADDING
            }
        }
    }
}
