import { DialogContent } from '@material-ui/core/'
import classnames from 'classnames'
import React from 'react'
import { withStyles } from '../styles/'
import { withTelemetry } from '../telemetry'
import { dialogContentStyles } from './styles'


const AUDialogContent = withTelemetry(withStyles(dialogContentStyles)(class extends React.Component {

    static displayName = 'AUDialogContent'

    static propTypes = DialogContent.propTypes

    render() {

        const { props } = this

        return (
            <DialogContent {... {
                ...props,
                className: classnames('au-dialog-content', props.className)
            }} />
        )
    }
}))

export default AUDialogContent
