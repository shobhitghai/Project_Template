import Add from '@material-ui/icons/Add'
import Remove from '@material-ui/icons/Remove'
import classnames from 'classnames'
import React from 'react'
import Tree, { TreeNode } from 'rc-tree'
import 'rc-tree/assets/index.css'
import PropTypes from 'prop-types'
import { withStyles } from '../styles'
import { withTelemetry } from '../telemetry'
import { listStyles } from './styles'


const AUTree = withTelemetry(withStyles(listStyles)(class extends React.Component {

    static displayName = 'AUTree'

    static propTypes = {
        childrenField: PropTypes.string.isRequired,
        classes: PropTypes.shape({
            svg: PropTypes.string.isRequired
        }).isRequired,
        data: PropTypes.array.isRequired,
        getNode: PropTypes.func.isRequired,
        onClick: PropTypes.func.isRequired,
        selectedId: PropTypes.string
    }

    getSwitcher = node => (
        node.expanded ? <Remove className={this.props.classes.svg} /> : <Add className={this.props.classes.svg} />
    )

    getNode = data => {

        const { icon, key, label } = this.props.getNode(data)

        const subNodes = data[this.props.childrenField]

        return (
            <TreeNode
                title={label}
                key={key}
                isLeaf={!Array.isArray(subNodes)}
                icon={icon}
                origin={data}
            >
                {Array.isArray(subNodes) && subNodes.map(node => this.getNode(node))}
            </TreeNode>
        )
    }

    onSelect = (_, e) => { // needs second param only
        this.props.onClick(e.node.props.origin, e)
    }

    render() {

        const { props } = this
        const { classes, data } = props

        const selectedIds = props.selectedId ? [ props.selectedId ] : []

        return (
            <div className={classnames('au-tree', classes.root, props.className)}>
                {Array.isArray(data) && data.length > 0 && (
                    <Tree
                        showIcon
                        onSelect={this.onSelect}
                        defaultSelectedKeys={selectedIds}
                        defaultExpandAll={props.expandAll}
                        switcherIcon={this.getSwitcher}
                        {...this.props}
                        onClick={undefined} // override undocumented event
                    >
                        {data.map(node => this.getNode(node))}
                    </Tree>
                )}
            </div>
        )
    }
}))

export default AUTree
