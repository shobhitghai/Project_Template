/* eslint-disable */
export const listStyles = theme => {
    return {
        svg: {
            fontSize: `inherit`,
        },

        root: {
            color: theme.palette.text.primary,
            cursor: 'default',
            fontFamily: theme.typography.fontFamily,
            fontSize: theme.typography.body2.fontSize,
            background: theme.palette.background.paper,

            '& .rc-tree': {
                paddingLeft: 0
            },

            '& ul': {
                listStyleType: 'none'
            },

            '& .rc-tree>li>span .rc-tree-title': {
                color: theme.typography.body2.color
            },

            '& .rc-tree-title': {
                color: theme.palette.text.secondary
            },

            '& .rc-tree-switcher': {
                color: theme.palette.background.paper,
                display: 'inline-flex',
                fontSize: `${theme.spacing(2)}px`,
                borderRadius: '2px',
                verticalAlign: 'text-top'
            },

            '& .rc-tree li': {
                lineHeight: `${theme.spacing(4)}px`,
                paddingTop: 0,
                paddingBottom: 0
            },

            '& .rc-tree-child-tree > li:first-child': {
                paddingTop: 0
            },

            '& .rc-tree-switcher_open': {
                backgroundColor: `${theme.palette.text.secondary} !important`,
                backgroundImage: 'none !important'
            },

            '& .rc-tree-switcher_close': {
                backgroundColor: `${theme.palette.primary.main} !important`,
                backgroundImage: 'none !important'
            },

            '& .rc-tree-switcher-noop': {
                display: 'none !important'
            },

            '& .rc-tree-iconEle:empty': {
                display: 'none'
            },

            '& .rc-tree-iconEle': {
                width: 'auto !important'
            },

            '& .rc-tree li ul': {
                paddingLeft: `${theme.spacing(3)}px`
            },

            '& .rc-tree-node-content-wrapper': {
                border: 'none',
                height: 'auto !important',
                padding: `0 ${theme.spacing(1)}px !important`,
                width: '100%',

                '&:hover': {
                    backgroundColor: theme.palette.action.hover,
                    cursor: 'pointer',

                    '& .rc-tree-title': {
                        color: theme.typography.body2.color
                    }
                }
            },

            '& .switch-icon': {
                fontSize: theme.spacing(2),
            },

            '& .rc-tree-node-selected': {
                backgroundColor: theme.palette.action.selected,

                '& .rc-tree-title': {
                    color: theme.palette.primary.main
                }
            }
        }
    }
}
