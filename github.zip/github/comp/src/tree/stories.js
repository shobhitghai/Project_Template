/* eslint-disable */
import ExpandMore from '@material-ui/icons/ExpandMore'
import ExpandLess from '@material-ui/icons/ExpandLess'
import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/react'
import jss from 'jss'
import preset from 'jss-preset-default'
import React from 'react'
import mdx from '../../stories/components/component-doc.mdx'
import rootWrapper from '../../stories/root-wrapper'
import Tree from './tree'


jss.setup(preset())

class Component extends React.Component {

    getNode = data => {
        return {
            key: data.id,
            label: data.label.toUpperCase()
        }
    }

    render() {

        const data = [
            {
                id: '1',
                label: 'Root',
                nodes: [
                    {
                        id: '1.1',
                        label: 'Node 1',
                        nodes: [
                            {
                                id: '1.1.1',
                                label: 'Sub-node 1.1'
                            },
                            {
                                id: '1.1.2',
                                label: 'Sub-node 1.2'
                            }
                            ,
                            {
                                id: '1.1.3',
                                label: 'Sub-node 1.3'
                            }
                            ,
                            {
                                id: '1.1.4',
                                label: 'Sub-node 1.4'
                            }
                        ]
                    },
                    {
                        id: '1.2',
                        label: 'Node 2',
                        nodes: [
                            {
                                id: '1.2.1',
                                label: 'Sub-node 2.1'
                            },
                            {
                                id: '1.2.2',
                                label: 'Sub-node 2.2'
                            }
                        ]
                    }
                ]
            }
        ]

        return (
            <Tree
                childrenField={'nodes'}
                data={data}
                expandAll={true}
                getNode={this.getNode}
                onClick={() => { }}
                selectable={true}
                {...this.props}
            />
        )
    }
}

export default {
    decorators: [
        withKnobs,
        rootWrapper,
    ],
    parameters: {
        docs: {
            page: mdx,
        } 
    },
    title: 'Components|Tree'
}

export const Basic = () => <Component />

export const CustomIcons = () => (
    <Component
        switcherIcon={({ expanded }) => {
            const iconProps = { style: { fontSize: 'inherit' } }
            return expanded ? <ExpandMore {...iconProps} /> : <ExpandLess {...iconProps} />
        }}
    />
)
